#! /usr/bin/python3
"""
Sophos XGS IPHost Hook Script

Creates or updates an IPHost entry on Sophos XGS firewall when a user logs in.
Based on AD group membership, the IPHost is added to ALLOW_INTERNET or BLOCK_INTERNET group.
This allows dynamic firewall rules based on user authentication and group membership.

Usage:
    Called by edulution-eventhandler with JSON event on STDIN.

Configuration:
    /etc/edulution/sophos.json (or SOPHOS_CONFIG environment variable)
"""

import ipaddress
import json
import logging
import os
import sys
import urllib.parse
import xml.etree.ElementTree as ET
from typing import Any

import requests
import urllib3

# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configuration
DEFAULT_CONFIG_PATH = "/etc/edulution/sophos.json"

# Default group names
DEFAULT_ALLOW_GROUP = "ALLOW_INTERNET"
DEFAULT_BLOCK_GROUP = "BLOCK_INTERNET"
DEFAULT_INTERNET_AD_GROUP = "internet"

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)


def load_config(config_path: str) -> dict[str, Any]:
    """Load Sophos configuration from JSON file."""
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        logger.error("Config file not found: %s", config_path)
        sys.exit(1)
    except json.JSONDecodeError as e:
        logger.error("Invalid JSON in config file: %s", e)
        sys.exit(1)


def build_iphost_xml(
    name: str,
    ip_address: str,
    host_type: str = "IP",
    ip_family: str = "IPv4",
    host_group: str | None = None,
) -> str:
    """
    Build XML request for creating/updating an IPHost.

    Args:
        name: Name of the IPHost (e.g., username or "user_workstation")
        ip_address: IP address of the host
        host_type: Type of host (IP, Network, IPRange, IPList)
        ip_family: IPv4 or IPv6
        host_group: Optional host group to add the host to
    """
    # Build the IPHost XML
    host_xml = f"""
    <IPHost>
        <Name>{name}</Name>
        <IPFamily>{ip_family}</IPFamily>
        <HostType>{host_type}</HostType>
        <IPAddress>{ip_address}</IPAddress>
    </IPHost>
    """

    return host_xml.strip()


def build_iphost_group_xml(
    name: str,
    description: str = "",
    hosts: list[str] | None = None,
) -> str:
    """
    Build XML for an IPHostGroup.

    Args:
        name: Name of the IPHostGroup
        description: Optional description
        hosts: List of IPHost names to include
    """
    hosts_xml = ""
    if hosts:
        hosts_xml = "<HostList>" + "".join(f"<Host>{h}</Host>" for h in hosts) + "</HostList>"

    return f"""
    <IPHostGroup>
        <Name>{name}</Name>
        <Description>{description}</Description>
        {hosts_xml}
    </IPHostGroup>
    """.strip()


def build_get_request_xml(
    username: str,
    password: str,
    entity_type: str,
    filter_name: str | None = None,
) -> str:
    """
    Build XML for a GET request to check if entity exists.

    Args:
        username: API username
        password: API password
        entity_type: Type of entity (IPHostGroup, IPHost, etc.)
        filter_name: Optional name filter
    """
    filter_xml = ""
    if filter_name:
        filter_xml = f"<Filter><key name='Name' criteria='='>{filter_name}</key></Filter>"

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <Login>
        <Username>{username}</Username>
        <Password>{password}</Password>
    </Login>
    <Get>
        <{entity_type}>{filter_xml}</{entity_type}>
    </Get>
</Request>"""


def build_request_xml(
    username: str,
    password: str,
    action: str,
    entity_xml: str,
) -> str:
    """
    Build the full API request XML.

    Args:
        username: API username
        password: API password (or encrypted password)
        action: API action (add, update, set, remove)
        entity_xml: The entity XML (e.g., IPHost)
    """
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <Login>
        <Username>{username}</Username>
        <Password>{password}</Password>
    </Login>
    <{action.capitalize()}>
        {entity_xml}
    </{action.capitalize()}>
</Request>"""


def call_sophos_api(
    firewall_url: str,
    request_xml: str,
    verify_ssl: bool = False,
    timeout: int = 30,
) -> tuple[bool, str]:
    """
    Call the Sophos XGS API.

    Args:
        firewall_url: Base URL of the firewall (e.g., https://192.168.1.1:4444)
        request_xml: The XML request body
        verify_ssl: Whether to verify SSL certificate
        timeout: Request timeout in seconds

    Returns:
        Tuple of (success, message)
    """
    api_endpoint = f"{firewall_url}/webconsole/APIController"

    try:
        response = requests.post(
            api_endpoint,
            data={"reqxml": request_xml},
            verify=verify_ssl,
            timeout=timeout,
        )

        # Parse response
        try:
            root = ET.fromstring(response.text)

            # Check for login status
            login_status = root.find(".//Login/status")
            if login_status is not None and login_status.text != "Authentication Successful":
                return False, f"Authentication failed: {login_status.text}"

            # Check for operation status
            status = root.find(".//Status")
            if status is not None:
                code = status.get("code", "")
                if code == "200":
                    return True, "Success"
                elif code == "502":
                    # Already exists - try update instead
                    return False, "Already exists"
                else:
                    status_text = status.text or "Unknown error"
                    return False, f"Error {code}: {status_text}"

            return True, "Operation completed"

        except ET.ParseError:
            return False, f"Invalid XML response: {response.text[:200]}"

    except requests.exceptions.Timeout:
        return False, "Request timeout"
    except requests.exceptions.ConnectionError as e:
        return False, f"Connection error: {e}"
    except Exception as e:
        return False, f"Unexpected error: {e}"


def check_iphost_group_exists(
    config: dict[str, Any],
    group_name: str,
) -> tuple[bool, list[str]]:
    """
    Check if an IPHostGroup exists and return its current members.

    Returns:
        Tuple of (exists, list_of_current_hosts)
    """
    firewall_url = config.get("firewall_url", "")
    username = config.get("api_username", "")
    password = config.get("api_password", "")
    verify_ssl = config.get("verify_ssl", False)

    request_xml = build_get_request_xml(username, password, "IPHostGroup", group_name)
    api_endpoint = f"{firewall_url}/webconsole/APIController"

    try:
        response = requests.post(
            api_endpoint,
            data={"reqxml": request_xml},
            verify=verify_ssl,
            timeout=30,
        )

        root = ET.fromstring(response.text)

        # Check if group was found
        group = root.find(".//IPHostGroup")
        if group is not None:
            # Extract current hosts
            hosts = []
            for host in group.findall(".//HostList/Host"):
                if host.text:
                    hosts.append(host.text)
            return True, hosts

        return False, []

    except Exception as e:
        logger.error("Error checking IPHostGroup %s: %s", group_name, e)
        return False, []


def ensure_iphost_group_exists(
    config: dict[str, Any],
    group_name: str,
    description: str = "",
) -> bool:
    """
    Ensure an IPHostGroup exists, creating it if necessary.
    """
    exists, _ = check_iphost_group_exists(config, group_name)

    if exists:
        logger.debug("IPHostGroup %s already exists", group_name)
        return True

    # Create the group
    firewall_url = config.get("firewall_url", "")
    username = config.get("api_username", "")
    password = config.get("api_password", "")
    verify_ssl = config.get("verify_ssl", False)

    group_xml = build_iphost_group_xml(group_name, description)
    request_xml = build_request_xml(username, password, "add", group_xml)
    success, message = call_sophos_api(firewall_url, request_xml, verify_ssl)

    if success:
        logger.info("Created IPHostGroup: %s", group_name)
        return True

    logger.error("Failed to create IPHostGroup %s: %s", group_name, message)
    return False


def add_iphost_to_group(
    config: dict[str, Any],
    iphost_name: str,
    group_name: str,
) -> bool:
    """
    Add an IPHost to an IPHostGroup.

    The Sophos API requires sending the full host list when updating a group.
    """
    firewall_url = config.get("firewall_url", "")
    username = config.get("api_username", "")
    password = config.get("api_password", "")
    verify_ssl = config.get("verify_ssl", False)

    # Get current hosts in the group
    exists, current_hosts = check_iphost_group_exists(config, group_name)

    if not exists:
        logger.error("IPHostGroup %s does not exist", group_name)
        return False

    # Check if already in group
    if iphost_name in current_hosts:
        logger.debug("IPHost %s already in group %s", iphost_name, group_name)
        return True

    # Add to list
    new_hosts = current_hosts + [iphost_name]

    # Update the group
    group_xml = build_iphost_group_xml(group_name, hosts=new_hosts)
    request_xml = build_request_xml(username, password, "update", group_xml)
    success, message = call_sophos_api(firewall_url, request_xml, verify_ssl)

    if success:
        logger.info("Added IPHost %s to group %s", iphost_name, group_name)
        return True

    logger.error("Failed to add IPHost %s to group %s: %s", iphost_name, group_name, message)
    return False


def remove_iphost_from_group(
    config: dict[str, Any],
    iphost_name: str,
    group_name: str,
) -> bool:
    """
    Remove an IPHost from an IPHostGroup.
    """
    firewall_url = config.get("firewall_url", "")
    username = config.get("api_username", "")
    password = config.get("api_password", "")
    verify_ssl = config.get("verify_ssl", False)

    # Get current hosts in the group
    exists, current_hosts = check_iphost_group_exists(config, group_name)

    if not exists:
        logger.debug("IPHostGroup %s does not exist", group_name)
        return True

    # Check if in group
    if iphost_name not in current_hosts:
        logger.debug("IPHost %s not in group %s", iphost_name, group_name)
        return True

    # Remove from list
    new_hosts = [h for h in current_hosts if h != iphost_name]

    # Update the group
    group_xml = build_iphost_group_xml(group_name, hosts=new_hosts)
    request_xml = build_request_xml(username, password, "update", group_xml)
    success, message = call_sophos_api(firewall_url, request_xml, verify_ssl)

    if success:
        logger.info("Removed IPHost %s from group %s", iphost_name, group_name)
        return True

    logger.error("Failed to remove IPHost %s from group %s: %s", iphost_name, group_name, message)
    return False


def create_or_update_iphost(
    config: dict[str, Any],
    name: str,
    ip_address: str,
) -> bool:
    """
    Create or update an IPHost on the Sophos XGS.

    First tries to add, if it exists, tries to update.
    """
    firewall_url = config.get("firewall_url", "")
    username = config.get("api_username", "")
    password = config.get("api_password", "")
    verify_ssl = config.get("verify_ssl", False)
    host_group = config.get("host_group")

    if not all([firewall_url, username, password]):
        logger.error("Missing required configuration (firewall_url, api_username, api_password)")
        return False

    # Build IPHost XML
    iphost_xml = build_iphost_xml(
        name=name,
        ip_address=ip_address,
        host_group=host_group,
    )

    # Try to add first
    request_xml = build_request_xml(username, password, "set", iphost_xml)
    success, message = call_sophos_api(firewall_url, request_xml, verify_ssl)

    if success:
        logger.info("IPHost created/updated: %s -> %s", name, ip_address)
        return True

    if "Already exists" in message:
        # Try update
        request_xml = build_request_xml(username, password, "set", iphost_xml)
        success, message = call_sophos_api(firewall_url, request_xml, verify_ssl)

        if success:
            logger.info("IPHost updated: %s -> %s", name, ip_address)
            return True

    logger.error("Failed to create/update IPHost %s: %s", name, message)
    return False


def generate_iphost_name(event: dict[str, Any], config: dict[str, Any]) -> str:
    """
    Generate the IPHost name based on configuration.

    Supports templates with placeholders:
    - {user}: Username without domain
    - {domain}: Domain name
    - {workstation}: Workstation name
    - {full_user}: Full username (domain\\user)
    - {school}: School name from LDAP (sophomorixSchoolname)
    - {class}: Class name from LDAP (sophomorixAdminClass)
    """
    template = config.get("iphost_name_template", "{user}")

    user = event.get("user", "")
    workstation = event.get("workstation", "")
    school = event.get("school", "")
    admin_class = event.get("class", "")

    # Split domain and username
    if "\\" in user:
        domain, username = user.split("\\", 1)
    else:
        domain = ""
        username = user

    # Replace placeholders
    name = template.format(
        user=username,
        domain=domain,
        workstation=workstation,
        full_user=user.replace("\\", "_"),
        school=school,
        **{"class": admin_class},  # 'class' is a reserved keyword
    )

    # Sanitize name (Sophos doesn't like special characters)
    name = "".join(c if c.isalnum() or c in "-_" else "_" for c in name)

    return name


def main():
    """Main entry point."""
    # Load configuration
    config_path = os.environ.get("SOPHOS_CONFIG", DEFAULT_CONFIG_PATH)
    config = load_config(config_path)

    # Read event from STDIN
    try:
        event_json = sys.stdin.read()
        event = json.loads(event_json)
    except json.JSONDecodeError as e:
        logger.error("Invalid JSON input: %s", e)
        sys.exit(1)

    # Extract required fields
    ip_address = event.get("remote", "")
    user = event.get("user", "")
    status = event.get("status", "")
    event_id = event.get("eventId", 0)

    # Only process successful logins
    if event_id != 4624 or status != "NT_STATUS_OK":
        logger.debug("Skipping non-login event: eventId=%s, status=%s", event_id, status)
        sys.exit(0)

    # Validate IP
    if not ip_address:
        logger.warning("No IP address in event")
        sys.exit(0)

    # Skip if IP should be ignored (e.g., internal ranges)
    ignored_ips = config.get("ignored_ips", [])
    ignored_networks = config.get("ignored_networks", [])

    if ip_address in ignored_ips:
        logger.debug("Ignoring IP %s (in ignored_ips)", ip_address)
        sys.exit(0)

    # Check ignored networks (CIDR notation supported)
    try:
        ip_obj = ipaddress.ip_address(ip_address)
        for network in ignored_networks:
            try:
                net_obj = ipaddress.ip_network(network, strict=False)
                if ip_obj in net_obj:
                    logger.debug("Ignoring IP %s (in network %s)", ip_address, network)
                    sys.exit(0)
            except ValueError:
                # Fallback: simple prefix match for backwards compatibility
                if ip_address.startswith(network.rstrip(".")):
                    logger.debug("Ignoring IP %s (matches prefix %s)", ip_address, network)
                    sys.exit(0)
    except ValueError:
        logger.warning("Invalid IP address: %s", ip_address)
        sys.exit(0)

    # Generate IPHost name
    iphost_name = generate_iphost_name(event, config)

    # Create/update IPHost
    success = create_or_update_iphost(config, iphost_name, ip_address)

    if not success:
        sys.exit(1)

    # Get group configuration
    allow_group = config.get("allow_internet_group", DEFAULT_ALLOW_GROUP)
    block_group = config.get("block_internet_group", DEFAULT_BLOCK_GROUP)
    internet_ad_group = config.get("internet_ad_group", DEFAULT_INTERNET_AD_GROUP)
    enable_groups = config.get("enable_internet_groups", True)

    if not enable_groups:
        logger.debug("Internet groups feature disabled")
        sys.exit(0)

    # Ensure both groups exist
    ensure_iphost_group_exists(
        config, allow_group, "Users with internet access"
    )
    ensure_iphost_group_exists(
        config, block_group, "Users without internet access"
    )

    # Get user's AD groups from event
    user_groups = event.get("groups", [])
    # Normalize group names to lowercase for comparison
    user_groups_lower = [g.lower() for g in user_groups]

    # Check if user has internet access
    has_internet = internet_ad_group.lower() in user_groups_lower

    if has_internet:
        # Add to ALLOW, remove from BLOCK
        logger.info("User %s has internet access (member of %s)", user, internet_ad_group)
        add_iphost_to_group(config, iphost_name, allow_group)
        remove_iphost_from_group(config, iphost_name, block_group)
    else:
        # Add to BLOCK, remove from ALLOW
        logger.info("User %s does NOT have internet access (not member of %s)", user, internet_ad_group)
        add_iphost_to_group(config, iphost_name, block_group)
        remove_iphost_from_group(config, iphost_name, allow_group)

    sys.exit(0)


if __name__ == "__main__":
    main()
