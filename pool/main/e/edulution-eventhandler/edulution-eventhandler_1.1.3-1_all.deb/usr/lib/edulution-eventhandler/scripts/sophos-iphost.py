#! /usr/bin/python3
"""
Sophos XGS IPHostGroup Management Script

This script is DEPRECATED. The Sophos integration is now built into the main
edulution-eventhandler daemon with batching support.

The new implementation:
- Manages a single BLOCKED_IPS group (instead of per-user IPHosts)
- Users without 'internet' AD group have their IP added to BLOCKED_IPS
- Users with 'internet' AD group have their IP removed from BLOCKED_IPS
- Changes are batched and sent to Sophos after a configurable interval

Configure Sophos in /etc/edulution-eventhandler/hooks.json:

{
  "sophos": {
    "enabled": true,
    "firewall_url": "https://192.168.1.1:4444",
    "api_username": "admin",
    "api_password": "your-password",
    "verify_ssl": false,
    "ignored_ips": ["127.0.0.1"],
    "ignored_networks": ["10.0.0.0/24"],
    "internet_ad_group": "internet",
    "blocked_ips_group": "BLOCKED_IPS",
    "batch_interval": 10.0
  }
}

For manual testing/debugging, this script can still be used to add/remove IPs
from the BLOCKED_IPS group.

Usage:
    sophos-iphost.py --add <ip>      Add IP to BLOCKED_IPS group
    sophos-iphost.py --remove <ip>   Remove IP from BLOCKED_IPS group
    sophos-iphost.py --list          List all IPs in BLOCKED_IPS group
"""

import argparse
import json
import logging
import os
import sys
import xml.etree.ElementTree as ET

import requests
import urllib3

# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configuration
DEFAULT_CONFIG_PATH = "/etc/edulution-eventhandler/hooks.json"

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)


def load_config(config_path: str) -> dict:
    """Load Sophos configuration from hooks.json file."""
    try:
        with open(config_path, encoding="utf-8") as f:
            data = json.load(f)
            return data.get("sophos", {})
    except FileNotFoundError:
        logger.error("Config file not found: %s", config_path)
        sys.exit(1)
    except json.JSONDecodeError as e:
        logger.error("Invalid JSON in config file: %s", e)
        sys.exit(1)


def build_iphost_group_xml(name: str, description: str = "", hosts: list[str] | None = None) -> str:
    """Build XML for an IPHostGroup."""
    hosts_xml = ""
    if hosts:
        hosts_xml = "<HostList>" + "".join(f"<Host>{h}</Host>" for h in hosts) + "</HostList>"
    return f"""
    <IPHostGroup>
        <Name>{name}</Name>
        <Description>{description}</Description>
        {hosts_xml}
    </IPHostGroup>
    """.strip()


def build_request_xml(username: str, password: str, action: str, entity_xml: str) -> str:
    """Build the full API request XML."""
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <Login>
        <Username>{username}</Username>
        <Password>{password}</Password>
    </Login>
    <{action.capitalize()}>
        {entity_xml}
    </{action.capitalize()}>
</Request>"""


def build_get_request_xml(
    username: str, password: str, entity_type: str, filter_name: str | None = None
) -> str:
    """Build XML for a GET request."""
    filter_xml = ""
    if filter_name:
        filter_xml = f"<Filter><key name='Name' criteria='='>{filter_name}</key></Filter>"
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <Login>
        <Username>{username}</Username>
        <Password>{password}</Password>
    </Login>
    <Get>
        <{entity_type}>{filter_xml}</{entity_type}>
    </Get>
</Request>"""


def call_api(config: dict, request_xml: str) -> tuple[bool, str]:
    """Call the Sophos XGS API."""
    firewall_url = config.get("firewall_url", "")
    verify_ssl = config.get("verify_ssl", False)
    api_endpoint = f"{firewall_url}/webconsole/APIController"

    try:
        response = requests.post(
            api_endpoint,
            data={"reqxml": request_xml},
            verify=verify_ssl,
            timeout=30,
        )
        try:
            root = ET.fromstring(response.text)
            login_status = root.find(".//Login/status")
            if login_status is not None and login_status.text != "Authentication Successful":
                return False, f"Authentication failed: {login_status.text}"
            status = root.find(".//Status")
            if status is not None:
                code = status.get("code", "")
                if code == "200":
                    return True, "Success"
                elif code == "502":
                    return False, "Already exists"
                else:
                    return False, f"Error {code}: {status.text or 'Unknown'}"
            return True, "Operation completed"
        except ET.ParseError:
            return False, f"Invalid XML response: {response.text[:200]}"
    except requests.exceptions.Timeout:
        return False, "Request timeout"
    except requests.exceptions.ConnectionError as e:
        return False, f"Connection error: {e}"
    except Exception as e:
        return False, f"Unexpected error: {e}"


def get_group_hosts(config: dict, group_name: str) -> tuple[bool, list[str]]:
    """Get current hosts in the IPHostGroup."""
    username = config.get("api_username", "")
    password = config.get("api_password", "")
    firewall_url = config.get("firewall_url", "")
    verify_ssl = config.get("verify_ssl", False)

    request_xml = build_get_request_xml(username, password, "IPHostGroup", group_name)

    try:
        response = requests.post(
            f"{firewall_url}/webconsole/APIController",
            data={"reqxml": request_xml},
            verify=verify_ssl,
            timeout=30,
        )
        root = ET.fromstring(response.text)
        group = root.find(".//IPHostGroup")
        if group is not None:
            hosts = [h.text for h in group.findall(".//HostList/Host") if h.text]
            return True, hosts
        return False, []
    except Exception as e:
        logger.error("Error checking IPHostGroup %s: %s", group_name, e)
        return False, []


def ensure_group_exists(config: dict, group_name: str) -> bool:
    """Ensure the IPHostGroup exists, creating it if necessary."""
    exists, _ = get_group_hosts(config, group_name)
    if exists:
        return True

    username = config.get("api_username", "")
    password = config.get("api_password", "")

    group_xml = build_iphost_group_xml(group_name, "Blocked IPs")
    request_xml = build_request_xml(username, password, "add", group_xml)
    success, message = call_api(config, request_xml)

    if success:
        logger.info("Created IPHostGroup: %s", group_name)
        return True
    logger.error("Failed to create IPHostGroup %s: %s", group_name, message)
    return False


def add_ip_to_group(config: dict, ip: str) -> bool:
    """Add an IP to the BLOCKED_IPS group."""
    group_name = config.get("blocked_ips_group", "BLOCKED_IPS")
    username = config.get("api_username", "")
    password = config.get("api_password", "")

    if not ensure_group_exists(config, group_name):
        return False

    exists, current_hosts = get_group_hosts(config, group_name)
    if not exists:
        return False

    if ip in current_hosts:
        logger.info("IP %s already in group %s", ip, group_name)
        return True

    new_hosts = [*current_hosts, ip]
    group_xml = build_iphost_group_xml(group_name, "Blocked IPs", hosts=new_hosts)
    request_xml = build_request_xml(username, password, "update", group_xml)
    success, message = call_api(config, request_xml)

    if success:
        logger.info("Added IP %s to group %s", ip, group_name)
        return True
    logger.error("Failed to add IP %s to group %s: %s", ip, group_name, message)
    return False


def remove_ip_from_group(config: dict, ip: str) -> bool:
    """Remove an IP from the BLOCKED_IPS group."""
    group_name = config.get("blocked_ips_group", "BLOCKED_IPS")
    username = config.get("api_username", "")
    password = config.get("api_password", "")

    exists, current_hosts = get_group_hosts(config, group_name)
    if not exists:
        logger.info("Group %s does not exist", group_name)
        return True

    if ip not in current_hosts:
        logger.info("IP %s not in group %s", ip, group_name)
        return True

    new_hosts = [h for h in current_hosts if h != ip]
    group_xml = build_iphost_group_xml(group_name, "Blocked IPs", hosts=new_hosts)
    request_xml = build_request_xml(username, password, "update", group_xml)
    success, message = call_api(config, request_xml)

    if success:
        logger.info("Removed IP %s from group %s", ip, group_name)
        return True
    logger.error("Failed to remove IP %s from group %s: %s", ip, group_name, message)
    return False


def list_ips(config: dict) -> None:
    """List all IPs in the BLOCKED_IPS group."""
    group_name = config.get("blocked_ips_group", "BLOCKED_IPS")
    exists, hosts = get_group_hosts(config, group_name)

    if not exists:
        print(f"Group {group_name} does not exist")
        return

    print(f"IPs in {group_name}:")
    if hosts:
        for ip in sorted(hosts):
            print(f"  {ip}")
    else:
        print("  (empty)")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Manage Sophos BLOCKED_IPS group",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "-c",
        "--config",
        default=os.environ.get("EDULUTION_HOOKS_CONFIG", DEFAULT_CONFIG_PATH),
        help="Path to hooks.json config file",
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--add", metavar="IP", help="Add IP to BLOCKED_IPS group")
    group.add_argument("--remove", metavar="IP", help="Remove IP from BLOCKED_IPS group")
    group.add_argument("--list", action="store_true", help="List all IPs in BLOCKED_IPS group")

    args = parser.parse_args()

    config = load_config(args.config)

    if not config.get("firewall_url"):
        logger.error("No firewall_url configured in sophos section")
        sys.exit(1)

    if args.add:
        success = add_ip_to_group(config, args.add)
        sys.exit(0 if success else 1)
    elif args.remove:
        success = remove_ip_from_group(config, args.remove)
        sys.exit(0 if success else 1)
    elif args.list:
        list_ips(config)
        sys.exit(0)


if __name__ == "__main__":
    main()
