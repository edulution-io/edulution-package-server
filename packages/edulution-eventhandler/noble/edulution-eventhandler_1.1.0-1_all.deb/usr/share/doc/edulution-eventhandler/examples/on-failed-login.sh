#!/bin/bash
# Example hook script for failed Samba login attempts
# Receives JSON event data on STDIN

# Read JSON from STDIN
EVENT_JSON=$(cat)

# Parse fields using jq
TIMESTAMP=$(echo "$EVENT_JSON" | jq -r '.timestamp // empty')
USER=$(echo "$EVENT_JSON" | jq -r '.Authentication.clientAccount // empty')
DOMAIN=$(echo "$EVENT_JSON" | jq -r '.Authentication.clientDomain // empty')
WORKSTATION=$(echo "$EVENT_JSON" | jq -r '.Authentication.workstation // empty')
REMOTE=$(echo "$EVENT_JSON" | jq -r '.Authentication.remoteAddress // empty')
STATUS=$(echo "$EVENT_JSON" | jq -r '.Authentication.status // empty')

# Log the failed attempt
logger -t samba-failed-login "Failed login for ${DOMAIN}\\${USER} from ${WORKSTATION} (${REMOTE}): ${STATUS}"

# Example: Increment fail counter in Redis for fail2ban-style blocking
# redis-cli INCR "samba:failed:${REMOTE}"

# Example: Send alert for repeated failures
# FAIL_COUNT=$(redis-cli GET "samba:failed:${REMOTE}")
# if [ "$FAIL_COUNT" -gt 5 ]; then
#     curl -s -d "Multiple failed logins from ${REMOTE}" ntfy.sh/my-security-alerts
# fi

exit 0
