#!/bin/bash
# Example hook script for successful Samba logins
# Receives JSON event data on STDIN

# Read JSON from STDIN
EVENT_JSON=$(cat)

# Parse fields using jq
TIMESTAMP=$(echo "$EVENT_JSON" | jq -r '.timestamp // empty')
USER=$(echo "$EVENT_JSON" | jq -r '.Authentication.clientAccount // empty')
DOMAIN=$(echo "$EVENT_JSON" | jq -r '.Authentication.clientDomain // empty')
WORKSTATION=$(echo "$EVENT_JSON" | jq -r '.Authentication.workstation // empty')
REMOTE=$(echo "$EVENT_JSON" | jq -r '.Authentication.remoteAddress // empty')

# Log the event
logger -t samba-login "User ${DOMAIN}\\${USER} logged in from ${WORKSTATION} (${REMOTE})"

# Example: Send notification via ntfy.sh
# curl -s -d "User ${USER} logged in from ${WORKSTATION}" ntfy.sh/my-samba-alerts

# Example: Write to a log file
echo "${TIMESTAMP} - Login: ${DOMAIN}\\${USER} from ${WORKSTATION} (${REMOTE})" >> /var/log/samba-logins.log

# Example: Update a database
# mysql -u user -p'password' -e "INSERT INTO logins (user, workstation, timestamp) VALUES ('${USER}', '${WORKSTATION}', NOW())"

exit 0
