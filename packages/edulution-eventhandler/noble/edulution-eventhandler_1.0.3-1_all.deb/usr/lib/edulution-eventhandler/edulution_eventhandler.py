#! /usr/bin/python3
"""
Edulution Event Handler

Reads Samba JSON Audit events from systemd journal and triggers configured hooks.
Automatically pushes all events to the configured Edulution server.
Enriches events with AD group memberships.
"""

import asyncio
import ipaddress
import json
import logging
import os
import signal
import sys
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import aiohttp
import requests
import urllib3
from ldap3 import ALL, Connection, Server
from ldap3.core.exceptions import LDAPException
from systemd import journal
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

# Disable SSL warnings for self-signed certificates (Sophos)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configuration
DEFAULT_CONFIG_PATH = "/etc/edulution/hooks.json"
SAMBA_CONF_PATH = "/etc/samba/smb.conf"
SAMBA_UNITS = ("samba-ad-dc.service",)  # Trailing comma for single-element tuple
GROUP_CACHE_TTL = 5  # 5 seconds cache for group memberships

# Logging setup
log_level = logging.DEBUG if os.environ.get("EDULUTION_DEBUG") else logging.INFO
logging.basicConfig(
    level=log_level,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


# Linuxmuster.net defaults
LINUXMUSTER_LDAP_SERVER = "ldap://localhost"
LINUXMUSTER_PASSWORD_FILE = "/etc/linuxmuster/.secret/administrator"


def get_samba_realm() -> str | None:
    """
    Read the realm/domain from smb.conf.

    Looks for 'realm = DOMAIN.TLD' in the [global] section.
    Returns the realm in uppercase (e.g., 'LINUXMUSTER.LAN') or None if not found.
    """
    try:
        with open(SAMBA_CONF_PATH, "r", encoding="utf-8") as f:
            in_global = False
            for line in f:
                line = line.strip()

                # Track section
                if line.startswith("["):
                    in_global = line.lower() == "[global]"
                    continue

                # Look for realm in [global] section
                if in_global and "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip().lower()
                    value = value.strip()

                    if key == "realm":
                        # Remove quotes if present
                        value = value.strip("'\"")
                        logger.debug("Found realm in smb.conf: %s", value)
                        return value.upper()

    except FileNotFoundError:
        logger.debug("smb.conf not found at %s", SAMBA_CONF_PATH)
    except Exception as e:
        logger.debug("Error reading smb.conf: %s", e)

    return None


def realm_to_base_dn(realm: str) -> str:
    """
    Convert a realm to LDAP base DN.

    Example: 'LINUXMUSTER.LAN' -> 'DC=linuxmuster,DC=lan'
    """
    parts = realm.lower().split(".")
    return ",".join(f"DC={part}" for part in parts)


def get_default_base_dn() -> str:
    """Get default base DN from smb.conf realm or fallback."""
    realm = get_samba_realm()
    if realm:
        return realm_to_base_dn(realm)
    return "DC=linuxmuster,DC=lan"


def get_default_bind_dn() -> str:
    """Get default bind DN from smb.conf realm or fallback."""
    base_dn = get_default_base_dn()
    return f"CN=Administrator,CN=Users,{base_dn}"


# Default extra LDAP attributes to fetch (linuxmuster.net / Sophomorix)
DEFAULT_EXTRA_ATTRIBUTES = ["sophomorixSchoolname", "sophomorixAdminClass"]


@dataclass
class LDAPConfig:
    """LDAP/AD configuration."""

    server: str = ""
    port: int = 389
    use_ssl: bool = False
    bind_dn: str = ""  # Default set dynamically from smb.conf
    bind_password: str = ""
    bind_password_file: str = LINUXMUSTER_PASSWORD_FILE
    base_dn: str = ""  # Default set dynamically from smb.conf
    user_filter: str = "(sAMAccountName={username})"
    group_attribute: str = "memberOf"
    extra_attributes: list[str] = field(
        default_factory=lambda: DEFAULT_EXTRA_ATTRIBUTES.copy()
    )

    def get_bind_password(self) -> str:
        """Get bind password from file or direct config."""
        # If password is set directly, use it
        if self.bind_password:
            return self.bind_password

        # Otherwise, try to read from file
        if self.bind_password_file:
            try:
                with open(self.bind_password_file, "r", encoding="utf-8") as f:
                    return f.read().strip()
            except FileNotFoundError:
                logger.warning("Password file not found: %s", self.bind_password_file)
            except PermissionError:
                logger.error(
                    "Permission denied reading password file: %s",
                    self.bind_password_file,
                )
            except Exception as e:
                logger.error("Error reading password file: %s", e)

        return ""


@dataclass
class Action:
    """Represents an action to execute when a hook matches."""

    action_type: str
    command: list[str] = field(default_factory=list)
    url: str = ""
    reduce_payload: bool = False


@dataclass
class Hook:
    """Represents a hook configuration."""

    name: str
    matches: list[dict[str, Any]]  # List of match conditions (OR logic)
    actions: list[Action]


@dataclass
class SophosConfig:
    """Sophos XGS firewall configuration."""

    enabled: bool = False
    firewall_url: str = ""
    api_username: str = ""
    api_password: str = ""
    verify_ssl: bool = False
    ignored_ips: list[str] = field(default_factory=list)
    ignored_networks: list[str] = field(default_factory=list)
    internet_ad_group: str = "internet"
    blocked_ips_group: str = "BLOCKED_IPS"
    batch_interval: float = 10.0


@dataclass
class UserInfo:
    """User information from LDAP lookup."""

    groups: list[str] = field(default_factory=list)
    school: str = ""
    admin_class: str = ""


class UserInfoCache:
    """Simple TTL cache for user information from LDAP."""

    def __init__(self, ttl: int = GROUP_CACHE_TTL):
        self.ttl = ttl
        self._cache: dict[str, tuple[float, UserInfo]] = {}

    def get(self, username: str) -> UserInfo | None:
        """Get cached user info, or None if not cached/expired."""
        if username in self._cache:
            timestamp, user_info = self._cache[username]
            if time.time() - timestamp < self.ttl:
                return user_info
            del self._cache[username]
        return None

    def set(self, username: str, user_info: UserInfo) -> None:
        """Cache user info."""
        self._cache[username] = (time.time(), user_info)

    def clear(self) -> None:
        """Clear the cache."""
        self._cache.clear()


class SophosIPBatcher:
    """
    Collects IP changes and sends them in batches to Sophos.

    This reduces API load by collecting changes over a configurable interval
    and then sending a single update request with all changes.
    """

    def __init__(self, config: SophosConfig, loop: asyncio.AbstractEventLoop):
        self.config = config
        self.loop = loop
        self._ips_to_block: set[str] = set()
        self._ips_to_unblock: set[str] = set()
        self._lock = asyncio.Lock()
        self._flush_task: asyncio.Task | None = None

    async def block_ip(self, ip: str) -> None:
        """Add IP to the blocked list."""
        async with self._lock:
            self._ips_to_unblock.discard(ip)
            self._ips_to_block.add(ip)
            self._schedule_flush()

    async def unblock_ip(self, ip: str) -> None:
        """Remove IP from the blocked list."""
        async with self._lock:
            self._ips_to_block.discard(ip)
            self._ips_to_unblock.add(ip)
            self._schedule_flush()

    def _schedule_flush(self) -> None:
        """Schedule a flush after batch_interval seconds."""
        if self._flush_task is None or self._flush_task.done():
            self._flush_task = self.loop.create_task(self._delayed_flush())

    async def _delayed_flush(self) -> None:
        """Wait for batch_interval and then flush."""
        await asyncio.sleep(self.config.batch_interval)
        await self.flush()

    async def flush(self) -> None:
        """Send all collected changes to Sophos."""
        async with self._lock:
            if not self._ips_to_block and not self._ips_to_unblock:
                return

            ips_to_block = self._ips_to_block.copy()
            ips_to_unblock = self._ips_to_unblock.copy()
            self._ips_to_block.clear()
            self._ips_to_unblock.clear()

        await self.loop.run_in_executor(
            None, self._sync_to_sophos, ips_to_block, ips_to_unblock
        )

    def _sync_to_sophos(self, ips_to_block: set[str], ips_to_unblock: set[str]) -> None:
        """Synchronize changes with Sophos (runs in thread pool)."""
        if not sophos_ensure_group_exists(
            self.config, self.config.blocked_ips_group, "Blocked IPs"
        ):
            logger.error("Sophos: Failed to ensure BLOCKED_IPS group exists")
            return

        exists, current_hosts = sophos_check_group_exists(
            self.config, self.config.blocked_ips_group
        )
        if not exists:
            logger.error("Sophos: BLOCKED_IPS group does not exist")
            return

        current_set = set(current_hosts)
        new_set = (current_set | ips_to_block) - ips_to_unblock

        if new_set == current_set:
            logger.debug("Sophos: No changes needed")
            return

        group_xml = sophos_build_iphost_group_xml(
            self.config.blocked_ips_group, "Blocked IPs", hosts=list(new_set)
        )
        request_xml = sophos_build_request_xml(
            self.config.api_username, self.config.api_password, "update", group_xml
        )
        success, message = sophos_call_api(
            self.config.firewall_url, request_xml, self.config.verify_ssl
        )

        if success:
            logger.info(
                "Sophos: BLOCKED_IPS updated (+%d, -%d IPs)",
                len(ips_to_block),
                len(ips_to_unblock),
            )
        else:
            logger.error("Sophos: Failed to update BLOCKED_IPS: %s", message)


class LDAPClient:
    """LDAP client for Active Directory queries."""

    def __init__(self, config: LDAPConfig):
        self.config = config
        self.cache = UserInfoCache()
        self._server: Server | None = None
        self._connection: Connection | None = None

    def _get_connection(self) -> Connection | None:
        """Get or create LDAP connection."""
        if not self.config.server:
            return None

        try:
            if self._connection is None or self._connection.closed:
                self._server = Server(
                    self.config.server,
                    port=self.config.port,
                    use_ssl=self.config.use_ssl,
                    get_info=ALL,
                )
                self._connection = Connection(
                    self._server,
                    user=self.config.bind_dn,
                    password=self.config.get_bind_password(),
                    auto_bind=True,
                    read_only=True,
                )
                logger.info("LDAP connection established to %s", self.config.server)
            return self._connection
        except LDAPException as e:
            logger.error("LDAP connection failed: %s", e)
            self._connection = None
            return None

    def _extract_group_name(self, dn: str) -> str:
        """Extract group name from DN (e.g., 'CN=GroupName,OU=Groups,...' -> 'GroupName')."""
        if dn.startswith("CN="):
            return dn.split(",")[0][3:]
        return dn

    def _get_attr_value(self, entry: Any, attr_name: str) -> str:
        """Safely extract a single-value attribute from LDAP entry."""
        attr = getattr(entry, attr_name, None)
        if attr is None:
            return ""
        if hasattr(attr, "value"):
            return str(attr.value) if attr.value else ""
        if hasattr(attr, "values") and attr.values:
            return str(attr.values[0])
        return str(attr) if attr else ""

    def get_user_info(self, username: str) -> UserInfo:
        """Get user information including groups and extra attributes."""
        if not username or not self.config.server:
            return UserInfo()

        # Check cache first
        cached = self.cache.get(username)
        if cached is not None:
            logger.debug(
                "Cache hit for user %s: %d groups", username, len(cached.groups)
            )
            return cached

        conn = self._get_connection()
        if not conn:
            return UserInfo()

        try:
            # Build search filter
            search_filter = self.config.user_filter.format(username=username)

            # Build attribute list (groups + extra attributes)
            attributes = [self.config.group_attribute] + self.config.extra_attributes

            # Search for user
            conn.search(
                search_base=self.config.base_dn,
                search_filter=search_filter,
                attributes=attributes,
            )

            if not conn.entries:
                logger.debug("User %s not found in AD", username)
                empty_info = UserInfo()
                self.cache.set(username, empty_info)
                return empty_info

            user_entry = conn.entries[0]

            # Extract group memberships
            group_dns = getattr(user_entry, self.config.group_attribute, [])
            if hasattr(group_dns, "values"):
                group_dns = group_dns.values
            groups = [self._extract_group_name(str(dn)) for dn in group_dns]

            # Extract extra attributes (sophomorix fields)
            school = self._get_attr_value(user_entry, "sophomorixSchoolname")
            admin_class = self._get_attr_value(user_entry, "sophomorixAdminClass")

            user_info = UserInfo(
                groups=groups,
                school=school,
                admin_class=admin_class,
            )

            logger.debug(
                "User %s: %d groups, school=%s, class=%s",
                username,
                len(groups),
                school,
                admin_class,
            )
            self.cache.set(username, user_info)
            return user_info

        except LDAPException as e:
            logger.error("LDAP search failed for user %s: %s", username, e)
            # Invalidate connection on error
            self._connection = None
            return UserInfo()

    def get_user_groups(self, username: str) -> list[str]:
        """Get group memberships for a user (convenience method)."""
        return self.get_user_info(username).groups

    def close(self) -> None:
        """Close LDAP connection."""
        if self._connection:
            try:
                self._connection.unbind()
            except Exception:
                pass
            self._connection = None


class Config:
    """Manages hook configuration."""

    def __init__(self, config_path: str):
        self.config_path = Path(config_path)
        self.edulution_enabled: bool = True
        self.edulution_url: str = ""
        self.edulution_api_key: str = ""
        self.sophos: SophosConfig = SophosConfig()
        self.ldap: LDAPConfig = LDAPConfig()
        self.hooks: list[Hook] = []
        self.load()

    def load(self) -> None:
        """Load configuration from file."""
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Load Edulution server settings
            edulution_data = data.get("edulution", {})
            # Support both old flat format and new nested format
            if edulution_data:
                self.edulution_enabled = edulution_data.get("enabled", True)
                self.edulution_url = edulution_data.get("url", "")
                self.edulution_api_key = edulution_data.get("api_key", "")
            else:
                # Backwards compatibility with old format
                self.edulution_enabled = True
                self.edulution_url = data.get("edulution_url", "")
                self.edulution_api_key = data.get("edulution_api_key", "")

            if self.edulution_enabled and self.edulution_url:
                logger.info("Edulution sync enabled: %s", self.edulution_url)
            elif not self.edulution_enabled:
                logger.info("Edulution sync disabled")
            else:
                logger.warning("No edulution URL configured, sync disabled")

            # Load Sophos firewall settings
            sophos_data = data.get("sophos", {})
            self.sophos = SophosConfig(
                enabled=sophos_data.get("enabled", False),
                firewall_url=sophos_data.get("firewall_url", ""),
                api_username=sophos_data.get("api_username", ""),
                api_password=sophos_data.get("api_password", ""),
                verify_ssl=sophos_data.get("verify_ssl", False),
                ignored_ips=sophos_data.get("ignored_ips", []),
                ignored_networks=sophos_data.get("ignored_networks", []),
                internet_ad_group=sophos_data.get("internet_ad_group", "internet"),
                blocked_ips_group=sophos_data.get("blocked_ips_group", "BLOCKED_IPS"),
                batch_interval=sophos_data.get("batch_interval", 10.0),
            )

            if self.sophos.enabled and self.sophos.firewall_url:
                logger.info("Sophos sync enabled: %s", self.sophos.firewall_url)
            elif self.sophos.enabled:
                logger.warning("Sophos enabled but no firewall_url configured")

            # Load LDAP/AD settings (with dynamic defaults from smb.conf)
            ldap_data = data.get("ldap", {})

            # Get dynamic defaults from smb.conf realm
            default_base_dn = get_default_base_dn()
            default_bind_dn = get_default_bind_dn()

            self.ldap = LDAPConfig(
                server=ldap_data.get("server", LINUXMUSTER_LDAP_SERVER),
                port=ldap_data.get("port", 389),
                use_ssl=ldap_data.get("use_ssl", False),
                bind_dn=ldap_data.get("bind_dn", default_bind_dn),
                bind_password=ldap_data.get("bind_password", ""),
                bind_password_file=ldap_data.get(
                    "bind_password_file", LINUXMUSTER_PASSWORD_FILE
                ),
                base_dn=ldap_data.get("base_dn", default_base_dn),
                user_filter=ldap_data.get("user_filter", "(sAMAccountName={username})"),
                group_attribute=ldap_data.get("group_attribute", "memberOf"),
                extra_attributes=ldap_data.get(
                    "extra_attributes", DEFAULT_EXTRA_ATTRIBUTES.copy()
                ),
            )

            if self.ldap.server:
                logger.info(
                    "LDAP enabled: %s (base_dn: %s)",
                    self.ldap.server,
                    self.ldap.base_dn,
                )
            else:
                logger.info("LDAP not configured, group lookup disabled")

            # Load custom hooks
            self.hooks = []
            for hook_data in data.get("hooks", []):
                actions = []
                for action_data in hook_data.get("actions", []):
                    actions.append(
                        Action(
                            action_type=action_data.get("type", ""),
                            command=action_data.get("command", []),
                            url=action_data.get("url", ""),
                            reduce_payload=action_data.get("reduce_payload", False),
                        )
                    )

                # Support both "match" (single) and "matches" (multiple)
                matches = hook_data.get("matches", [])
                if not matches:
                    # Backwards compatibility: convert single "match" to list
                    single_match = hook_data.get("match", {})
                    if single_match:
                        matches = [single_match]

                self.hooks.append(
                    Hook(
                        name=hook_data.get("name", "unnamed"),
                        matches=matches,
                        actions=actions,
                    )
                )
            logger.info(
                "Loaded config: %d custom hooks from %s",
                len(self.hooks),
                self.config_path,
            )

        except FileNotFoundError:
            logger.error("Config file not found: %s", self.config_path)
            self.hooks = []
        except json.JSONDecodeError as e:
            logger.error("Invalid JSON in config file: %s", e)
        except Exception as e:
            logger.error("Error loading config: %s", e)


class ConfigWatcher(FileSystemEventHandler):
    """Watches config file for changes and triggers reload."""

    def __init__(self, config: Config, ldap_client: LDAPClient):
        self.config = config
        self.ldap_client = ldap_client
        self._debounce_task: asyncio.Task | None = None
        self._loop: asyncio.AbstractEventLoop | None = None

    def set_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Set the event loop for async operations."""
        self._loop = loop

    def on_modified(self, event) -> None:
        """Handle file modification events."""
        if event.src_path == str(self.config.config_path):
            logger.info("Config file changed, reloading...")
            if self._loop:
                self._loop.call_soon_threadsafe(self._reload_config)

    def _reload_config(self) -> None:
        """Reload config and reset LDAP client."""
        self.config.load()
        self.ldap_client.config = self.config.ldap
        self.ldap_client.cache.clear()
        self.ldap_client.close()


def get_nested_value(data: dict, key_path: str) -> Any:
    """
    Get a nested value from a dict using dot notation.

    Example: get_nested_value(data, "Authentication.eventId")
    """
    keys = key_path.split(".")
    value = data
    for key in keys:
        if isinstance(value, dict) and key in value:
            value = value[key]
        else:
            return None
    return value


def matches_single(event: dict, match: dict[str, Any]) -> bool:
    """Check if an event matches a single match criteria (AND logic within match)."""
    for key_path, expected_value in match.items():
        actual_value = get_nested_value(event, key_path)
        if actual_value != expected_value:
            return False
    return True


def matches_hook(event: dict, hook: Hook) -> bool:
    """Check if an event matches any of the hook's match criteria (OR logic)."""
    # If no matches defined, match ALL events
    if not hook.matches:
        return True
    # OR logic: match if ANY of the match conditions is satisfied
    for match in hook.matches:
        if matches_single(event, match):
            return True
    return False


def extract_username(account: str) -> str:
    """
    Extract username from account string.

    Handles various formats:
    - "netzint1" -> "netzint1"
    - "CN=netzint1,OU=Students,..." -> "netzint1"
    - "<GUID=...>;<SID=...>;CN=netzint1,OU=..." -> "netzint1"
    """
    if not account:
        return ""

    # Handle format with GUID/SID prefix: <GUID=...>;<SID=...>;CN=...
    if account.startswith("<"):
        # Find the CN= part after the prefixes
        cn_index = account.upper().find(";CN=")
        if cn_index != -1:
            account = account[cn_index + 1 :]  # Skip the semicolon

    # If it's a DN (contains CN=), extract the CN value
    if account.upper().startswith("CN="):
        # Extract CN value (everything before the first comma)
        cn_part = account.split(",")[0]
        # Remove the "CN=" prefix
        return cn_part[3:]

    return account


def extract_usernames_from_event(event: dict) -> list[str]:
    """
    Extract all usernames from an event.

    For Authentication events: extracts clientAccount
    For dsdbChange events: extracts from dn and member attributes
    For passwordChange events: extracts from dn

    Returns a list of unique usernames found.
    """
    usernames = set()

    # Authentication events
    auth = event.get("Authentication", {})
    if auth:
        account = auth.get("clientAccount", "")
        if account:
            username = extract_username(account)
            if username and not username.endswith("$"):
                usernames.add(username)

    # dsdbChange events
    dsdb = event.get("dsdbChange", {})
    if dsdb:
        # Extract from member attribute (users being added/removed from groups)
        # These are the actual users we want to look up
        attributes = dsdb.get("attributes", {})
        member = attributes.get("member", {})
        actions = member.get("actions", [])
        member_users = []
        for action in actions:
            values = action.get("values", [])
            for val in values:
                value = val.get("value", "")
                if value:
                    username = extract_username(value)
                    if username and not username.endswith("$"):
                        member_users.append(username)

        if member_users:
            # If there are member changes, only use those users (not the group dn)
            usernames.update(member_users)
        else:
            # No member changes - extract from dn (e.g., user modification)
            dn = dsdb.get("dn", "")
            if dn:
                username = extract_username(dn)
                if username and not username.endswith("$"):
                    usernames.add(username)

    # passwordChange events
    pwd_change = event.get("passwordChange", {})
    if pwd_change:
        dn = pwd_change.get("dn", "")
        if dn:
            username = extract_username(dn)
            if username and not username.endswith("$"):
                usernames.add(username)

    return list(usernames)


def extract_remote_ip(remote: str) -> str:
    """Extract IP address from format 'ipv4:10.0.0.3:36370' or 'ipv6:::1:47628'."""
    if not remote:
        return ""
    if remote.startswith("ipv4:"):
        parts = remote.split(":")
        if len(parts) >= 2:
            return parts[1]
    elif remote.startswith("ipv6:"):
        # IPv6 format: ipv6:::1:47628 (::1 with port 47628)
        parts = remote.split(":")
        if len(parts) >= 2:
            # Reconstruct IPv6 without the prefix and port
            return ":".join(parts[1:-1]) if len(parts) > 2 else parts[1]
    return remote


def reduce_event(
    event: dict,
    groups: list[str] | None = None,
    user_info: UserInfo | None = None,
) -> dict:
    """
    Reduce an event to essential fields for Edulution and webhook payloads.

    Returns a simplified structure with:
    - timestamp
    - type (event type)
    - user (username or affected user)
    - workstation (for Authentication)
    - remote (IP address)
    - service (for Authentication)
    - status
    - eventId (for Authentication)
    - operation (for dsdbChange)
    - action (for passwordChange)
    - dn (for dsdbChange/passwordChange)
    - affectedUsers (for group membership changes)
    - groups (AD group memberships, if available)
    """
    event_type = event.get("type", "")
    result = {
        "timestamp": event.get("timestamp", ""),
        "type": event_type,
    }

    # Handle Authentication events
    auth = event.get("Authentication", {})
    if auth:
        domain = auth.get("clientDomain", "")
        account = extract_username(auth.get("clientAccount", ""))
        result["user"] = f"{domain}\\{account}" if domain and account else account
        result["workstation"] = auth.get("workstation", "")
        result["remote"] = extract_remote_ip(auth.get("remoteAddress", ""))
        result["service"] = auth.get("serviceDescription", "")
        result["status"] = auth.get("status", "")
        result["eventId"] = auth.get("eventId", 0)

    # Handle dsdbChange events
    dsdb = event.get("dsdbChange", {})
    if dsdb:
        dn = dsdb.get("dn", "")
        dn_name = extract_username(dn)
        result["dn"] = dn
        result["operation"] = dsdb.get("operation", "")
        result["status"] = dsdb.get("status", "")
        result["remote"] = extract_remote_ip(dsdb.get("remoteAddress", ""))

        # Extract affected users from member attribute (group changes)
        attributes = dsdb.get("attributes", {})
        member = attributes.get("member", {})
        actions = member.get("actions", [])
        affected_users = []
        for action in actions:
            action_type = action.get("action", "")
            values = action.get("values", [])
            for val in values:
                value = val.get("value", "")
                if value:
                    username = extract_username(value)
                    if username:
                        affected_users.append(
                            {
                                "action": action_type,
                                "user": username,
                            }
                        )

        if affected_users:
            # DN is a group (has member changes)
            result["group"] = dn_name
            result["affectedUsers"] = affected_users
        else:
            # DN is a user/object being modified
            result["user"] = dn_name

    # Handle passwordChange events
    pwd_change = event.get("passwordChange", {})
    if pwd_change:
        dn = pwd_change.get("dn", "")
        result["user"] = extract_username(dn)
        result["dn"] = dn
        result["action"] = pwd_change.get("action", "")
        result["remote"] = extract_remote_ip(pwd_change.get("remoteAddress", ""))

    if groups is not None:
        result["groups"] = groups

    # Add user_info fields if provided
    if user_info is not None:
        if user_info.school:
            result["school"] = user_info.school
        if user_info.admin_class:
            result["class"] = user_info.admin_class

    return result


async def lookup_user_info(
    event: dict, ldap_client: LDAPClient, loop: asyncio.AbstractEventLoop
) -> tuple[UserInfo, list[str]]:
    """
    Look up user info from AD (runs in thread pool to avoid blocking).

    Returns a tuple of (UserInfo, list of usernames found in event).
    For events with multiple users (e.g., group membership changes),
    the UserInfo is for the first user found.
    """
    if not ldap_client.config.server:
        return UserInfo(), []

    # Extract all usernames from the event
    usernames = extract_usernames_from_event(event)

    if not usernames:
        return UserInfo(), []

    # Look up info for the first user
    primary_username = usernames[0]

    try:
        user_info = await loop.run_in_executor(
            None, ldap_client.get_user_info, primary_username
        )
        return user_info, usernames
    except Exception as e:
        logger.error("Error looking up user info for %s: %s", primary_username, e)
        return UserInfo(), usernames


# =============================================================================
# Sophos XGS Firewall Integration
# =============================================================================


def sophos_build_iphost_group_xml(
    name: str, description: str = "", hosts: list[str] | None = None
) -> str:
    """Build XML for an IPHostGroup."""
    hosts_xml = ""
    if hosts:
        hosts_xml = (
            "<HostList>" + "".join(f"<Host>{h}</Host>" for h in hosts) + "</HostList>"
        )
    return f"""
    <IPHostGroup>
        <Name>{name}</Name>
        <Description>{description}</Description>
        {hosts_xml}
    </IPHostGroup>
    """.strip()


def sophos_build_request_xml(
    username: str, password: str, action: str, entity_xml: str
) -> str:
    """Build the full API request XML."""
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <Login>
        <Username>{username}</Username>
        <Password>{password}</Password>
    </Login>
    <{action.capitalize()}>
        {entity_xml}
    </{action.capitalize()}>
</Request>"""


def sophos_build_get_request_xml(
    username: str, password: str, entity_type: str, filter_name: str | None = None
) -> str:
    """Build XML for a GET request."""
    filter_xml = ""
    if filter_name:
        filter_xml = (
            f"<Filter><key name='Name' criteria='='>{filter_name}</key></Filter>"
        )
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <Login>
        <Username>{username}</Username>
        <Password>{password}</Password>
    </Login>
    <Get>
        <{entity_type}>{filter_xml}</{entity_type}>
    </Get>
</Request>"""


def sophos_call_api(
    firewall_url: str, request_xml: str, verify_ssl: bool = False
) -> tuple[bool, str]:
    """Call the Sophos XGS API."""
    api_endpoint = f"{firewall_url}/webconsole/APIController"
    try:
        response = requests.post(
            api_endpoint,
            data={"reqxml": request_xml},
            verify=verify_ssl,
            timeout=30,
        )
        try:
            root = ET.fromstring(response.text)
            login_status = root.find(".//Login/status")
            if (
                login_status is not None
                and login_status.text != "Authentication Successful"
            ):
                return False, f"Authentication failed: {login_status.text}"
            status = root.find(".//Status")
            if status is not None:
                code = status.get("code", "")
                if code == "200":
                    return True, "Success"
                elif code == "502":
                    return False, "Already exists"
                else:
                    return False, f"Error {code}: {status.text or 'Unknown'}"
            return True, "Operation completed"
        except ET.ParseError:
            return False, f"Invalid XML response: {response.text[:200]}"
    except requests.exceptions.Timeout:
        return False, "Request timeout"
    except requests.exceptions.ConnectionError as e:
        return False, f"Connection error: {e}"
    except Exception as e:
        return False, f"Unexpected error: {e}"


def sophos_check_group_exists(
    config: SophosConfig, group_name: str
) -> tuple[bool, list[str]]:
    """Check if an IPHostGroup exists and return its current members."""
    request_xml = sophos_build_get_request_xml(
        config.api_username, config.api_password, "IPHostGroup", group_name
    )
    try:
        response = requests.post(
            f"{config.firewall_url}/webconsole/APIController",
            data={"reqxml": request_xml},
            verify=config.verify_ssl,
            timeout=30,
        )
        root = ET.fromstring(response.text)
        group = root.find(".//IPHostGroup")
        if group is not None:
            hosts = [h.text for h in group.findall(".//HostList/Host") if h.text]
            return True, hosts
        return False, []
    except Exception as e:
        logger.error("Error checking IPHostGroup %s: %s", group_name, e)
        return False, []


def sophos_ensure_group_exists(
    config: SophosConfig, group_name: str, description: str = ""
) -> bool:
    """Ensure an IPHostGroup exists, creating it if necessary."""
    exists, _ = sophos_check_group_exists(config, group_name)
    if exists:
        return True
    group_xml = sophos_build_iphost_group_xml(group_name, description)
    request_xml = sophos_build_request_xml(
        config.api_username, config.api_password, "add", group_xml
    )
    success, message = sophos_call_api(
        config.firewall_url, request_xml, config.verify_ssl
    )
    if success:
        logger.info("Sophos: Created IPHostGroup %s", group_name)
        return True
    logger.error("Sophos: Failed to create IPHostGroup %s: %s", group_name, message)
    return False


def sophos_is_ip_ignored(ip_address: str, config: SophosConfig) -> bool:
    """Check if IP should be ignored."""
    if ip_address in config.ignored_ips:
        return True
    try:
        ip_obj = ipaddress.ip_address(ip_address)
        for network in config.ignored_networks:
            try:
                net_obj = ipaddress.ip_network(network, strict=False)
                if ip_obj in net_obj:
                    return True
            except ValueError:
                if ip_address.startswith(network.rstrip(".")):
                    return True
    except ValueError:
        pass
    return False


def sophos_extract_ip(event: dict) -> str | None:
    """Extract IP address from authentication event."""
    auth = event.get("Authentication", {})
    remote = auth.get("remoteAddress", "")
    if remote.startswith("ipv4:") or remote.startswith("ipv6:"):
        parts = remote.split(":")
        return ":".join(parts[1:-1]) if len(parts) > 2 else parts[1]
    return remote if remote else None


async def sync_to_sophos(
    event: dict,
    user_info: UserInfo,
    config: Config,
    sophos_batcher: SophosIPBatcher | None,
) -> None:
    """
    Handle Sophos sync for login events.

    Users without the internet AD group will have their IP added to BLOCKED_IPS.
    Users with the internet AD group will have their IP removed from BLOCKED_IPS.
    Changes are batched and sent to Sophos after the configured interval.
    """
    if not config.sophos.enabled or sophos_batcher is None:
        return

    # Only process successful logins
    auth = event.get("Authentication", {})
    if auth.get("eventId") != 4624 or auth.get("status") != "NT_STATUS_OK":
        return

    ip_address = sophos_extract_ip(event)
    if not ip_address or sophos_is_ip_ignored(ip_address, config.sophos):
        return

    # Check if user has internet access
    user_groups_lower = [g.lower() for g in user_info.groups]
    has_internet = config.sophos.internet_ad_group.lower() in user_groups_lower

    user = extract_username(auth.get("clientAccount", ""))

    if has_internet:
        logger.debug(
            "Sophos: User %s has internet, removing IP %s from blocked list",
            user,
            ip_address,
        )
        await sophos_batcher.unblock_ip(ip_address)
    else:
        logger.debug(
            "Sophos: User %s blocked, adding IP %s to blocked list", user, ip_address
        )
        await sophos_batcher.block_ip(ip_address)


# =============================================================================
# Edulution Server Sync
# =============================================================================


async def push_to_edulution(
    event: dict,
    groups: list[str],
    user_info: UserInfo,
    config: Config,
    session: aiohttp.ClientSession,
) -> None:
    """Push login events to Edulution server."""
    if not config.edulution_enabled or not config.edulution_url:
        return

    # Only send successful logins to Edulution
    auth = event.get("Authentication", {})
    if auth.get("eventId") != 4624 or auth.get("status") != "NT_STATUS_OK":
        return

    payload = reduce_event(event, groups, user_info)
    headers = {"Content-Type": "application/json"}

    if config.edulution_api_key:
        headers["Authorization"] = f"Bearer {config.edulution_api_key}"

    try:
        async with session.post(
            config.edulution_url,
            json=payload,
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=30),
        ) as response:
            if response.status >= 400:
                logger.warning(
                    "Edulution push failed with status %d: %s",
                    response.status,
                    await response.text(),
                )
            else:
                logger.debug("Event pushed to Edulution successfully")

    except aiohttp.ClientError as e:
        logger.error("Edulution push error: %s", e)
    except Exception as e:
        logger.error("Unexpected error pushing to Edulution: %s", e)


def extract_affected_users(event: dict) -> list[dict] | None:
    """Extract affected users from dsdbChange member attribute changes."""
    dsdb = event.get("dsdbChange", {})
    if not dsdb:
        return None

    attributes = dsdb.get("attributes", {})
    member = attributes.get("member", {})
    actions = member.get("actions", [])

    affected_users = []
    for action in actions:
        action_type = action.get("action", "")
        values = action.get("values", [])
        for val in values:
            value = val.get("value", "")
            if value:
                username = extract_username(value)
                if username:
                    affected_users.append(
                        {
                            "action": action_type,
                            "user": username,
                        }
                    )

    return affected_users if affected_users else None


def enrich_full_event(event: dict, groups: list[str], user_info: UserInfo) -> dict:
    """Add computed fields to a full event payload."""
    enriched = event.copy()
    enriched["_groups"] = groups
    enriched["_school"] = user_info.school
    enriched["_class"] = user_info.admin_class

    # Add affected users for dsdbChange events
    affected_users = extract_affected_users(event)
    if affected_users:
        enriched["_affectedUsers"] = affected_users

    return enriched


async def execute_script(
    action: Action, event: dict, groups: list[str], user_info: UserInfo
) -> None:
    """Execute a script action asynchronously."""
    if not action.command:
        logger.warning("Script action has no command defined")
        return

    if action.reduce_payload:
        payload = json.dumps(reduce_event(event, groups, user_info))
    else:
        payload = json.dumps(enrich_full_event(event, groups, user_info))

    try:
        process = await asyncio.create_subprocess_exec(
            *action.command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        stdout, stderr = await process.communicate(input=payload.encode())

        if process.returncode != 0:
            logger.warning(
                "Script %s exited with code %d: %s",
                action.command[0],
                process.returncode,
                stderr.decode().strip(),
            )
        else:
            logger.debug("Script %s executed successfully", action.command[0])

    except FileNotFoundError:
        logger.error("Script not found: %s", action.command[0])
    except Exception as e:
        logger.error("Error executing script %s: %s", action.command[0], e)


async def execute_webhook(
    action: Action,
    event: dict,
    groups: list[str],
    user_info: UserInfo,
    session: aiohttp.ClientSession,
) -> None:
    """Execute a webhook action."""
    if not action.url:
        logger.warning("Webhook action has no URL defined")
        return

    if action.reduce_payload:
        payload = reduce_event(event, groups, user_info)
    else:
        payload = enrich_full_event(event, groups, user_info)

    try:
        async with session.post(
            action.url,
            json=payload,
            timeout=aiohttp.ClientTimeout(total=30),
        ) as response:
            if response.status >= 400:
                logger.warning(
                    "Webhook %s returned status %d", action.url, response.status
                )
            else:
                logger.debug("Webhook %s called successfully", action.url)

    except aiohttp.ClientError as e:
        logger.error("Webhook error for %s: %s", action.url, e)
    except Exception as e:
        logger.error("Unexpected error calling webhook %s: %s", action.url, e)


async def process_event(
    event: dict,
    config: Config,
    ldap_client: LDAPClient,
    session: aiohttp.ClientSession,
    loop: asyncio.AbstractEventLoop,
    sophos_batcher: SophosIPBatcher | None = None,
) -> None:
    """Process a single event: lookup user info, sync to services, run hooks."""
    # First, look up user info from AD (includes groups and extra attributes)
    user_info, usernames = await lookup_user_info(event, ldap_client, loop)
    groups = user_info.groups

    # Log extracted usernames for dsdbChange events
    event_type = event.get("type", "")
    if usernames and event_type != "Authentication":
        logger.debug("Extracted usernames from %s event: %s", event_type, usernames)

    tasks = []

    # Push to Edulution (if enabled)
    if config.edulution_enabled and config.edulution_url:
        tasks.append(push_to_edulution(event, groups, user_info, config, session))

    # Sync to Sophos firewall (if enabled)
    if config.sophos.enabled:
        tasks.append(sync_to_sophos(event, user_info, config, sophos_batcher))

    # Run custom hooks
    for hook in config.hooks:
        if matches_hook(event, hook):
            logger.info("Event matched custom hook: %s", hook.name)

            for action in hook.actions:
                if action.action_type == "script":
                    tasks.append(execute_script(action, event, groups, user_info))
                elif action.action_type == "webhook":
                    tasks.append(
                        execute_webhook(action, event, groups, user_info, session)
                    )
                else:
                    logger.warning("Unknown action type: %s", action.action_type)

    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)


def read_journal_events(reader: journal.Reader):
    """Generator that yields parsed JSON events from journal."""
    while True:
        entry = reader.get_next()
        if not entry:
            break

        message = entry.get("MESSAGE", "")
        unit = entry.get("_SYSTEMD_UNIT", "unknown")
        logger.debug("Raw journal entry from %s: %s...", unit, str(message)[:80])

        if not message:
            continue

        # Try to parse as JSON
        try:
            if isinstance(message, bytes):
                message = message.decode("utf-8")
            event = json.loads(message)
            logger.debug("Parsed JSON event: type=%s", event.get("type", "unknown"))
            yield event
        except json.JSONDecodeError:
            # Not a JSON message, skip
            continue


async def journal_reader_loop(
    config: Config,
    ldap_client: LDAPClient,
    shutdown_event: asyncio.Event,
    sophos_batcher: SophosIPBatcher | None = None,
) -> None:
    """Main loop that reads journal and processes events."""
    reader = journal.Reader()

    # Filter for Samba units
    for unit in SAMBA_UNITS:
        logger.info("Adding journal filter for unit: %s", unit)
        reader.add_match(_SYSTEMD_UNIT=unit)

    # Seek to end to only process new events
    reader.seek_tail()
    reader.get_previous()

    logger.info("Started watching journal for Samba events (units: %s)", SAMBA_UNITS)

    loop = asyncio.get_running_loop()

    async with aiohttp.ClientSession() as session:
        while not shutdown_event.is_set():
            # Wait for new entries (with timeout to allow shutdown check)
            change = reader.wait(timeout=1.0)

            if change == journal.APPEND:
                logger.debug("Journal has new entries")
                event_count = 0
                for event in read_journal_events(reader):
                    event_count += 1
                    await process_event(
                        event, config, ldap_client, session, loop, sophos_batcher
                    )
                if event_count > 0:
                    logger.debug("Processed %d events", event_count)

            await asyncio.sleep(0.01)  # Small yield for async

    # Flush any pending Sophos changes before shutdown
    if sophos_batcher is not None:
        logger.info("Flushing pending Sophos changes...")
        await sophos_batcher.flush()

    reader.close()
    logger.info("Journal reader stopped")


async def main(config_path: str) -> None:
    """Main entry point."""
    logger.info("Starting Edulution Event Handler")
    logger.info("Config path: %s", config_path)

    # Load configuration
    config = Config(config_path)

    # Create LDAP client
    ldap_client = LDAPClient(config.ldap)

    # Setup config file watcher
    config_watcher = ConfigWatcher(config, ldap_client)
    observer = Observer()
    observer.schedule(
        config_watcher, path=str(config.config_path.parent), recursive=False
    )
    observer.start()

    # Setup shutdown event
    shutdown_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    config_watcher.set_loop(loop)

    # Create Sophos IP batcher if enabled
    sophos_batcher: SophosIPBatcher | None = None
    if config.sophos.enabled and config.sophos.firewall_url:
        sophos_batcher = SophosIPBatcher(config.sophos, loop)
        logger.info(
            "Sophos integration enabled (batch interval: %.1fs, blocked group: %s)",
            config.sophos.batch_interval,
            config.sophos.blocked_ips_group,
        )

    def signal_handler(sig):
        logger.info("Received signal %s, shutting down...", sig)
        shutdown_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, lambda s=sig: signal_handler(s))

    try:
        await journal_reader_loop(config, ldap_client, shutdown_event, sophos_batcher)
    finally:
        ldap_client.close()
        observer.stop()
        observer.join()
        logger.info("Edulution Event Handler stopped")


if __name__ == "__main__":
    config_file = os.environ.get("EDULUTION_HOOKS_CONFIG", DEFAULT_CONFIG_PATH)

    if len(sys.argv) > 1:
        config_file = sys.argv[1]

    asyncio.run(main(config_file))
