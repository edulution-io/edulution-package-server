"""Data models used across the VDI package."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class GroupConfig:
    """Parsed content of a ``start.conf.<group>.vdi`` file."""

    activated: bool
    vmids: list[str]
    bios: str
    boot: str
    cores: int
    memory: int
    ostype: str
    name: str
    room: str
    hostname: str
    group: str
    ip: str
    storage: str
    scsihw: str
    size: int
    format: str
    bridge: str
    mac: str
    display: str
    audio: str
    usb0: str
    spice_enhancements: str
    minimum_vms: int
    maximum_vms: int
    prestarted_vms: int
    timeout_building_master: int
    timeout_building_clone: int
    tag: int = 0
    machine: str = ""
    efidisk0: str = ""
    tpmstate0: str = ""
    bootdisk: str = ""
    disk_bus: str = ""

    @classmethod
    def from_dict(cls, data: dict) -> GroupConfig:
        """Create a GroupConfig from a raw JSON dict (as stored on disk)."""
        activated = data.get("activated", False)
        if isinstance(activated, str):
            activated = activated.lower() in ("yes", "true", "1")

        vmids = data.get("vmids", [])
        if isinstance(vmids, str):
            vmids = [v.strip() for v in vmids.split(",") if v.strip()]

        return cls(
            activated=activated,
            vmids=vmids,
            bios=data["bios"],
            boot=data["boot"],
            cores=int(data["cores"]),
            memory=int(data["memory"]),
            ostype=data["ostype"],
            name=data["name"],
            room=data.get("room", ""),
            hostname=data.get("hostname", ""),
            group=data["group"],
            ip=data.get("ip", ""),
            storage=data["storage"],
            scsihw=data["scsihw"],
            size=int(data["size"]),
            format=data["format"],
            bridge=data["bridge"],
            mac=data.get("mac", ""),
            display=data.get("display", ""),
            audio=data.get("audio", ""),
            usb0=data.get("usb0", ""),
            spice_enhancements=data.get("spice_enhancements", ""),
            minimum_vms=int(data.get("minimum_vms", 0)),
            maximum_vms=int(data.get("maximum_vms", 0)),
            prestarted_vms=int(data.get("prestarted_vms", 0)),
            timeout_building_master=int(data.get("timeout_building_master", 600)),
            timeout_building_clone=int(data.get("timeout_building_clone", 300)),
            tag=int(data.get("tag", 0)),
            machine=data.get("machine", ""),
            efidisk0=data.get("efidisk0", ""),
            tpmstate0=data.get("tpmstate0", ""),
            bootdisk=data.get("bootdisk", ""),
            disk_bus=data.get("disk_bus", ""),
        )

    def to_raw_dict(self) -> dict:
        """Return the dict format expected by legacy code / Proxmox API calls."""
        d: dict = {
            "activated": self.activated,
            "vmids": self.vmids,
            "bios": self.bios,
            "boot": self.boot,
            "cores": self.cores,
            "memory": self.memory,
            "ostype": self.ostype,
            "name": self.name,
            "room": self.room,
            "hostname": self.hostname,
            "group": self.group,
            "ip": self.ip,
            "storage": self.storage,
            "scsihw": self.scsihw,
            "size": self.size,
            "format": self.format,
            "bridge": self.bridge,
            "mac": self.mac,
            "display": self.display,
            "audio": self.audio,
            "usb0": self.usb0,
            "spice_enhancements": self.spice_enhancements,
            "minimum_vms": self.minimum_vms,
            "maximum_vms": self.maximum_vms,
            "prestarted_vms": self.prestarted_vms,
            "timeout_building_master": self.timeout_building_master,
            "timeout_building_clone": self.timeout_building_clone,
            "tag": self.tag,
            "machine": self.machine,
            "efidisk0": self.efidisk0,
            "tpmstate0": self.tpmstate0,
            "bootdisk": self.bootdisk,
            "disk_bus": self.disk_bus,
        }
        return d


@dataclass
class DeviceEntry:
    """One row from ``devices.csv``."""

    room: str
    hostname: str
    group: str
    mac: str
    ip: str
    field5: str = ""
    field6: str = ""
    field7: str = ""
    field8: str = ""
    field9: str = ""
    pxe: str = ""
    vmid: str = ""

    @classmethod
    def from_row(cls, row: list[str]) -> DeviceEntry:
        def _get(idx: int) -> str:
            return row[idx] if idx < len(row) else ""

        return cls(
            room=_get(0),
            hostname=_get(1),
            group=_get(2),
            mac=_get(3),
            ip=_get(4),
            field5=_get(5),
            field6=_get(6),
            field7=_get(7),
            field8=_get(8),
            field9=_get(9),
            pxe=_get(10),
            vmid=_get(11),
        )


@dataclass
class MasterDescription:
    """Description blob stored in the Proxmox VM description field for masters."""

    timestamp: str = ""
    imagesize: str = ""
    date_of_creation: str = ""
    buildstate: str = "building"
    group: str = ""

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "imagesize": self.imagesize,
            "dateOfCreation": self.date_of_creation,
            "buildstate": self.buildstate,
            "group": self.group,
        }

    @classmethod
    def from_dict(cls, d: dict) -> MasterDescription:
        return cls(
            timestamp=d.get("timestamp", ""),
            imagesize=d.get("imagesize", ""),
            date_of_creation=d.get("dateOfCreation", ""),
            buildstate=d.get("buildstate", "building"),
            group=d.get("group", ""),
        )


@dataclass
class CloneDescription:
    """Description blob stored in the Proxmox VM description field for clones."""

    name: str = ""
    date_of_creation: str = ""
    master: str = ""
    last_connection_request_user: str = ""
    last_connection_request_time: str = ""
    group: str = ""
    imagesize: str = ""
    image: str = ""
    buildstate: str = "building"

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "dateOfCreation": self.date_of_creation,
            "master": self.master,
            "lastConnectionRequestUser": self.last_connection_request_user,
            "lastConnectionRequestTime": self.last_connection_request_time,
            "group": self.group,
            "imagesize": self.imagesize,
            "image": self.image,
            "buildstate": self.buildstate,
        }

    @classmethod
    def from_dict(cls, d: dict) -> CloneDescription:
        return cls(
            name=d.get("name", ""),
            date_of_creation=d.get("dateOfCreation", ""),
            master=d.get("master", ""),
            last_connection_request_user=d.get("lastConnectionRequestUser", ""),
            last_connection_request_time=d.get("lastConnectionRequestTime", ""),
            group=d.get("group", ""),
            imagesize=d.get("imagesize", ""),
            image=d.get("image", ""),
            buildstate=d.get("buildstate", "building"),
        )


@dataclass
class CloneSummary:
    """Aggregate counters for clone VMs of a group."""

    allocated_vms: int = 0
    available_vms: int = 0
    existing_vms: int = 0
    registered_vms: int = 0
    building_vms: int = 0
    failed_vms: int = 0

    def to_dict(self) -> dict:
        return {
            "allocated_vms": self.allocated_vms,
            "available_vms": self.available_vms,
            "existing_vms": self.existing_vms,
            "registered_vms": self.registered_vms,
            "building_vms": self.building_vms,
            "failed_vms": self.failed_vms,
        }


@dataclass
class MasterSummary:
    """Aggregate counters for master VMs of a group."""

    existing_master: int = 0
    registered: int = 0
    building_master: int = 0
    failed_master: int = 0
    finished: int = 0

    def to_dict(self) -> dict:
        return {
            "existing_master": self.existing_master,
            "registered": self.registered,
            "building_master": self.building_master,
            "failed_master": self.failed_master,
            "finished": self.finished,
        }
