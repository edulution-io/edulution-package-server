"""CLI entry-points for edulution-linbo-vdi."""

from __future__ import annotations

import argparse
import json
import logging
import os
import subprocess
import sys
from getpass import getpass
from pathlib import Path

from .logging_config import setup_logging

_CONFIG_DIR = Path("/etc/edulution/linbo-vdi")
_CONFIG_FILE = _CONFIG_DIR / "vdiConfig.json"
_TEMPLATE_DIR = Path(__file__).resolve().parent.parent.parent / "usr" / "lib" / "edulution-linbo-vdi" / "etc"
_TEMPLATE_CONFIG = _TEMPLATE_DIR / "template-vdiConfig.json"


def _get_context(config_path: str | None = None):
    """Lazy import and create VdiContext."""
    from . import VdiContext
    return VdiContext.from_config_file(config_path)


# ------------------------------------------------------------------
# vdi-service CLI
# ------------------------------------------------------------------

def run_service() -> None:
    """Entry-point for the VDI background service."""
    setup_logging(logging.INFO)
    ctx = _get_context()
    from .service import VdiService
    VdiService(ctx).run()


# ------------------------------------------------------------------
# getVmStates CLI
# ------------------------------------------------------------------

def get_vm_states_cli() -> None:
    """Replaces the old ``getVmStates.py`` CLI."""
    setup_logging(logging.ERROR)

    parser = argparse.ArgumentParser(description="getVmStates")
    parser.add_argument("-v", dest="version", action="store_true", help="Print version and exit")
    parser.add_argument("-m", "-master", dest="master", action="store_true", help="Show master states")
    parser.add_argument("-c", "-clones", dest="clones", action="store_true", help="Show clone states")
    parser.add_argument("group", nargs="?", default="all")
    args = parser.parse_args()

    if args.version:
        print("version 1.0.0")
        sys.exit(0)

    ctx = _get_context()

    if args.master:
        from .master import MasterManager
        from . import device_store
        mgr = MasterManager(ctx)
        if args.group != "all":
            group_data = device_store.get_vdi_groups()["groups"][args.group]
            print(json.dumps(mgr.get_states(group_data, args.group), indent=2))
        else:
            print(json.dumps(mgr.get_all_states(), indent=2))
        sys.exit(0)

    if args.clones:
        from .clone import CloneManager
        from . import device_store
        mgr = CloneManager(ctx)
        if args.group != "all":
            group_data = device_store.get_vdi_groups()["groups"][args.group]
            print(json.dumps(mgr.get_states(group_data, args.group), indent=2))
        else:
            print(json.dumps(mgr.get_all_states(), indent=2))
        sys.exit(0)

    parser.print_help()
    sys.exit(0)


# ------------------------------------------------------------------
# removeClone CLI
# ------------------------------------------------------------------

def remove_clone_cli() -> None:
    """Replaces the old ``removeClone.py`` CLI."""
    setup_logging(logging.INFO)

    parser = argparse.ArgumentParser(description="removeClone")
    parser.add_argument("-v", dest="version", action="store_true")
    parser.add_argument("--everything", dest="everything", action="store_true", help="Remove every clone")
    parser.add_argument("--vm", dest="vm", action="store_true", help="Remove a specific VM")
    parser.add_argument("group", nargs="?", default="all")
    args = parser.parse_args()

    if args.version:
        print("version 1.0.0")
        sys.exit(0)

    ctx = _get_context()
    from .clone import CloneManager
    mgr = CloneManager(ctx)

    if args.vm:
        mgr._remove_vm(args.group)
        sys.exit(0)

    parser.print_help()
    sys.exit(0)


# ------------------------------------------------------------------
# vdi-setup CLI -- helpers
# ------------------------------------------------------------------

_OS_PRESETS = {
    "1": {"name": "Windows 10", "ostype": "win10", "fstype": "ntfs", "part_id": "7", "label": "windows", "version": "22H2", "kernel": "auto", "initrd": "", "icon": "win10.svg"},
    "2": {"name": "Windows 11", "ostype": "win11", "fstype": "ntfs", "part_id": "7", "label": "windows", "version": "24H2", "kernel": "auto", "initrd": "", "icon": "win11.svg"},
    "3": {"name": "Ubuntu", "ostype": "l26", "fstype": "ext4", "part_id": "83", "label": "ubuntu", "version": "24.04", "kernel": "boot/vmlinuz", "initrd": "boot/initrd.img", "icon": "ubuntu.svg"},
    "4": {"name": "Debian", "ostype": "l26", "fstype": "ext4", "part_id": "83", "label": "debian", "version": "13", "kernel": "boot/vmlinuz", "initrd": "boot/initrd.img", "icon": "debian.svg"},
}


def _prompt(label: str, default: str = "", secret: bool = False) -> str:
    """Prompt the user for input with an optional default value."""
    if secret:
        suffix = " (input hidden)" if not default else " [****] (input hidden)"
        value = getpass(f"  {label}{suffix}: ")
        return value if value else default
    if default:
        value = input(f"  {label} [{default}]: ")
        return value if value else default
    return input(f"  {label}: ")


def _prompt_bool(label: str, default: bool = True) -> bool:
    """Prompt the user for a yes/no answer."""
    hint = "Y/n" if default else "y/N"
    value = input(f"  {label} [{hint}]: ").strip().lower()
    if not value:
        return default
    return value in ("y", "yes", "j", "ja")


def _prompt_choice(label: str, options: dict[str, str], default: str = "1") -> str:
    """Prompt the user to choose from numbered options."""
    for key, desc in options.items():
        print(f"    {key}) {desc}")
    value = _prompt(label, default)
    return value if value in options else default


def _needs_sudo(path: Path) -> bool:
    """Check if we need sudo to write to the given path."""
    try:
        test_dir = path if path.is_dir() else (path.parent if path.parent.exists() else path.parent.parent)
        return not os.access(test_dir, os.W_OK)
    except OSError:
        return True


def _write_file(path: Path, content: str) -> None:
    """Write a file, using sudo if necessary."""
    if _needs_sudo(path.parent):
        subprocess.run(["sudo", "mkdir", "-p", str(path.parent)], check=True)
        subprocess.run(
            ["sudo", "tee", str(path)],
            input=content.encode(),
            stdout=subprocess.DEVNULL,
            check=True,
        )
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")


def _append_file(path: Path, content: str) -> None:
    """Append to a file, using sudo if necessary."""
    if _needs_sudo(path):
        subprocess.run(
            ["sudo", "tee", "-a", str(path)],
            input=content.encode(),
            stdout=subprocess.DEVNULL,
            check=True,
        )
    else:
        with open(path, "a", encoding="utf-8") as f:
            f.write(content)


def _increment_mac(mac: str, offset: int) -> str:
    """Increment a MAC address by offset (always lowercase)."""
    num = int(mac.replace(":", ""), 16) + offset
    h = f"{num:012x}"
    return ":".join(h[i:i + 2] for i in range(0, 12, 2))


def _increment_ip(ip: str, offset: int) -> str:
    """Increment an IP address by offset."""
    parts = [int(p) for p in ip.split(".")]
    num = (parts[0] << 24) + (parts[1] << 16) + (parts[2] << 8) + parts[3] + offset
    return f"{(num >> 24) & 0xFF}.{(num >> 16) & 0xFF}.{(num >> 8) & 0xFF}.{num & 0xFF}"


# ------------------------------------------------------------------
# vdi-setup CLI -- main entry point
# ------------------------------------------------------------------

def run_setup() -> None:
    """Interactive setup wizard for edulution-linbo-vdi."""
    print()
    print("=" * 60)
    print("  edulution-linbo-vdi -- Setup")
    print("=" * 60)
    print()

    # --- Step 1: VDI service config ---
    config_data = _setup_vdi_config()

    # --- Step 2: Test connection ---
    print()
    if _prompt_bool("Test Proxmox connection?"):
        while not _test_connection(config_data):
            if not _prompt_bool("Retry?"):
                break

    # --- Step 3: VDI groups ---
    print()
    first_group = True
    while _prompt_bool("Add a VDI group?" if first_group else "Add another VDI group?", default=first_group):
        _setup_vdi_group(config_data)
        first_group = False
        print()

    # --- Step 4: Final hints ---
    print()
    print("-" * 60)
    print("  Next steps")
    print("-" * 60)
    print()
    print("  1. Prepare the OS image:")
    print("     - Windows: allow ports 135, 445, 49665 in Firewall")
    print("     - Install QEMU Guest Agent and SPICE Guest Tools")
    print()
    print("  2. Start the service:")
    print("     uv run vdi-service")
    print()


# ------------------------------------------------------------------
# vdi-setup CLI -- VDI service config
# ------------------------------------------------------------------

def _setup_vdi_config() -> dict:
    """Set up the main VDI service config (vdiConfig.json)."""
    config_exists = _CONFIG_FILE.is_file()

    if config_exists:
        print(f"  Config found: {_CONFIG_FILE}")
        existing = json.loads(_CONFIG_FILE.read_text(encoding="utf-8"))
        if not _prompt_bool("Reconfigure?", default=False):
            print("  Keeping existing config.\n")
            return existing
        print()
        defaults = existing
    else:
        print(f"  No config found at {_CONFIG_FILE}\n")
        defaults = {}
        if _TEMPLATE_CONFIG.is_file():
            defaults = json.loads(_TEMPLATE_CONFIG.read_text(encoding="utf-8"))

    print("-" * 60)
    print("  Proxmox connection")
    print("-" * 60)
    node = _prompt("Proxmox node name", defaults.get("node", "pve01"))
    hv_ip = _prompt("Proxmox host IP", defaults.get("hvIp", ""))
    hv_user = _prompt("Proxmox API user", defaults.get("hvUser", "root@pam"))
    password = _prompt("Proxmox API password", defaults.get("password", ""), secret=True)

    print()
    print("-" * 60)
    print("  API / Advanced")
    print("-" * 60)
    multischool = _prompt_bool("Multi-school mode?", default=defaults.get("multischool", False))
    timeout = _prompt(
        "Connection request timeout (seconds)",
        str(defaults.get("timeoutConnectionRequest", 1000)),
    )
    proxy_url = _prompt("SPICE proxy URL (leave empty if none)", defaults.get("proxy_url", ""))
    api_secret = _prompt("LMN API secret", defaults.get("lmn-api-secret", ""), secret=True)
    debugging = _prompt_bool("Enable debug logging?", default=defaults.get("debugging", False))

    config_data = {
        "node": node,
        "hvIp": hv_ip,
        "hvUser": hv_user,
        "password": password,
        "nmapPorts": "135,445,49665",
        "vdiLocalService": True,
        "serverIP": "",
        "debugging": debugging,
        "multischool": multischool,
        "timeoutConnectionRequest": int(timeout),
        "proxy_url": proxy_url,
        "lmn-api-secret": api_secret,
    }

    print()
    _write_file(_CONFIG_FILE, json.dumps(config_data, indent=4, ensure_ascii=False) + "\n")
    print(f"  Config written to {_CONFIG_FILE}")
    return config_data


# ------------------------------------------------------------------
# vdi-setup CLI -- VDI group setup
# ------------------------------------------------------------------

def _fetch_storages(config_data: dict) -> list[str]:
    """Fetch available Proxmox storage names. Returns empty list on failure."""
    try:
        from .config import VdiConfig
        from .proxmox_client import ProxmoxClient

        config = VdiConfig(
            node=config_data["node"],
            hv_ip=config_data["hvIp"],
            hv_user=config_data["hvUser"],
            password=config_data["password"],
            multischool=config_data.get("multischool", False),
            timeout_connection_request=float(config_data.get("timeoutConnectionRequest", 1000)),
            vdi_local_service=config_data.get("vdiLocalService", True),
            nmap_ports=[p.strip() for p in config_data.get("nmapPorts", "").split(",") if p.strip()],
            server_ip=config_data.get("serverIP", ""),
            proxy_url=config_data.get("proxy_url", ""),
            lmn_api_secret=config_data.get("lmn-api-secret", ""),
            debugging=config_data.get("debugging", False),
        )
        client = ProxmoxClient(config)
        storages = client.get_storage_list()
        return [s["storage"] for s in storages if s.get("content", "") and "images" in s["content"]]
    except Exception:
        return []


def _prompt_storage(available: list[str], default: str) -> str:
    """Prompt user to pick a storage from available options."""
    if not available:
        return _prompt("Proxmox storage", default)
    options = {str(i + 1): name for i, name in enumerate(available)}
    print()
    print("  Available storages:")
    choice = _prompt_choice("Storage", options, default="1")
    return options.get(choice, available[0])


def _setup_vdi_group(config_data: dict) -> None:
    """Set up a single VDI group (start.conf + .vdi + devices.csv)."""
    # Fetch available storages from Proxmox
    print()
    print("  Fetching available storages from Proxmox...")
    available_storages = _fetch_storages(config_data)
    if available_storages:
        print(f"  Found: {', '.join(available_storages)}")
    else:
        print("  Could not fetch storages, manual input required.")

    print()
    print("-" * 60)
    print("  VDI group")
    print("-" * 60)
    group = _prompt("Group name", "win10-vdi")

    print()
    os_key = _prompt_choice("OS type", {
        "1": "Windows 10",
        "2": "Windows 11",
        "3": "Ubuntu",
        "4": "Debian",
    })
    os_preset = _OS_PRESETS[os_key]

    print()
    boot_key = _prompt_choice("Boot mode", {
        "1": "BIOS (SeaBIOS)",
        "2": "EFI (OVMF)",
    })
    efi = boot_key == "2"

    # Derive a sensible default image name from the group
    default_image = f"{group}.qcow2"
    base_image = _prompt("Base image filename", default_image)

    # Storage selection
    if available_storages:
        storage = _prompt_storage(available_storages, available_storages[0])
    else:
        storage = _prompt("Proxmox storage")

    # Network -- VLAN is important and easy to miss, ask upfront
    vlan_tag = _prompt("VLAN tag (leave empty if none)", "")

    # Defaults for everything else
    os_version = os_preset["version"]
    school = "default-school"
    server_ip = "10.0.0.1"
    cores = 4
    memory = 4096
    disk_size = 80
    bridge = "vmbr0"
    master_vmid = 1701
    master_ip = "10.0.0.50"
    master_mac = "aa:ee:4e:b5:5c:00"
    max_vms = 10
    min_vms = 3
    prestarted = 1

    # Show defaults summary and offer to customize
    print()
    print("  Defaults:")
    print(f"    OS version:       {os_version}")
    print(f"    School:           {school}")
    print(f"    Server IP:        {server_ip}")
    print(f"    Cores / RAM:      {cores} cores, {memory} MB")
    print(f"    Disk / Storage:   {disk_size} GB on {storage}")
    print(f"    Network:          {bridge}" + (f", VLAN {vlan_tag}" if vlan_tag else ""))
    print(f"    Master:           VMID {master_vmid}, IP {master_ip}, MAC {master_mac}")
    print(f"    Clone pool:       {min_vms}-{max_vms} VMs, {prestarted} pre-started")
    print(f"    Clone VMIDs:      {master_vmid + 100}+, IPs {master_ip.rsplit('.', 1)[0]}.201+")

    if _prompt_bool("Customize these values?", default=False):
        print()
        print("-" * 60)
        print("  General")
        print("-" * 60)
        os_version = _prompt("OS version", os_version)
        school = _prompt("School", school)
        server_ip = _prompt("linuxmuster server IP", server_ip)

        print()
        print("-" * 60)
        print("  VM specs")
        print("-" * 60)
        cores = int(_prompt("CPU cores", str(cores)))
        memory = int(_prompt("Memory in MB", str(memory)))
        disk_size = int(_prompt("Disk size in GB", str(disk_size)))
        if available_storages:
            storage = _prompt_storage(available_storages, storage)
        else:
            storage = _prompt("Proxmox storage", storage)

        print()
        print("-" * 60)
        print("  Network")
        print("-" * 60)
        bridge = _prompt("Network bridge", bridge)

        print()
        print("-" * 60)
        print("  Master VM")
        print("-" * 60)
        master_vmid = int(_prompt("Master VMID", str(master_vmid)))
        master_ip = _prompt("Master IP", master_ip)
        master_mac = _prompt("Master MAC", master_mac).lower()

        print()
        print("-" * 60)
        print("  Clone pool")
        print("-" * 60)
        max_vms = int(_prompt("Maximum VMs", str(max_vms)))
        min_vms = int(_prompt("Minimum VMs", str(min_vms)))
        prestarted = int(_prompt("Pre-started VMs", str(prestarted)))

    clone_vmid_start = master_vmid + 100
    default_clone_ip = f"{master_ip.rsplit('.', 1)[0]}.201"
    clone_ip_start = default_clone_ip

    # --- Write start.conf ---
    print()
    start_conf_path = Path(f"/srv/linbo/start.conf.{group}")
    start_conf = _generate_start_conf(
        group=group,
        server_ip=server_ip,
        school=school,
        efi=efi,
        os_preset=os_preset,
        os_version=os_version,
        base_image=base_image,
        disk_size=disk_size,
    )
    _write_file(start_conf_path, start_conf)
    print(f"  Written: {start_conf_path}")

    # --- Write .vdi config ---
    vdi_path = Path(f"/srv/linbo/start.conf.{group}.vdi")
    vdi_config = _generate_vdi_config(
        group=group,
        os_preset=os_preset,
        efi=efi,
        master_vmid=master_vmid,
        master_ip=master_ip,
        master_mac=master_mac,
        cores=cores,
        memory=memory,
        disk_size=disk_size,
        storage=storage,
        bridge=bridge,
        vlan_tag=vlan_tag,
        min_vms=min_vms,
        max_vms=max_vms,
        prestarted=prestarted,
    )
    _write_file(vdi_path, json.dumps(vdi_config, indent=4, ensure_ascii=False) + "\n")
    print(f"  Written: {vdi_path}")

    # --- Append to devices.csv ---
    if school and school not in ("default-school", ""):
        devices_path = Path(f"/etc/linuxmuster/sophomorix/{school}/{school}.devices.csv")
    else:
        devices_path = Path("/etc/linuxmuster/sophomorix/default-school/devices.csv")

    lines = _generate_devices_lines(
        group=group,
        master_mac=master_mac,
        master_ip=master_ip,
        max_vms=max_vms,
        clone_vmid_start=clone_vmid_start,
        clone_ip_start=clone_ip_start,
    )

    print()
    print("  devices.csv entries to add:")
    for line in lines.strip().splitlines()[:3]:
        print(f"    {line}")
    if max_vms > 2:
        print(f"    ... ({max_vms + 1} lines total)")
    print()

    if _prompt_bool(f"Append to {devices_path}?"):
        _append_file(devices_path, lines)
        print(f"  Appended {max_vms + 1} entries to {devices_path}")
    else:
        print("  Skipped. You can add these manually later.")


# ------------------------------------------------------------------
# vdi-setup CLI -- file generators
# ------------------------------------------------------------------

def _generate_start_conf(
    *,
    group: str,
    server_ip: str,
    school: str,
    efi: bool,
    os_preset: dict,
    os_version: str,
    base_image: str,
    disk_size: int,
) -> str:
    """Generate a LINBO start.conf file."""
    system_type = "efi64" if efi else "bios64"
    os_partition_size = disk_size - 10 if disk_size > 20 else disk_size

    lines = [
        "[LINBO]",
        f"Server = {server_ip}",
        f"Group = {group}",
    ]

    if efi:
        # EFI: sda1=ESP, sda2=OS, sda3=cache
        lines += [
            "Cache = /dev/sda3",
            "RootTimeout = 600",
            "DownloadType = rsync",
            f"SystemType = {system_type}",
            f"School = {school}",
            "KernelOptions = quiet splash forcegrub",
            "",
            "[Partition]",
            "Dev = /dev/sda1",
            "Label = efi",
            "Size = 200M",
            "Id = ef",
            "FSType = vfat",
            "Bootable = yes",
            "",
            "[Partition]",
            "Dev = /dev/sda2",
            f"Label = {os_preset['label']}",
            f"Size = {os_partition_size}G",
            f"Id = {os_preset['part_id']}",
            f"FSType = {os_preset['fstype']}",
            "",
            "[Partition]",
            "Dev = /dev/sda3",
            "Label = cache",
            "Size =",
            "Id = 83",
            "FSType = ext4",
            "",
            "[OS]",
            f"Name = {os_preset['name']}",
            f"Version = {os_version}",
            f"IconName = {os_preset['icon']}",
            f"BaseImage = {base_image}",
            "Boot = /dev/sda2",
            "Root = /dev/sda2",
            f"Kernel = {os_preset['kernel']}",
            *([ f"Initrd = {os_preset['initrd']}" ] if os_preset.get("initrd") else []),
            "StartEnabled = yes",
            "Autostart = yes",
            "AutostartTimeout = 3",
            "",
        ]
    else:
        # BIOS: sda1=OS, sda2=cache
        lines += [
            "Cache = /dev/sda2",
            "RootTimeout = 600",
            "DownloadType = rsync",
            f"SystemType = {system_type}",
            f"School = {school}",
            "KernelOptions = quiet splash",
            "",
            "[Partition]",
            "Dev = /dev/sda1",
            f"Label = {os_preset['label']}",
            f"Size = {os_partition_size}G",
            f"Id = {os_preset['part_id']}",
            f"FSType = {os_preset['fstype']}",
            "",
            "[Partition]",
            "Dev = /dev/sda2",
            "Label = cache",
            "Size =",
            "Id = 83",
            "FSType = ext4",
            "",
            "[OS]",
            f"Name = {os_preset['name']}",
            f"Version = {os_version}",
            f"IconName = {os_preset['icon']}",
            f"BaseImage = {base_image}",
            "Boot = /dev/sda1",
            "Root = /dev/sda1",
            f"Kernel = {os_preset['kernel']}",
            *([ f"Initrd = {os_preset['initrd']}" ] if os_preset.get("initrd") else []),
            "StartEnabled = yes",
            "Autostart = yes",
            "AutostartTimeout = 3",
            "",
        ]

    return "\n".join(lines)


def _generate_vdi_config(
    *,
    group: str,
    os_preset: dict,
    efi: bool,
    master_vmid: int,
    master_ip: str,
    master_mac: str,
    cores: int,
    memory: int,
    disk_size: int,
    storage: str,
    bridge: str,
    vlan_tag: str,
    min_vms: int,
    max_vms: int,
    prestarted: int,
) -> dict:
    """Generate a VDI group config dict (.vdi file)."""
    config: dict = {
        "activated": "yes",
        "vmids": [master_vmid],
    }

    if efi:
        config.update({
            "bios": "ovmf",
            "machine": "q35",
            "boot": "order=scsi0;net0",
            "bootdisk": "scsi0",
        })
    else:
        config.update({
            "bios": "seabios",
            "boot": "cn",
        })

    config.update({
        "cores": cores,
        "memory": memory,
        "ostype": os_preset["ostype"],
        "name": f"{group}-master",
        "room": "vdi",
        "hostname": "vdi-master",
        "group": group,
        "ip": master_ip,
        "storage": storage,
    })

    if efi:
        config.update({
            "scsihw": "virtio-scsi-single",
            "disk_bus": "scsi",
        })
    else:
        config["scsihw"] = "virtio-scsi-pci"

    config.update({
        "size": disk_size,
        "format": "raw",
        "bridge": bridge,
    })

    if vlan_tag:
        config["tag"] = int(vlan_tag)

    config["mac"] = master_mac

    if efi:
        config.update({
            "efidisk0": f"{storage}:1,efitype=4m,pre-enrolled-keys=0",
            "tpmstate0": f"{storage}:1,version=v2.0",
        })

    config.update({
        "display": "type=qxl,memory=16",
        "audio": "device=ich9-intel-hda,driver=spice",
        "usb0": "host=spice,usb3=1",
        "spice_enhancements": "foldersharing=1,videostreaming=all",
        "minimum_vms": min_vms,
        "maximum_vms": max_vms,
        "prestarted_vms": prestarted,
        "timeout_building_master": 750,
        "timeout_building_clone": 400,
    })

    return config


def _generate_devices_lines(
    *,
    group: str,
    master_mac: str,
    master_ip: str,
    max_vms: int,
    clone_vmid_start: int,
    clone_ip_start: str,
) -> str:
    """Generate devices.csv lines for master + clones."""
    lines = []

    # Master line (no VMID in devices.csv)
    lines.append(
        f"vdi;vdi-master;{group};{master_mac};{master_ip}"
        f";;;;classroom-studentcomputer;;1;;;;;"
    )

    # Clone lines
    for i in range(max_vms):
        clone_mac = _increment_mac(master_mac, i + 1)
        clone_ip = _increment_ip(clone_ip_start, i)
        clone_vmid = clone_vmid_start + i
        hostname = f"vdi-client{i + 1:02d}"
        lines.append(
            f"vdi;{hostname};{group};{clone_mac};{clone_ip}"
            f";;;;classroom-studentcomputer;;1;{clone_vmid};;;;"
        )

    return "\n".join(lines) + "\n"


# ------------------------------------------------------------------
# vdi-setup CLI -- connection test
# ------------------------------------------------------------------

def _test_connection(config_data: dict) -> bool:
    """Test the Proxmox connection with the given config. Returns True on success."""
    print("  Testing Proxmox connection...")
    try:
        from .config import VdiConfig
        from .proxmox_client import ProxmoxClient

        config = VdiConfig(
            node=config_data["node"],
            hv_ip=config_data["hvIp"],
            hv_user=config_data["hvUser"],
            password=config_data["password"],
            multischool=config_data.get("multischool", False),
            timeout_connection_request=float(config_data.get("timeoutConnectionRequest", 1000)),
            vdi_local_service=config_data.get("vdiLocalService", True),
            nmap_ports=[p.strip() for p in config_data.get("nmapPorts", "").split(",") if p.strip()],
            server_ip=config_data.get("serverIP", ""),
            proxy_url=config_data.get("proxy_url", ""),
            lmn_api_secret=config_data.get("lmn-api-secret", ""),
            debugging=config_data.get("debugging", False),
        )
        client = ProxmoxClient(config)
        if client.check_node_connection():
            print(f"  OK -- Connected to node '{config_data['node']}' at {config_data['hvIp']}")
            return True
        print(f"  FAILED -- Could not reach node '{config_data['node']}'")
    except Exception as e:
        print(f"  FAILED -- {e}")

    print()
    print("  The Proxmox API user needs these permissions on /:")
    print("    Sys.Audit, Sys.Modify")
    print("    VM.Allocate, VM.Clone, VM.Config.Disk, VM.Config.CPU,")
    print("    VM.Config.Memory, VM.Config.Network, VM.Config.Options,")
    print("    VM.Config.HWType, VM.Console, VM.Monitor,")
    print("    VM.PowerMgmt, VM.Audit")
    print("    Datastore.Allocate, Datastore.AllocateSpace, Datastore.Audit")
    print()
    return False
