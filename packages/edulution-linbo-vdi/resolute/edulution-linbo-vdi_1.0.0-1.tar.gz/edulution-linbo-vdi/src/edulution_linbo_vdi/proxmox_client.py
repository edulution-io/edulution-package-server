"""Thin wrapper around ``proxmoxer.ProxmoxAPI``."""

from __future__ import annotations

import json
import logging
from typing import Any

from proxmoxer import ProxmoxAPI

from .config import VdiConfig
from .exceptions import ProxmoxApiError, VmNotFoundError

logger = logging.getLogger(__name__)


class ProxmoxClient:
    """Manages the Proxmox API connection and exposes higher-level helpers.

    The raw ``proxmoxer`` API object is available as :pyattr:`api` for
    anything not covered by the convenience methods.
    """

    def __init__(self, config: VdiConfig) -> None:
        self._config = config
        self.api: ProxmoxAPI = ProxmoxAPI(
            config.hv_ip,
            user=config.hv_user,
            password=config.password,
            verify_ssl=False,
        )

    @property
    def node(self) -> str:
        return self._config.node

    # ------------------------------------------------------------------
    # Connection checks
    # ------------------------------------------------------------------

    def check_node_connection(self) -> bool:
        try:
            self.api.nodes(self.node).status.get()
            return True
        except Exception as exc:
            logger.error("Connection to node failed: %s", exc)
            errorcode = str(exc).split(" ")[0]
            if errorcode == "596":
                logger.error("Possible wrong node name in vdiConfig.json")
            return False

    # ------------------------------------------------------------------
    # VM helpers
    # ------------------------------------------------------------------

    def vm_config(self, vmid: str) -> dict[str, Any] | None:
        """Return the VM config dict, or *None* if the VM does not exist."""
        try:
            return self.api.nodes(self.node).qemu(vmid).config.get()
        except Exception as exc:
            if hasattr(exc, "status_code") and exc.status_code == 500 and "does not exist" in getattr(exc, "content", ""):
                return None
            raise ProxmoxApiError(str(exc)) from exc

    def vm_status(self, vmid: str) -> dict[str, Any]:
        return self.api.nodes(self.node).qemu(vmid).status.current.get()

    def vm_exists(self, vmid: str) -> bool:
        try:
            self.api.nodes(self.node).qemu(vmid).status.get()
            return True
        except Exception:
            return False

    def set_vm_description(self, vmid: str, description: dict) -> None:
        self.api.nodes(self.node).qemu(vmid).config.post(
            description=json.dumps(description)
        )

    def set_vm_config(self, vmid: str, **kwargs: Any) -> None:
        self.api.nodes(self.node).qemu(vmid).config.post(**kwargs)

    def start_vm(self, vmid: str) -> None:
        self.api.nodes(self.node).qemu(vmid).status.start.post()

    def stop_vm(self, vmid: str) -> None:
        self.api.nodes(self.node).qemu(vmid).status.stop.post()

    def shutdown_vm(self, vmid: str) -> None:
        self.api.nodes(self.node).qemu(vmid).status.shutdown.post()

    def delete_vm(self, vmid: str) -> None:
        self.api.nodes(self.node).qemu(vmid).delete()

    def clone_vm(self, source_vmid: str, newid: str, name: str, description: str) -> None:
        self.api.nodes(self.node).qemu(source_vmid).clone.post(
            newid=newid, name=name, description=description, full=0,
        )

    def convert_to_template(self, vmid: str) -> None:
        self.api.nodes(self.node).qemu(vmid).template.post()

    def create_vm(self, **kwargs: Any) -> None:
        self.api.nodes(self.node).qemu.create(**kwargs)

    def get_spice_proxy(self, vmid: str, proxy: str) -> dict:
        return self.api.nodes(self.node).qemu(vmid).spiceproxy.post(proxy=proxy)

    def get_storage_list(self) -> list[dict]:
        return self.api.nodes(self.node).storage.get()
