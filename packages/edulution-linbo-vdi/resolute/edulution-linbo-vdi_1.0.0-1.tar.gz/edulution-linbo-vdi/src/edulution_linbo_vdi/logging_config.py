"""Centralised logging configuration for edulution-linbo-vdi."""

from __future__ import annotations

import logging

_FORMAT = "%(asctime)s %(levelname)7s: [%(filename)19s] [l%(lineno)4s]- %(message)s"
_DATEFMT = "%Y-%m-%d:%H:%M:%S"


def setup_logging(level: int = logging.INFO) -> None:
    """Configure the root logger with a consistent format.

    Safe to call multiple times -- only the first call has an effect
    (``basicConfig`` is a no-op when handlers already exist).
    """
    logging.basicConfig(format=_FORMAT, datefmt=_DATEFMT, level=level)
