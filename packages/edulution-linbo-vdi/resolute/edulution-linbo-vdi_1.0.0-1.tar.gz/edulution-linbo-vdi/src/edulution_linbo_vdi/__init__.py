"""edulution-linbo-vdi -- VDI management for linuxmuster.net on Proxmox.

Usage as a library::

    from edulution_linbo_vdi import VdiContext
    ctx = VdiContext.from_config_file("/etc/edulution/linbo-vdi/vdiConfig.json")
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from .command_runner import CommandRunner
from .config import VdiConfig
from .proxmox_client import ProxmoxClient

if TYPE_CHECKING:
    pass

__all__ = ["VdiContext", "VdiConfig", "ProxmoxClient", "CommandRunner"]


class VdiContext:
    """Central context object that bundles config, API clients, and command runner.

    Create once at startup and pass to all manager classes.
    """

    def __init__(self, config: VdiConfig, proxmox: ProxmoxClient, command_runner: CommandRunner) -> None:
        self.config = config
        self.proxmox = proxmox
        self.command_runner = command_runner

    @classmethod
    def from_config_file(cls, path: str | Path | None = None) -> VdiContext:
        """Convenience factory: load config, create clients, return context."""
        config = VdiConfig.from_file(path)
        proxmox = ProxmoxClient(config)
        command_runner = CommandRunner(config)
        return cls(config=config, proxmox=proxmox, command_runner=command_runner)
