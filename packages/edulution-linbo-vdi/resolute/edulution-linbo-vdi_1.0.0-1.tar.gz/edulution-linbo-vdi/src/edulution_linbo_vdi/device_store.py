"""File-based data loading: devices.csv, start.conf, image.info, VDI groups."""

from __future__ import annotations

import configparser
import csv
import glob
import json
import logging
import os
from pathlib import Path
from typing import Any

from .models import DeviceEntry, GroupConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# start.conf parsing
# ---------------------------------------------------------------------------

def start_conf_loader(path_to_file: str | Path) -> dict:
    """Parse a linbo ``start.conf`` file and return structured data.

    Returns a dict with keys ``config``, ``partitions``, ``os``.
    """
    path = Path(path_to_file)
    if not path.is_file():
        logger.error("%s is not a file", path)
        return {"config": {}, "partitions": [], "os": []}

    data: dict[str, Any] = {"config": {}, "partitions": [], "os": []}
    section: dict[str, Any] = {}

    for raw_line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.split("#")[0].strip()
        if not line:
            continue
        if line.startswith("["):
            section = {}
            section_name = line.strip("[]")
            if section_name == "Partition":
                data["partitions"].append(section)
            elif section_name == "OS":
                data["os"].append(section)
            else:
                data["config"][section_name] = section
        elif "=" in line:
            k, v = line.split("=", 1)
            v = v.strip()
            if v in ("yes", "no"):
                v = v == "yes"
            section[k.strip()] = v
    return data


# ---------------------------------------------------------------------------
# image.info parsing
# ---------------------------------------------------------------------------

def image_info_loader(image_name: str) -> dict[str, str]:
    """Load and parse an image ``.info`` file.  Returns key-value pairs."""
    if image_name.endswith(".cloop"):
        info_path = f"/srv/linbo/{image_name}.info"
    elif image_name.endswith(".qcow2"):
        base = image_name.split(".")[0]
        info_path = f"/srv/linbo/images/{base}/{image_name}.info"
    else:
        logger.error("Unknown image format: %s", image_name)
        return {}

    path = Path(info_path)
    if not path.is_file():
        logger.error("Image info file not found: %s", info_path)
        return {}

    data: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            data[key.strip()] = value.strip()
    return data


# ---------------------------------------------------------------------------
# devices.csv loading
# ---------------------------------------------------------------------------

def devices_loader(school_id: str) -> list[DeviceEntry]:
    """Load ``devices.csv`` for the given school and return typed entries."""
    if school_id and school_id not in ("default-school", ""):
        device_path = f"/etc/linuxmuster/sophomorix/{school_id}/{school_id}.devices.csv"
    else:
        device_path = "/etc/linuxmuster/sophomorix/default-school/devices.csv"

    entries: list[DeviceEntry] = []
    try:
        with open(device_path, newline="", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f, delimiter=";")
            for row in reader:
                if len(row) < 12 or row[0].startswith("#"):
                    continue
                entries.append(DeviceEntry.from_row(row))
    except FileNotFoundError:
        logger.error("devices.csv not found: %s", device_path)
    return entries


def devices_loader_raw(school_id: str) -> list[list[str]]:
    """Load ``devices.csv`` as raw rows (legacy compatibility)."""
    if school_id and school_id not in ("default-school", ""):
        device_path = f"/etc/linuxmuster/sophomorix/{school_id}/{school_id}.devices.csv"
    else:
        device_path = "/etc/linuxmuster/sophomorix/default-school/devices.csv"

    rows: list[list[str]] = []
    try:
        with open(device_path, newline="", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f, delimiter=";")
            for row in reader:
                if len(row) < 12 or row[0].startswith("#"):
                    continue
                rows.append(row)
    except FileNotFoundError:
        logger.error("devices.csv not found: %s", device_path)
    return rows


# ---------------------------------------------------------------------------
# Device lookup helpers
# ---------------------------------------------------------------------------

def get_vmid_range(devices: list[list[str]], vdi_group: str) -> list[str]:
    """Return all VMIDs registered for *vdi_group* (excluding master)."""
    vmids: list[str] = []
    for device in devices:
        if vdi_group in device[2]:
            if device[1] != "master" and device[11] != "":
                vmids.append(device[11])
    return vmids


def find_device_by_vmid(devices: list[list[str]], vmid: str) -> dict | None:
    """Find a device row by its VMID field and return network info."""
    for device in devices:
        if device[11] == vmid:
            return {"hostname": device[1], "mac": device[3], "ip": device[4], "vmid": vmid}
    return None


def find_device_by_mac(devices: list[list[str]], mac: str) -> dict | None:
    """Find a device row by MAC address."""
    for device in devices:
        if device[3] == mac:
            return {"hostname": device[1], "mac": device[3], "ip": device[4]}
    return None


def find_device_by_hostname(devices: list[list[str]], hostname: str) -> dict | None:
    """Find a device row by hostname (partial match)."""
    for device in devices:
        if hostname in device[1]:
            return {
                "room": device[0],
                "hostname": device[1],
                "group": device[2],
                "mac": device[3],
                "ip": device[4],
                "pxe": device[10],
            }
    return None


# ---------------------------------------------------------------------------
# School ID
# ---------------------------------------------------------------------------

def get_school_id(vdi_group: str) -> str | None:
    """Read the school ID from the LINBO section of a group's start.conf."""
    try:
        parser = configparser.ConfigParser(strict=False)
        parser.read(f"/srv/linbo/start.conf.{vdi_group}")
        return parser["LINBO"]["School"]
    except Exception as exc:
        logger.error("Problem finding school ID for %s: %s", vdi_group, exc)
        return None


# ---------------------------------------------------------------------------
# VDI groups
# ---------------------------------------------------------------------------

def get_vdi_groups() -> dict:
    """Discover all ``*.vdi`` files in ``/srv/linbo/`` and return group data.

    Returns the *legacy* dict format::

        {
            "general": {"active_groups": [...]},
            "groups": {"<name>": <raw_dict>, ...}
        }
    """
    vdi_groups: dict[str, Any] = {"general": {"active_groups": []}, "groups": {}}
    for vdi_file in glob.glob("/srv/linbo/*.vdi"):
        try:
            data = json.loads(Path(vdi_file).read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            logger.error("Error loading %s: %s", vdi_file, exc)
            continue
        vdi_group = vdi_file.split("/srv/linbo/start.conf.")[1].split(".vdi")[0]
        vdi_groups["groups"][vdi_group] = data
        activated = data.get("activated", False)
        if isinstance(activated, str):
            activated = activated.lower() in ("yes", "true", "1")
        if activated:
            vdi_groups["general"]["active_groups"].append(vdi_group)
    return vdi_groups


def get_needed_imagesize(vdi_group: str) -> str:
    """Determine the current image size for a VDI group from start.conf + image.info."""
    device_path = f"/srv/linbo/start.conf.{vdi_group}"
    start_conf_data = start_conf_loader(device_path)
    image_name = ""
    for os_section in start_conf_data["os"]:
        image_name = os_section.get("BaseImage", "")
    if not image_name:
        return ""
    image_info = image_info_loader(image_name)
    return image_info.get("imagesize", "")
