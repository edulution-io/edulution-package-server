"""Custom exception hierarchy for edulution-linbo-vdi."""


class VdiError(Exception):
    """Base exception for all VDI errors."""


class ConfigError(VdiError):
    """Configuration file missing, malformed, or invalid."""


class ConnectionError(VdiError):
    """Cannot reach Proxmox node or SSH server."""


class ProxmoxApiError(VdiError):
    """Proxmox API returned an unexpected error."""


class VmNotFoundError(VdiError):
    """A VM with the given VMID does not exist on the node."""

    def __init__(self, vmid: str, node: str) -> None:
        self.vmid = vmid
        self.node = node
        super().__init__(f"VM {vmid} does not exist on node {node}")


class NoFreeVmidError(VdiError):
    """No unoccupied VMID left in the configured range."""


class NmapCheckError(VdiError):
    """Health-check via nmap failed or timed out."""


class NoDesktopAvailableError(VdiError):
    """No free desktop could be assigned to the requesting user."""


class CommandError(VdiError):
    """A local or remote shell command failed."""

    def __init__(self, command: str, returncode: int | None = None, stderr: str = "") -> None:
        self.command = command
        self.returncode = returncode
        self.stderr = stderr
        super().__init__(f"Command failed: {command!r} (rc={returncode})")
