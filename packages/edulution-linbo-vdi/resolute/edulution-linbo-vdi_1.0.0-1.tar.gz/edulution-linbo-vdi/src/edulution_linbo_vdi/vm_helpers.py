"""Shared VM helper functions (replaces 3x duplicated wait-for-status logic)."""

from __future__ import annotations

import logging
import time
from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .proxmox_client import ProxmoxClient

logger = logging.getLogger(__name__)


def now_timestamp() -> str:
    """Return the current time as ``YYYYMMDDHHmmSS`` string."""
    return datetime.now().strftime("%Y%m%d%H%M%S")


def now_float() -> float:
    """Return the current time as a ``YYYYMMDDHHmmSS`` float (legacy format)."""
    return float(now_timestamp())


def wait_for_vm_status(
    client: ProxmoxClient,
    vmid: str,
    target_status: str,
    timeout: int,
    poll_interval: float = 5.0,
    vdi_group: str = "",
) -> bool:
    """Poll a VM's ``qmpstatus`` until it matches *target_status* or timeout.

    Returns *True* if the target was reached, *False* otherwise.
    """
    prefix = f"[{vdi_group}] " if vdi_group else ""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            response = client.vm_status(vmid)
            current = response.get("qmpstatus", "unknown")
        except Exception:
            current = "unknown"

        if current == target_status:
            logger.info("%sVM %s reached status '%s'", prefix, vmid, target_status)
            return True

        logger.debug("%sVM %s status is '%s', waiting for '%s'...", prefix, vmid, current, target_status)
        time.sleep(poll_interval)

    logger.warning("%sVM %s did not reach '%s' within %ds", prefix, vmid, target_status, timeout)
    return False


def get_current_master(
    master_states: dict,
    master_vmids: list[str],
    vdi_group: str,
) -> dict:
    """Find the most recent master by ``dateOfCreation`` timestamp.

    Returns ``{"vmid": <id>, "timestamp": <ts>}``.
    """
    timestamp_latest: float = 0
    vmid_latest: str = ""
    for vmid in master_vmids:
        if vmid in master_states and master_states[vmid] is not None:
            ts = master_states[vmid].get("dateOfCreation") or 0
            if float(ts) >= timestamp_latest:
                timestamp_latest = float(ts)
                vmid_latest = vmid

    logger.debug("[%s] Current master vmid=%s, timestamp=%s", vdi_group, vmid_latest, timestamp_latest)
    return {"vmid": vmid_latest, "timestamp": timestamp_latest}
