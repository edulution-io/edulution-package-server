"""VdiService -- main loop that manages masters and clones."""

from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime
from typing import TYPE_CHECKING

from . import device_store
from .broker import ConnectionBroker
from .clone import CloneManager
from .master import MasterManager

if TYPE_CHECKING:
    from .__init__ import VdiContext

logger = logging.getLogger(__name__)

BUILDING_TIMEOUT_MINUTES = 10


class VdiService:
    """Encapsulates the VDI service main loop."""

    def __init__(self, ctx: VdiContext) -> None:
        self._ctx = ctx
        self._master_mgr = MasterManager(ctx)
        self._clone_mgr = CloneManager(ctx)
        self._broker = ConnectionBroker(ctx)

    def run(self) -> None:
        """Run the service loop (blocking)."""
        logger.info("***** VDI-Service initiated ... *****")

        try:
            while True:
                logger.debug("*" * 56)
                while not self._check_connection():
                    time.sleep(5)

                vdi_groups = device_store.get_vdi_groups()

                while not vdi_groups["general"]["active_groups"]:
                    logger.info("No active VDI groups available!")
                    time.sleep(5)
                    vdi_groups = device_store.get_vdi_groups()

                for vdi_group, group_data in vdi_groups["groups"].items():
                    if group_data.get("activated") in (True, "yes", "true", "1"):
                        self._handle_master(group_data, vdi_group)

                for vdi_group, group_data in vdi_groups["groups"].items():
                    if group_data.get("activated") in (True, "yes", "true", "1"):
                        self._handle_clones(group_data, vdi_group)

                self._broker.cleanup_files()
                time.sleep(2)
        except KeyboardInterrupt:
            logger.info("***** VDI-Service stopped *****")

    # ------------------------------------------------------------------
    # Master handling
    # ------------------------------------------------------------------

    def _handle_master(self, group_data: dict, vdi_group: str) -> None:
        logger.debug("[%s] Group Data", vdi_group)
        logger.debug(json.dumps(group_data, indent=2))

        master_states = self._master_mgr.get_states(group_data, vdi_group)
        if not master_states:
            return

        logger.debug("[%s] Master States Summary", vdi_group)
        logger.debug(json.dumps(master_states["summary"], indent=2))

        existing = master_states["summary"]["existing_master"]

        if existing == 0:
            logger.info("[%s] Building new master", vdi_group)
            t = threading.Thread(target=self._master_mgr.create_master, args=(group_data, vdi_group))
            t.start()

        elif existing > 1:
            logger.debug("[%s] Trying to find failed/deprecated masters to delete", vdi_group)
            t = threading.Thread(target=self._master_mgr.remove_master, args=(group_data, vdi_group))
            t.start()
            master_states = self._master_mgr.get_states(group_data, vdi_group)

        elif existing == 1:
            master_vmids = group_data["vmids"]
            if isinstance(master_vmids, str):
                master_vmids = [v.strip() for v in master_vmids.split(",") if v.strip()]

            vmid_latest = None
            timestamp_latest: float = 1
            for vmid in master_vmids:
                state = master_states.get(vmid)
                if state and isinstance(state, dict) and state.get("buildstate") != "failed":
                    ts = float(state.get("dateOfCreation", 0))
                    if ts > timestamp_latest:
                        timestamp_latest = ts
                        vmid_latest = vmid

            if vmid_latest is None:
                logger.info("[%s] No finished or building master found", vdi_group)
                return

            logger.debug("[%s] Latest master: %s", vdi_group, vmid_latest)

            if master_states[vmid_latest]["buildstate"] == "building":
                logger.debug("[%s] Master is building", vdi_group)
                return

            # Check image up-to-date
            actual_imagesize = master_states["basic"].get("actual_imagesize", "")
            master_imagesize = master_states[vmid_latest].get("imagesize", "")
            if actual_imagesize != master_imagesize:
                logger.debug("[%s] Master image is not up-to-date, creating new", vdi_group)
                t = threading.Thread(target=self._master_mgr.create_master, args=(group_data, vdi_group))
                t.start()
                return

            # Check hardware config (skip attributes that may differ
            # between config and actual VM, e.g. boot order is changed
            # for master creation, spice_enhancements requires root)
            attributes = ["bios", "cores", "memory", "ostype", "name", "scsihw", "machine"]
            for attr in attributes:
                config_val = group_data.get(attr)
                vm_val = master_states[vmid_latest].get(attr)
                if config_val and vm_val and str(config_val) != str(vm_val):
                    logger.info("[%s] Master resources not up-to-date (%s: %s != %s), building new",
                                vdi_group, attr, config_val, vm_val)
                    self._master_mgr.create_master(group_data, vdi_group)
                    return

            logger.debug("[%s] Master resources %s are up-to-date", vdi_group, vmid_latest)

    # ------------------------------------------------------------------
    # Clone handling
    # ------------------------------------------------------------------

    def _handle_clones(self, group_data: dict, vdi_group: str) -> None:
        master_states = self._master_mgr.get_states(group_data, vdi_group)
        if not master_states:
            logger.warning("[%s] No master states, probably no entry in devices.csv", vdi_group)
            return

        summary = master_states["summary"]
        finished_masters = summary["existing_master"] - summary["building_master"] - summary["failed_master"]
        if finished_masters < 1:
            logger.debug("[%s] No master ready for clone handling", vdi_group)
            return

        clone_states = self._clone_mgr.get_states(group_data, vdi_group)
        if not clone_states:
            return

        master_vm_id = master_states["current_master"]["vmid"]

        existing_vms = clone_states["summary"]["existing_vms"]
        building_vms = clone_states["summary"]["building_vms"]
        available_vms = clone_states["summary"]["available_vms"]
        min_vms = group_data["minimum_vms"]
        max_vms = group_data["maximum_vms"]
        prestarted_vms = group_data["prestarted_vms"]

        not_enough_min = existing_vms < min_vms and building_vms < (min_vms - existing_vms)
        not_enough_prestarted = available_vms < prestarted_vms and existing_vms < max_vms and building_vms < (prestarted_vms - available_vms)

        if not_enough_min or not_enough_prestarted:
            logger.debug("[%s] Building new clone...", vdi_group)
            t = threading.Thread(
                target=self._clone_mgr.build_clone,
                args=(clone_states, group_data, master_vm_id, vdi_group),
            )
            t.start()

        too_many = available_vms > prestarted_vms and existing_vms > min_vms
        if too_many:
            amount = existing_vms - min_vms
            logger.debug("[%s] Removing %d clone(s)...", vdi_group, amount)
            self._clone_mgr.remove_clone(amount, clone_states, vdi_group)

        # Outdated clones
        now = datetime.now()
        outdated: list[dict] = []
        for vmid, info in clone_states.items():
            if vmid == "summary" or not isinstance(info, dict):
                continue
            try:
                doc = datetime.strptime(info["dateOfCreation"], "%Y%m%d%H%M%S")
                minutes_since = (now - doc).seconds / 60
            except (KeyError, ValueError):
                continue

            is_outdated = (
                info.get("master") != master_vm_id
                or info.get("imagesize") != master_states.get(master_vm_id, {}).get("imagesize")
                or (info.get("buildstate") == "building" and minutes_since > BUILDING_TIMEOUT_MINUTES)
            )
            if is_outdated:
                outdated.append(info)

        if outdated:
            self._clone_mgr.remove_outdated_clones(outdated, clone_states, vdi_group)

    # ------------------------------------------------------------------
    # Connection check
    # ------------------------------------------------------------------

    def _check_connection(self) -> bool:
        if self._ctx.config.vdi_local_service:
            return self._ctx.proxmox.check_node_connection()
        return (
            self._ctx.command_runner.check_connection()
            and self._ctx.proxmox.check_node_connection()
        )
