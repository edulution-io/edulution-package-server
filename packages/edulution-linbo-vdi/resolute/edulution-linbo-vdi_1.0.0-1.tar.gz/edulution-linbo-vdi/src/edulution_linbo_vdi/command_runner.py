"""Run shell commands locally or via SSH -- without ``shell=True``."""

from __future__ import annotations

import logging
import shlex
import subprocess
from typing import TYPE_CHECKING

import paramiko

from .exceptions import CommandError

if TYPE_CHECKING:
    from .config import VdiConfig

logger = logging.getLogger(__name__)


class CommandRunner:
    """Execute commands either locally or over SSH depending on config.

    When ``vdi_local_service`` is *True* commands run locally via
    ``subprocess``.  Otherwise an SSH connection to ``server_ip`` is used.
    """

    def __init__(self, config: VdiConfig) -> None:
        self._local = config.vdi_local_service
        self._ssh: paramiko.SSHClient | None = None
        if not self._local:
            self._ssh = paramiko.SSHClient()
            self._ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self._ssh.connect(config.server_ip, port=22, username="root")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self, command: str) -> list[bytes]:
        """Run *command* and return stdout lines as a list of ``bytes``.

        The signature intentionally matches the old ``vdi_common.run_command``
        so callers that iterate over lines keep working.
        """
        if self._local:
            return self._run_local(command)
        return self._run_ssh(command)

    def run_text(self, command: str) -> list[str]:
        """Like :meth:`run` but decode each line to ``str``."""
        return [line.decode("utf-8", errors="replace").rstrip("\n") for line in self.run(command)]

    def check_connection(self) -> bool:
        """Return *True* if the underlying transport (SSH) is alive."""
        if self._local:
            return True
        if self._ssh is None:
            return False
        transport = self._ssh.get_transport()
        if transport is None:
            logger.error("Connection to server failed!")
            return False
        return transport.is_active()

    def close(self) -> None:
        if self._ssh is not None:
            self._ssh.close()
            self._ssh = None

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run_local(self, command: str) -> list[bytes]:
        args = shlex.split(command)
        proc = subprocess.run(args, capture_output=True, check=False)
        if proc.returncode != 0:
            logger.warning("Command %r exited with %d: %s", command, proc.returncode, proc.stderr.decode(errors="replace"))
        return proc.stdout.splitlines(keepends=True)

    def _run_ssh(self, command: str) -> list[bytes]:
        assert self._ssh is not None
        _stdin, stdout, _stderr = self._ssh.exec_command(command)
        return [line.encode("utf-8") if isinstance(line, str) else line for line in stdout.readlines()]
