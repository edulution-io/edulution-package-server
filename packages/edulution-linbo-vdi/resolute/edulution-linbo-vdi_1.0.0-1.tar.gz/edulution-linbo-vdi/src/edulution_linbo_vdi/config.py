"""VdiConfig -- immutable, thread-safe configuration loaded from JSON."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from .exceptions import ConfigError

_DEFAULT_CONFIG_PATH = Path("/etc/edulution/linbo-vdi/vdiConfig.json")


@dataclass(frozen=True)
class VdiConfig:
    """All values from ``vdiConfig.json``, validated at construction time."""

    node: str
    hv_ip: str
    hv_user: str
    password: str
    multischool: bool
    timeout_connection_request: float
    vdi_local_service: bool
    nmap_ports: list[str] = field(default_factory=list)
    server_ip: str = ""
    proxy_url: str = ""
    lmn_api_secret: str = ""
    debugging: bool = False

    @classmethod
    def from_file(cls, path: str | Path | None = None) -> VdiConfig:
        """Load and validate configuration from a JSON file.

        Parameters
        ----------
        path:
            Path to the config file.  Defaults to
            ``/etc/edulution/linbo-vdi/vdiConfig.json``.
        """
        config_path = Path(path) if path else _DEFAULT_CONFIG_PATH
        if not config_path.is_file():
            raise ConfigError(f"Config file not found: {config_path}")
        try:
            raw = json.loads(config_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ConfigError(f"Invalid JSON in {config_path}: {exc}") from exc

        try:
            return cls(
                node=raw["node"],
                hv_ip=raw["hvIp"],
                hv_user=raw["hvUser"],
                password=raw["password"],
                multischool=raw.get("multischool", False),
                timeout_connection_request=float(raw["timeoutConnectionRequest"]),
                vdi_local_service=raw.get("vdiLocalService", True),
                nmap_ports=[p.strip() for p in raw.get("nmapPorts", "").split(",") if p.strip()],
                server_ip=raw.get("serverIP", raw.get("serverIp", "")),
                proxy_url=raw.get("proxy_url", ""),
                lmn_api_secret=raw.get("lmn-api-secret", ""),
                debugging=raw.get("debugging", False),
            )
        except KeyError as exc:
            raise ConfigError(f"Missing required config key: {exc}") from exc
