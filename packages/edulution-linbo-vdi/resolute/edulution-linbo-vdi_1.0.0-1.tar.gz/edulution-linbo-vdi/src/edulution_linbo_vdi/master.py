"""MasterManager -- create, remove, and query master VM states."""

from __future__ import annotations

import json
import logging
import re
import time
from datetime import datetime
from multiprocessing.pool import ThreadPool
from typing import TYPE_CHECKING, Any

from . import device_store
from .exceptions import NoFreeVmidError
from .nmap_checker import check_vm_health
from .vm_helpers import get_current_master, now_timestamp, wait_for_vm_status

if TYPE_CHECKING:
    from .__init__ import VdiContext

logger = logging.getLogger(__name__)


class MasterManager:
    """Manages master VMs for VDI groups."""

    def __init__(self, ctx: VdiContext) -> None:
        self._ctx = ctx
        self._px = ctx.proxmox
        self._cmd = ctx.command_runner

    # ------------------------------------------------------------------
    # Public: get states
    # ------------------------------------------------------------------

    def get_states(self, group_data: dict, vdi_group: str) -> dict | None:
        """Gather master VM states for *vdi_group*.  Returns the legacy dict."""
        school_id = device_store.get_school_id(vdi_group)
        if not school_id:
            return None
        devices = device_store.devices_loader_raw(school_id)

        master_vmids = group_data["vmids"]
        if isinstance(master_vmids, str):
            master_vmids = [v.strip() for v in master_vmids.split(",") if v.strip()]
        master_hostname = group_data["hostname"]

        logger.debug("[%s] ID range for imagegroup: %s", vdi_group, master_vmids)

        master_states: dict[str, Any] = {}
        basic = device_store.find_device_by_hostname(devices, master_hostname)
        if not basic:
            logger.warning("[%s] Could not find master hostname in devices", vdi_group)
            return None
        basic["actual_imagesize"] = device_store.get_needed_imagesize(vdi_group)
        basic["hostname"] = master_hostname
        master_states["basic"] = basic

        all_api = self._get_vm_info_multithreaded(master_vmids, vdi_group, "master")
        master_states.update(all_api)

        # Build summary
        summary = {
            "existing_master": 0,
            "registered": len(master_vmids),
            "building_master": 0,
            "failed_master": 0,
            "finished": 0,
        }
        for vmid in all_api:
            if self._px.vm_exists(vmid):
                summary["existing_master"] += 1
                bs = all_api[vmid].get("buildstate", "")
                if bs == "building":
                    summary["building_master"] += 1
                elif bs == "finished":
                    summary["finished"] += 1
                elif bs == "failed":
                    summary["failed_master"] += 1

        master_states["summary"] = summary
        master_states["current_master"] = get_current_master(master_states, master_vmids, vdi_group)
        return master_states

    def get_all_states(self) -> dict:
        """Return master states for every VDI group."""
        vdi_groups = device_store.get_vdi_groups()
        result: dict = {}
        for vdi_group, group_data in vdi_groups["groups"].items():
            states = self.get_states(group_data, vdi_group)
            if not states:
                continue
            entry: dict = {"summary": states["summary"]}
            entry["current_master"] = states["current_master"]
            entry["current_master"]["hostname"] = states["basic"]["hostname"]
            entry["current_master"]["actual_imagesize"] = states["basic"]["actual_imagesize"]
            entry["current_master"]["ip"] = states["basic"].get("ip", "")
            entry["current_master"]["mac"] = states["basic"].get("mac", "")
            master_vms = {k: v for k, v in states.items() if k not in ("summary", "basic", "current_master")}
            entry["master_vms"] = master_vms
            result[vdi_group] = entry
        return result

    # ------------------------------------------------------------------
    # Public: create master
    # ------------------------------------------------------------------

    def create_master(self, group_data: dict, vdi_group: str) -> bool:
        logger.info("[%s] Creating new master...", vdi_group)

        school_id = device_store.get_school_id(vdi_group)
        if not school_id:
            return False
        devices = device_store.devices_loader_raw(school_id)

        master_vmid = self._get_available_vmid(group_data, vdi_group)
        if not master_vmid:
            logger.error("[%s] No master VMID available", vdi_group)
            return False

        master_net0 = f"bridge={group_data['bridge']},virtio={group_data['mac']}"
        if group_data.get("tag", 0) != 0:
            master_net0 += f",tag={group_data['tag']}"

        timeout = group_data["timeout_building_master"]
        description = self._generate_description(group_data, vdi_group)

        master_device = device_store.find_device_by_mac(devices, group_data["mac"])
        if not master_device:
            logger.error("[%s] Master device not found in devices.csv", vdi_group)
            return False

        self._send_linbo_remote(school_id, master_device["hostname"], vdi_group)

        # Build VM parameters
        params = self._build_vm_params(group_data, master_vmid, master_net0, description)

        # Validate storage
        storage_repos = self._px.get_storage_list()
        storage_names = [s["storage"] for s in storage_repos]
        if group_data["storage"] not in storage_names:
            logger.error("[%s] Storage %s not available on node", vdi_group, group_data["storage"])
            return False

        # Validate MAC
        if not self._validate_mac(group_data["mac"]):
            logger.warning("[%s] MAC address appears malformed: %s", vdi_group, group_data["mac"])

        try:
            self._px.create_vm(**params)
            logger.info("[%s] Master VM %s is being created", vdi_group, master_vmid)
        except Exception as exc:
            # spice_enhancements requires root@pam -- retry without it
            if "spice_enhancements" in str(exc) and "spice_enhancements" in params:
                logger.warning("[%s] Retrying VM creation without spice_enhancements (requires root@pam)", vdi_group)
                del params["spice_enhancements"]
                try:
                    self._px.create_vm(**params)
                    logger.info("[%s] Master VM %s is being created", vdi_group, master_vmid)
                except Exception as exc2:
                    logger.error("[%s] Could not create VM: %s", vdi_group, exc2)
                    return False
            else:
                logger.error("[%s] Could not create VM: %s", vdi_group, exc)
                return False

        # Start and prepare via LINBO
        self._start_preparing_vm(master_vmid, vdi_group)

        # Health check
        if check_vm_health(master_device["ip"], timeout, vmid=master_vmid):
            description["buildstate"] = "finished"
            self._prepare_template(master_vmid, vdi_group)
            self._px.set_vm_description(master_vmid, description)
            logger.info("[%s] Master template created successfully", vdi_group)
        else:
            description["buildstate"] = "failed"
            self._px.set_vm_description(master_vmid, description)
            logger.info("[%s] Master creation failed, removing", vdi_group)
            self._delete_failed_master(master_vmid, vdi_group)
        return True

    # ------------------------------------------------------------------
    # Public: remove master
    # ------------------------------------------------------------------

    def remove_master(self, group_data: dict, vdi_group: str) -> None:
        master_states = self.get_states(group_data, vdi_group)
        if not master_states:
            return

        timeout_building = group_data["timeout_building_master"]
        master_vmids = group_data["vmids"]
        if isinstance(master_vmids, str):
            master_vmids = [v.strip() for v in master_vmids.split(",") if v.strip()]

        removeables = self._find_and_sort_existing(master_states, master_vmids, vdi_group)
        if not removeables:
            logger.info("[%s] No master available to delete", vdi_group)
            return

        now = float(datetime.now().strftime("%Y%m%d%H%M%S"))
        for vmid in list(removeables):
            state = master_states.get(vmid, {})
            bs = state.get("buildstate", "")
            doc = float(state.get("dateOfCreation", 0))
            if bs == "failed" or (bs == "building" and (now - doc) > timeout_building):
                logger.info("[%s] Removing failed/timed-out master %s", vdi_group, vmid)
                self._stop_and_delete(vmid, vdi_group, state)
                return

        if len(removeables) == 1:
            logger.info("[%s] Only one master exists, not deleting", vdi_group)
            return

        # Remove the latest from candidates (keep it)
        latest = max(removeables, key=lambda k: removeables[k])
        del removeables[latest]

        # Check which masters are still referenced by clones
        from .clone import CloneManager
        clone_mgr = CloneManager(self._ctx)
        clone_states = clone_mgr.get_states(group_data, vdi_group)
        linked_masters: list[str] = []
        if clone_states:
            for vm, info in clone_states.items():
                if vm != "summary" and isinstance(info, dict) and "master" in info:
                    linked_masters.append(info["master"])
            linked_masters = list(set(linked_masters))

        # Try unlinked first
        for vmid in removeables:
            if vmid not in linked_masters:
                self._stop_and_delete(vmid, vdi_group, master_states.get(vmid, {}))
                return

        # Fall back to any removeable
        for vmid in removeables:
            self._stop_and_delete(vmid, vdi_group, master_states.get(vmid, {}))
            return

        logger.info("[%s] No master was deleted", vdi_group)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_vm_info_multithreaded(self, vmids: list[str], vdi_group: str, vm_type: str) -> dict:
        pool = ThreadPool(processes=5)
        procs = [pool.apply_async(func=self._get_vm_info_by_api, args=(vmid, vdi_group, vm_type)) for vmid in vmids]
        data: dict = {}
        for p in procs:
            result = p.get()
            if result:
                data[result["vmid"]] = result
        pool.close()
        pool.join()
        return data

    def _get_vm_info_by_api(self, vmid: str, vdi_group: str, vm_type: str = "master") -> dict | None:
        config = self._px.vm_config(vmid)
        if config is None:
            logger.info("[%s] VM %s does not exist on %s", vdi_group, vmid, self._px.node)
            return None

        try:
            response = self._px.vm_status(vmid)
            config["status"] = response["qmpstatus"]
            config["uptime"] = response.get("uptime", 0)
            config["spicestatus"] = ""
        except Exception:
            logger.error("[%s] Cannot parse VM %s information", vdi_group, vmid)
            return None

        try:
            desc = json.loads(config.get("description", "{}"))
            if vm_type == "master":
                config["timestamp"] = desc.get("timestamp", "")
            config["imagesize"] = desc.get("imagesize", "")
            config["dateOfCreation"] = desc.get("dateOfCreation", "")
            config["buildstate"] = desc.get("buildstate", "")
            config["vmid"] = vmid
            config["group"] = desc.get("group", "")
            config.pop("description", None)
            logger.debug("[%s] VM %s parsed", vdi_group, vmid)
            return config
        except Exception as exc:
            logger.error("[%s] Failed to extract description for VM %s: %s", vdi_group, vmid, exc)
            return None

    def _get_available_vmid(self, group_data: dict, vdi_group: str) -> str | None:
        vmids = group_data["vmids"]
        if isinstance(vmids, str):
            vmids = [v.strip() for v in vmids.split(",") if v.strip()]
        for vmid in vmids:
            if not self._px.vm_exists(vmid):
                logger.info("[%s] Available VMID for master: %s", vdi_group, vmid)
                return vmid
        logger.info("[%s] No VMID available", vdi_group)
        return None

    @staticmethod
    def _build_vm_params(group_data: dict, vmid: str, net0: str, description: dict) -> dict:
        """Assemble the ``qemu.create()`` parameter dict.

        Handles the differences between SeaBIOS and OVMF (EFI):
        - OVMF requires ``machine=q35``, ``efidisk0``, and a modern boot order.
        - The primary disk bus defaults to ``sata`` for SeaBIOS and ``scsi``
          for OVMF, but can be overridden with ``disk_bus`` in the group config.
        - ``bootdisk`` is forwarded when present.
        """
        bios = group_data.get("bios", "seabios")
        storage = group_data["storage"]
        size = group_data["size"]
        fmt = group_data["format"]
        is_efi = bios == "ovmf"

        # Determine disk bus: explicit config > auto-detect from bios
        disk_bus = group_data.get("disk_bus", "")
        if not disk_bus:
            disk_bus = "scsi" if is_efi else "sata"

        disk_spec = f"{storage}:{size},format={fmt}"
        disk_key = f"{disk_bus}0"  # e.g. "sata0", "scsi0", "virtio0"

        params: dict = {
            "name": group_data["name"],
            "vmid": vmid,
            "description": json.dumps(description),
            "bios": bios,
            "cores": group_data["cores"],
            "ostype": group_data["ostype"],
            "memory": group_data["memory"],
            "storage": storage,
            "scsihw": group_data["scsihw"],
            disk_key: disk_spec,
            "net0": net0,
            "vga": group_data["display"],
            "audio0": group_data["audio"],
            "usb0": group_data["usb0"],
        }

        # spice_enhancements requires root@pam -- only set when configured
        spice_enh = group_data.get("spice_enhancements", "")
        if spice_enh:
            params["spice_enhancements"] = spice_enh

        # --- EFI / OVMF specifics ---
        if is_efi:
            # q35 chipset is required for OVMF
            params["machine"] = group_data.get("machine", "q35")

            # VirtIO RNG -- required for OVMF PXE boot (entropy source)
            params["rng0"] = group_data.get("rng0", "source=/dev/urandom")

            # EFI disk -- user can provide a full spec or we build a default
            efidisk = group_data.get("efidisk0", "")
            if not efidisk:
                efidisk = f"{storage}:1,efitype=4m,pre-enrolled-keys=0"
            params["efidisk0"] = efidisk

            # TPM (optional, e.g. for Win11)
            tpmstate = group_data.get("tpmstate0", "")
            if tpmstate:
                params["tpmstate0"] = tpmstate
        else:
            # For SeaBIOS, only set machine if explicitly configured
            machine = group_data.get("machine", "")
            if machine:
                params["machine"] = machine

        # --- Boot order ---
        # For master creation, network must come first so the VM can
        # PXE-boot into LINBO and receive its image.  Once cloned, the
        # clone's disk already contains a bootable OS.
        boot = group_data.get("boot", "")
        if boot:
            # Ensure net0 is before disk for initial PXE boot
            params["boot"] = f"order=net0;{disk_key}"
        else:
            params["boot"] = f"order=net0;{disk_key}"

        # bootdisk (optional, tells PVE which disk to prefer)
        bootdisk = group_data.get("bootdisk", "")
        if bootdisk:
            params["bootdisk"] = bootdisk

        return params

    def _generate_description(self, group_data: dict, vdi_group: str) -> dict:
        device_path = f"/srv/linbo/start.conf.{vdi_group}"
        start_conf = device_store.start_conf_loader(device_path)
        image_name = ""
        for os_section in start_conf["os"]:
            image_name = os_section.get("BaseImage", "")
        image_info = device_store.image_info_loader(image_name) if image_name else {}

        return {
            "timestamp": image_info.get("timestamp", ""),
            "imagesize": image_info.get("imagesize", ""),
            "dateOfCreation": now_timestamp(),
            "buildstate": "building",
            "group": group_data["group"],
        }

    def _send_linbo_remote(self, school_id: str, master_hostname: str, vdi_group: str) -> None:
        try:
            command = "linbo-remote"
            if school_id != "default-school":
                command += f" -s {school_id}"
            command += f" -i {master_hostname} -p partition,format,initcache:rsync,sync:1,start:1"
            logger.info("[%s] Sending linbo-remote command to %s", vdi_group, master_hostname)
            self._cmd.run(command)
        except Exception as exc:
            logger.error("[%s] linbo-remote failed: %s", vdi_group, exc)

    @staticmethod
    def _validate_mac(mac: str) -> bool:
        return bool(re.match(r"[0-9a-f]{2}([-:])[0-9a-f]{2}(\1[0-9a-f]{2}){4}$", mac.lower()))

    def _start_preparing_vm(self, vmid: str, vdi_group: str) -> bool:
        try:
            self._px.start_vm(vmid)
            if wait_for_vm_status(self._px, vmid, "running", timeout=100, vdi_group=vdi_group):
                logger.info("[%s] VM %s started, getting prepared by LINBO", vdi_group, vmid)
                return True
        except Exception as exc:
            logger.error("[%s] Failed to start master VM: %s", vdi_group, exc)
            self._delete_failed_master(vmid, vdi_group)
        return False

    def _prepare_template(self, vmid: str, vdi_group: str) -> None:
        try:
            status = self._px.vm_status(vmid).get("qmpstatus", "")
            if status == "running":
                self._px.shutdown_vm(vmid)
            logger.info("[%s] Preparing VM to template...", vdi_group)
            if wait_for_vm_status(self._px, vmid, "stopped", timeout=50, vdi_group=vdi_group):
                logger.info("[%s] Converting VM to template", vdi_group)
                self._px.convert_to_template(vmid)
        except Exception as exc:
            logger.error("[%s] Template preparation failed: %s", vdi_group, exc)

    def _delete_failed_master(self, vmid: str, vdi_group: str) -> None:
        try:
            status = self._px.vm_status(vmid).get("qmpstatus", "")
            if status == "running":
                self._px.stop_vm(vmid)
                logger.info("[%s] Stopping failed master %s", vdi_group, vmid)
                if wait_for_vm_status(self._px, vmid, "stopped", timeout=20, vdi_group=vdi_group):
                    self._px.delete_vm(vmid)
                    logger.info("[%s] Deleted failed master %s", vdi_group, vmid)
            else:
                self._px.delete_vm(vmid)
                logger.info("[%s] Deleted failed master %s", vdi_group, vmid)
        except Exception as exc:
            logger.error("[%s] Error deleting master %s: %s", vdi_group, vmid, exc)

    def _find_and_sort_existing(self, master_states: dict, master_vmids: list[str], vdi_group: str) -> dict:
        existing: dict[str, str] = {}
        for vmid in master_vmids:
            state = master_states.get(vmid)
            if state and isinstance(state, dict) and "dateOfCreation" in state:
                existing[vmid] = state["dateOfCreation"]
        if not existing:
            logger.info("[%s] No master exists", vdi_group)
            return {}
        return dict(sorted(existing.items(), key=lambda item: item[1]))

    def _stop_and_delete(self, vmid: str, vdi_group: str, state: dict) -> None:
        try:
            status = state.get("status", "")
            if status == "running":
                self._px.stop_vm(vmid)
                logger.info("[%s] Master %s is getting stopped", vdi_group, vmid)
                if not wait_for_vm_status(self._px, vmid, "stopped", timeout=20, vdi_group=vdi_group):
                    logger.error("[%s] Could not stop VM %s", vdi_group, vmid)
                    return
            self._px.delete_vm(vmid)
            logger.info("[%s] Deleted master %s", vdi_group, vmid)
        except Exception as exc:
            logger.error("[%s] Master %s could not be removed: %s", vdi_group, vmid, exc)
