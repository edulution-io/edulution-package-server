"""ConnectionBroker -- assign VMs to users and manage SPICE connection files."""

from __future__ import annotations

import json
import logging
import os
import random
import string
from pathlib import Path
from typing import TYPE_CHECKING

from . import device_store
from .clone import CloneManager
from .exceptions import NoDesktopAvailableError
from .vm_helpers import now_float, now_timestamp

if TYPE_CHECKING:
    from .__init__ import VdiContext

logger = logging.getLogger(__name__)

_VDI_TMP = Path("/tmp/vdi")


class ConnectionBroker:
    """Assigns free clone VMs to users and creates SPICE connection files."""

    def __init__(self, ctx: VdiContext) -> None:
        self._ctx = ctx
        self._px = ctx.proxmox
        self._clone_mgr = CloneManager(ctx)

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def get_connection(self, vdi_group: str, user: str) -> dict:
        """Find a free clone for *user* in *vdi_group* and return connection info.

        Returns ``{"configFile": "<path>"}`` on success.
        Raises :class:`NoDesktopAvailableError` if nothing is available.
        """
        group_data = device_store.get_vdi_groups()["groups"][vdi_group]
        vm_states = self._clone_mgr.get_states(group_data, vdi_group)
        if not vm_states:
            raise NoDesktopAvailableError(f"No clone states for group {vdi_group}")

        # Remove summary for iteration
        states = {k: v for k, v in vm_states.items() if k != "summary"}

        now = now_float()
        timeout = self._ctx.config.timeout_connection_request

        # 1) User already has a recent connection
        for vmid, info in states.items():
            if not isinstance(info, dict):
                continue
            try:
                if info.get("buildstate") != "finished":
                    continue
                if info.get("lastConnectionRequestUser") == user:
                    lcrt = info.get("lastConnectionRequestTime", "")
                    if lcrt:
                        passed = now - float(lcrt)
                        if passed < timeout:
                            return json.loads(self._send_connection(vmid, user))
            except Exception as exc:
                logger.debug("Skipping VM %s: %s", vmid, exc)

        # 2) Never-used VM
        unused: list[str] = []
        for vmid, info in states.items():
            if not isinstance(info, dict):
                continue
            if info.get("buildstate") == "finished":
                if info.get("lastConnectionRequestTime", "") == "" and info.get("user", "") == "":
                    unused.append(vmid)
        if unused:
            vmid = random.choice(unused)
            return json.loads(self._send_connection(vmid, user))

        # 3) Timed-out VM (no longer in active use)
        available: list[str] = []
        for vmid, info in states.items():
            if not isinstance(info, dict):
                continue
            try:
                if info.get("buildstate") != "finished":
                    continue
                lcrt = info.get("lastConnectionRequestTime", "")
                if lcrt and info.get("user", "") == "":
                    if (now - float(lcrt)) > timeout:
                        available.append(vmid)
            except (ValueError, TypeError):
                continue
        if available:
            vmid = random.choice(available)
            return json.loads(self._send_connection(vmid, user))

        raise NoDesktopAvailableError(f"No desktop available for {user} in {vdi_group}")

    def cleanup_files(self) -> None:
        """Delete SPICE connection files older than ~1 minute."""
        if not _VDI_TMP.exists():
            return
        now = now_float()
        for path in _VDI_TMP.glob("start-vdi-*"):
            try:
                # Filename format: start-vdi-YYYYMMDDHHmmSS-XXXXXX.vv
                parts = path.name.split("-")
                if len(parts) >= 3:
                    file_ts = float(parts[2])
                    if (now - file_ts) > 60:
                        path.unlink()
                        logger.info("Deleted old connection file %s", path)
                    else:
                        logger.debug("Connection file %s is under 1 min old", path)
            except (ValueError, IndexError, OSError) as exc:
                logger.debug("Skipping file %s: %s", path, exc)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _send_connection(self, vmid: str, user: str) -> str:
        """Update VM description and create a SPICE ``.vv`` file.

        Returns JSON string ``{"configFile": "...path..."}``.
        """
        # Update VM description with user + timestamp
        config = self._px.vm_config(vmid) or {}
        desc = json.loads(config.get("description", "{}"))
        desc["lastConnectionRequestUser"] = user
        desc["lastConnectionRequestTime"] = now_timestamp()
        self._px.set_vm_description(vmid, desc)

        # Get SPICE proxy data
        vv = self._px.get_spice_proxy(vmid, self._ctx.config.hv_ip)

        # Write .vv file
        _VDI_TMP.mkdir(parents=True, exist_ok=True)
        random_suffix = "".join(random.choices(string.ascii_letters + string.digits, k=6))
        filename = f"start-vdi-{now_timestamp()}-{random_suffix}.vv"
        config_path = _VDI_TMP / filename

        proxy_url = self._ctx.config.proxy_url
        lines = [
            "[virt-viewer]",
            f"type={vv['type']}",
            f"host-subject={vv['host-subject']}",
            f"delete-this-file={vv['delete-this-file']}",
            f"secure-attention={vv['secure-attention']}",
            f"toggle-fullscreen={vv['toggle-fullscreen']}",
            f"title={vv['title']}",
            f"tls-port={vv['tls-port']}",
            f"proxy=http://{proxy_url}:3128",
            f"password={vv['password']}",
            f"release-cursor={vv['release-cursor']}",
            f"host={vv['host']}",
            f"ca={vv['ca']}",
        ]
        config_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        return json.dumps({"configFile": str(config_path)})
