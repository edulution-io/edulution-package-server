# edulution-linbo-vdi

Virtual Desktop Infrastructure (VDI) for [linuxmuster.net](https://linuxmuster.net) on Proxmox.

Manages the full lifecycle of VDI desktops: creating master VMs from LINBO images, cloning them, auto-scaling the pool, brokering SPICE connections to users, and monitoring VM health.

## Package structure

The project is a standard Python package (`edulution_linbo_vdi`) that can be installed with `pip` and imported as a library, run as a CLI, or served as a FastAPI application.

```
src/edulution_linbo_vdi/
  __init__.py          # VdiContext -- central context object
  config.py            # VdiConfig dataclass, loaded from JSON
  models.py            # Typed data models (GroupConfig, DeviceEntry, ...)
  exceptions.py        # Custom exception hierarchy
  proxmox_client.py    # Wrapper around proxmoxer
  command_runner.py    # Local/SSH command execution (no shell=True)
  device_store.py      # devices.csv, start.conf, image.info parsing
  nmap_checker.py      # Unified nmap health-checks
  vm_helpers.py        # wait_for_vm_status(), timestamp utilities
  master.py            # MasterManager: create, remove, get_states
  clone.py             # CloneManager: build, remove, get_states
  broker.py            # ConnectionBroker: assign VMs, manage SPICE files
  service.py           # VdiService: main loop
  api.py               # FastAPI app factory (direct calls, no subprocess)
  cli.py               # CLI entry-points
  logging_config.py    # Centralised logging setup
```

## How it works

1. **Master creation** -- The service reads VDI group configs (`/srv/linbo/start.conf.<group>.vdi`), creates a VM on Proxmox matching the specs, boots it via LINBO to sync the image, verifies health with nmap, and converts it to a template.

2. **Clone scaling** -- Clones are created from the master template. The service maintains a pool between `minimum_vms` and `maximum_vms`, keeping `prestarted_vms` available at all times. Outdated or failed clones are automatically removed.

3. **Connection brokering** -- When a user requests a desktop, the broker assigns a free clone (preferring previously assigned or unused VMs), updates the VM description, and returns a SPICE `.vv` connection file.

4. **API** -- All operations are exposed via a FastAPI REST API on port 5555, authenticated with an API secret header.

## Installation

### From source (development)

```bash
git clone https://github.com/edulution-io/edulution-linbo-vdi.git
cd edulution-linbo-vdi

# Create a virtual environment
uv venv .venv
source .venv/bin/activate

# Install in editable mode
uv pip install -e .
```

### From Debian package (production)

```bash
apt-get install edulution-linbo-vdi
```

The package installs:
- The Python package into the system Python path
- Thin wrapper at `/usr/lib/edulution-linbo-vdi/vdi-service.py`
- Systemd unit `edulution-linbo-vdi.service`
- Config templates at `/usr/lib/edulution-linbo-vdi/etc/`

The REST API is provided by [linuxmuster-api](https://github.com/hermanntoast/linuxmuster-api) (endpoints under `/v1/vdi/`).

## Interactive setup

The fastest way to get started is the interactive setup wizard. It creates all
required config files step by step:

```bash
uv run vdi-setup
```

The wizard walks through three stages:

1. **VDI service config** (`/etc/edulution/linbo-vdi/vdiConfig.json`) --
   Proxmox connection (node, IP, user, password) and API settings
   (multi-school, timeout, SPICE proxy, API secret).
   After writing the config it can optionally test the Proxmox connection.

2. **VDI group setup** (repeatable for multiple groups) --
   The wizard asks for group name, OS type (Windows 10 / 11 / Ubuntu),
   boot mode (BIOS / EFI), and base image filename. Everything else
   (VM specs, network, master VM, clone pool) has sensible defaults that
   are shown as a summary. Press Enter to accept them all, or choose
   "Customize" to adjust individual values.

   It then generates:
   - `/srv/linbo/start.conf.<group>` -- LINBO start.conf with partitions and OS section
   - `/srv/linbo/start.conf.<group>.vdi` -- VDI group config (BIOS or EFI with SPICE settings)
   - Entries in `devices.csv` -- master + all clones with auto-incremented MAC, IP, and VMID

3. **Next steps** -- reminds you to prepare the OS image and start the services.

All files are written with `sudo` when necessary.

If you prefer to create the config files manually, see the sections below.

## Configuration

### 1. VDI service config

Edit `/etc/edulution/linbo-vdi/vdiConfig.json`:

```json
{
    "node": "hv01",
    "hvIp": "10.0.8.10",
    "hvUser": "root@pam",
    "password": "Muster!",
    "nmapPorts": "135,445,49665",
    "vdiLocalService": true,
    "serverIP": "10.0.0.1",
    "debugging": true,
    "multischool": true,
    "timeoutConnectionRequest": 1000,
    "proxy_url": "server.demo.multi.schule",
    "lmn-api-secret": "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
}
```

| Key | Description |
|---|---|
| `node` | Proxmox node name (must match exactly) |
| `hvIp` | Proxmox host IP |
| `hvUser` | Proxmox API user (e.g. `root@pam`) |
| `password` | Proxmox API password |
| `nmapPorts` | Comma-separated ports for health-checks |
| `vdiLocalService` | `true` = run on the server itself, `false` = remote via SSH |
| `serverIP` | Server IP (only used when `vdiLocalService` is `false`) |
| `timeoutConnectionRequest` | Seconds before a connection assignment expires |
| `proxy_url` | SPICE proxy hostname for `.vv` files |
| `lmn-api-secret` | Shared secret for API authentication |

### 2. LINBO group start.conf

Create `/srv/linbo/start.conf.<group>` (standard LINBO config):

```ini
[LINBO]
Server = 10.0.0.1
Group = win10-vdi
Cache = /dev/sda2
RootTimeout = 600
DownloadType = torrent
SystemType = bios64
School = default-school

[Partition]
Dev = /dev/sda1
Label = windows
Size = 70G
Id = 7
FSType = ntfs

[Partition]
Dev = /dev/sda2
Label = cache
Size =
Id = 83
FSType = ext4

[OS]
Name = Windows 10
Version = 22H2
BaseImage = win10-22h2-pro-education.qcow2
Boot = /dev/sda1
Root = /dev/sda1
Kernel = auto
StartEnabled = yes
Autostart = yes
AutostartTimeout = 3
```

### 3. VDI group config

Create `/srv/linbo/start.conf.<group>.vdi`:

```json
{
    "activated": "yes",
    "vmids": [1701],
    "bios": "seabios",
    "boot": "cn",
    "cores": 4,
    "memory": 4096,
    "ostype": "win10",
    "name": "lmn72.v001-master",
    "room": "vdi",
    "hostname": "vdi-master",
    "group": "win10-vdi",
    "ip": "10.0.0.50",
    "storage": "local-zfs",
    "scsihw": "virtio-scsi-pci",
    "size": 120,
    "format": "raw",
    "bridge": "vmbr0",
    "tag": 100,
    "mac": "AA:EE:4E:B5:5C:00",
    "display": "type=qxl,memory=16",
    "audio": "device=ich9-intel-hda,driver=spice",
    "usb0": "host=spice,usb3=1",
    "spice_enhancements": "foldersharing=1,videostreaming=all",
    "minimum_vms": 6,
    "maximum_vms": 10,
    "prestarted_vms": 1,
    "timeout_building_master": 750,
    "timeout_building_clone": 400
}
```

### 4. Register devices in devices.csv

Add master and clone entries to the appropriate `devices.csv`:

```
vdi;vdi-master;win10-vdi;AA:EE:4E:B5:5C:00;10.0.0.50;;;;classroom-studentcomputer;;1;;;;;
vdi;vdi-client01;win10-vdi;AA:EE:4E:B5:5C:01;10.0.0.201;;;;classroom-studentcomputer;;1;1801;;;;
vdi;vdi-client02;win10-vdi;AA:EE:4E:B5:5C:02;10.0.0.202;;;;classroom-studentcomputer;;1;1802;;;;
vdi;vdi-client03;win10-vdi;AA:EE:4E:B5:5C:03;10.0.0.203;;;;classroom-studentcomputer;;1;1803;;;;
```

- The master MAC address must match between `devices.csv` and the `.vdi` config
- Clone VMIDs go in field 12
- Clone MAC addresses can be chosen freely

### 5. Prepare the image

- Allow ports 135, 445, 49665 through the Windows Firewall
- Install QEMU Guest Agent and SPICE Guest Tools

## Testing on a live environment (without installing the Debian package)

You can test the package directly on a linuxmuster.net server with Proxmox --
no systemd service or Debian package needed. Just `uv` and the repo.

### 1. Setup on the server

```bash
# Clone the repo
git clone https://github.com/edulution-io/edulution-linbo-vdi.git /opt/edulution-linbo-vdi
cd /opt/edulution-linbo-vdi

# Install uv (if not already available)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Create venv and install the package
uv venv .venv
uv pip install -e .

# Run the interactive setup wizard
uv run vdi-setup
```

### 2. Query master and clone states

```bash
# All master states
uv run vdi-states -m

# Master states for a specific group
uv run vdi-states win10-vdi -m

# All clone states
uv run vdi-states -c

# Clone states for a specific group
uv run vdi-states win10-vdi -c
```

### 3. Run the service in the foreground

This starts the main loop (master handling, clone scaling, cleanup).
It runs in the foreground -- press `Ctrl+C` to stop.

```bash
uv run vdi-service
```

### 4. REST API

The API is provided by [linuxmuster-api](https://github.com/hermanntoast/linuxmuster-api)
and available under `/v1/vdi/` when `edulution-linbo-vdi` is installed.

See the linuxmuster-api Swagger docs for endpoint details.

### 5. Interactive Python session

For debugging or exploring the API interactively:

```bash
uv run python
```

```python
from edulution_linbo_vdi import VdiContext
from edulution_linbo_vdi.master import MasterManager
from edulution_linbo_vdi.clone import CloneManager
from edulution_linbo_vdi.device_store import get_vdi_groups

ctx = VdiContext.from_config_file()
groups = get_vdi_groups()
print("Active groups:", groups["general"]["active_groups"])

# Check master states
masters = MasterManager(ctx)
for name in groups["general"]["active_groups"]:
    states = masters.get_states(groups["groups"][name], name)
    if states:
        print(f"\n{name}:", states["summary"])
```

### Systemd service (production)

After installing the Debian package, the service is managed via systemd:

```bash
systemctl start edulution-linbo-vdi       # Main service loop
systemctl status edulution-linbo-vdi
journalctl -u edulution-linbo-vdi -f      # Follow logs
```

## Usage as a library

The package can be imported and used from any Python application:

```python
from edulution_linbo_vdi import VdiContext
from edulution_linbo_vdi.clone import CloneManager
from edulution_linbo_vdi.broker import ConnectionBroker
from edulution_linbo_vdi.device_store import get_vdi_groups

ctx = VdiContext.from_config_file("/etc/edulution/linbo-vdi/vdiConfig.json")
groups = get_vdi_groups()

# Query clone states
clones = CloneManager(ctx)
states = clones.get_states(groups["groups"]["win10-vdi"], "win10-vdi")

# Request a connection
broker = ConnectionBroker(ctx)
conn = broker.get_connection("win10-vdi", "teacher01")
```

## License

GPL-3.0-or-later
