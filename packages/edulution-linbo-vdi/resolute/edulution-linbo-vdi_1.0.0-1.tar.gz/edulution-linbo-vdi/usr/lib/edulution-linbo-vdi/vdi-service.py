#!/usr/bin/env python3
"""Thin wrapper -- delegates to the edulution_linbo_vdi package."""

from edulution_linbo_vdi.cli import run_service

if __name__ == "__main__":
    run_service()
