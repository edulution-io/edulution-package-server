"""Example: using edulution-linbo-vdi as a library."""

from edulution_linbo_vdi import VdiContext
from edulution_linbo_vdi.clone import CloneManager
from edulution_linbo_vdi.broker import ConnectionBroker
from edulution_linbo_vdi.device_store import get_vdi_groups

# 1) Create context from config file
ctx = VdiContext.from_config_file("/etc/edulution/linbo-vdi/vdiConfig.json")

# 2) Discover VDI groups
groups = get_vdi_groups()
print("Active groups:", groups["general"]["active_groups"])

# 3) Query clone states
clones = CloneManager(ctx)
for group_name in groups["general"]["active_groups"]:
    group_data = groups["groups"][group_name]
    states = clones.get_states(group_data, group_name)
    if states:
        print(f"\n{group_name} summary:", states["summary"])

# 4) Request a connection for a user
broker = ConnectionBroker(ctx)
try:
    conn = broker.get_connection("win10-vdi", "lehrer01")
    print("Connection info:", conn)
except Exception as e:
    print(f"No connection available: {e}")
