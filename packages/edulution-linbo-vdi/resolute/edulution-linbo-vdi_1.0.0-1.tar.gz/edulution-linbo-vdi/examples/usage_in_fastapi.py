"""Example: mounting edulution-linbo-vdi into an existing FastAPI app."""

from fastapi import FastAPI
from edulution_linbo_vdi import VdiContext
from edulution_linbo_vdi.api import create_app as create_vdi_app

# Your main application
app = FastAPI(title="My School Server")

# Mount VDI endpoints under /vdi
ctx = VdiContext.from_config_file()
vdi_app = create_vdi_app(ctx)
app.mount("/vdi", vdi_app)

# VDI endpoints are now available at:
#   /vdi/api/status/clones
#   /vdi/api/status/masters
#   /vdi/api/connection/request


@app.get("/")
def root():
    return {"message": "School Server API", "vdi_docs": "/vdi/docs"}
