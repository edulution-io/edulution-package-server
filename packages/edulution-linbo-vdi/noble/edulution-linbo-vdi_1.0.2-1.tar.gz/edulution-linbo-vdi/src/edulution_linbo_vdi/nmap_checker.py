"""Unified nmap health-checks (replaces duplicated logic in buildClone/createNewMaster)."""

from __future__ import annotations

import logging
import time

import nmap

logger = logging.getLogger(__name__)

WINDOWS_PORTS = {"RPC": "135", "SMB": "445", "SVCHOST": "49665"}
LINUX_PORTS = {"SSH": "22"}


def is_any_port_open(ip: str) -> bool:
    """One-shot: return True if any expected Windows/Linux port is currently open."""
    scanner = nmap.PortScanner()
    for ports in (WINDOWS_PORTS, LINUX_PORTS):
        for port in ports.values():
            try:
                result = scanner.scan(ip, port)
                if result["scan"][ip]["tcp"][int(port)]["state"] == "open":
                    return True
            except KeyError:
                continue
    return False


def check_vm_health(
    ip: str,
    timeout: int,
    vmid: str = "",
    poll_interval: float = 2.0,
) -> bool:
    """Scan *ip* for open Windows/Linux ports until *timeout* seconds elapse.

    Returns *True* as soon as any expected port is found open or closed
    (indicating the OS has booted), *False* on timeout.
    """
    scanner = nmap.PortScanner()
    label = f"VM {vmid}" if vmid else ip
    logger.info("Scanning for open ports on %s (timeout=%ds)", label, timeout)

    deadline = time.time() + timeout
    while time.time() < deadline:
        for name, port in WINDOWS_PORTS.items():
            try:
                result = scanner.scan(ip, port)
                state = result["scan"][ip]["tcp"][int(port)]["state"]
                logger.debug("Port %s (%s): %s", port, name, state)
                if state == "open":
                    logger.info("Boot check on %s succeeded (port %s %s)", label, name, state)
                    return True
            except KeyError:
                continue

        for name, port in LINUX_PORTS.items():
            try:
                result = scanner.scan(ip, port)
                state = result["scan"][ip]["tcp"][int(port)]["state"]
                logger.debug("Port %s (%s): %s", port, name, state)
                if state == "open":
                    logger.info("Boot check on %s succeeded (port %s %s)", label, name, state)
                    return True
            except KeyError:
                continue

        logger.debug("%s seems not ready yet, no open ports found", label)
        time.sleep(poll_interval)

    logger.warning("Health-check timed out for %s after %ds", label, timeout)
    return False
