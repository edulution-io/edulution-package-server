"""CloneManager -- build, remove, and query clone VM states."""

from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime
from multiprocessing.pool import ThreadPool
from typing import TYPE_CHECKING, Any

from . import device_store
from .nmap_checker import check_vm_health
from .vm_helpers import now_float, now_timestamp, wait_for_vm_status

if TYPE_CHECKING:
    from .__init__ import VdiContext

logger = logging.getLogger(__name__)


class CloneManager:
    """Manages clone VMs for VDI groups."""

    def __init__(self, ctx: VdiContext) -> None:
        self._ctx = ctx
        self._px = ctx.proxmox
        self._cmd = ctx.command_runner

    # ------------------------------------------------------------------
    # Public: get states
    # ------------------------------------------------------------------

    def get_states(self, group_data: dict, vdi_group: str) -> dict | None:
        """Gather clone VM states for *vdi_group*.  Returns the legacy dict."""
        school_id = device_store.get_school_id(vdi_group)
        if not school_id:
            return None

        devices = device_store.devices_loader_raw(school_id)
        id_range = device_store.get_vmid_range(devices, vdi_group)

        clone_states = self._get_vm_info_multithreaded(id_range, vdi_group, "clone")

        # Expand device info
        for vmid in clone_states:
            for device in devices:
                if vmid == device[11]:
                    clone_states[vmid]["room"] = device[0]
                    clone_states[vmid]["hostname"] = device[1]
                    clone_states[vmid]["ip"] = device[4]
                    clone_states[vmid]["mac"] = device[3]

        # SMB status for user assignment
        logged_in = self._get_smbstatus(school_id)
        if logged_in:
            for user, user_info in logged_in.items():
                for vmid in clone_states:
                    if user_info["ip"] == clone_states[vmid].get("ip"):
                        clone_states[vmid]["user"] = user_info["full"]
                    if "user" not in clone_states[vmid]:
                        clone_states[vmid]["user"] = ""
        else:
            for vmid in clone_states:
                clone_states[vmid]["user"] = ""

        # Summary
        timeout_cr = self._ctx.config.timeout_connection_request
        allocated = 0
        existing = len(clone_states)
        available = 0
        building = 0
        failed = 0
        registered = len(id_range)
        now = now_float()

        for vmid in clone_states:
            try:
                bs = clone_states[vmid].get("buildstate", "")
                if bs == "building":
                    building += 1
                    continue
                if bs == "failed":
                    failed += 1
                    continue
                if bs == "finished":
                    lcrt = clone_states[vmid].get("lastConnectionRequestTime", "")
                    user = clone_states[vmid].get("user", "")
                    if lcrt == "":
                        if user == "":
                            available += 1
                        else:
                            allocated += 1
                    else:
                        if user == "" and (now - float(lcrt)) > timeout_cr:
                            available += 1
                        elif user != "" or (now - float(lcrt)) <= timeout_cr:
                            allocated += 1
            except Exception as exc:
                logger.error("Error computing summary for %s: %s", vmid, exc)

        clone_states["summary"] = {
            "allocated_vms": allocated,
            "available_vms": available,
            "existing_vms": existing,
            "registered_vms": registered,
            "building_vms": building,
            "failed_vms": failed,
        }
        return clone_states

    def get_all_states(self) -> dict:
        """Return clone states for every VDI group."""
        vdi_groups = device_store.get_vdi_groups()
        result: dict = {}
        for vdi_group, group_data in vdi_groups["groups"].items():
            states = self.get_states(group_data, vdi_group)
            if not states:
                continue
            entry: dict = {"summary": states["summary"]}
            states_copy = {k: v for k, v in states.items() if k != "summary"}
            entry["clone_vms"] = states_copy
            result[vdi_group] = entry
        return result

    # ------------------------------------------------------------------
    # Public: build clone
    # ------------------------------------------------------------------

    def build_clone(self, clone_states: dict, group_data: dict, master_vmid: str, vdi_group: str) -> bool:
        school_id = device_store.get_school_id(vdi_group)
        if not school_id:
            return False
        devices = device_store.devices_loader_raw(school_id)
        id_range = device_store.get_vmid_range(devices, vdi_group)

        clone_vmid = self._get_next_available_vmid(clone_states, id_range, vdi_group)
        if not clone_vmid:
            return False

        master_name = group_data["name"]
        clone_name_prefix = master_name.replace("master", "")
        clone_name = f"{clone_name_prefix}clone-{clone_vmid}"
        clone_description = self._generate_clone_description(group_data, master_vmid, clone_name, vdi_group)

        # Clone the master
        self._px.clone_vm(
            source_vmid=master_vmid,
            newid=clone_vmid,
            name=clone_name,
            description=json.dumps(clone_description),
        )
        logger.info("[%s] Template being cloned to VM %s", vdi_group, clone_vmid)

        # Set correct MAC
        net_info = device_store.find_device_by_vmid(devices, clone_vmid)
        if not net_info:
            logger.error("[%s] No device entry for clone %s", vdi_group, clone_vmid)
            return False

        nic_model = group_data.get("nic_model", "virtio")
        clone_net = f"bridge={group_data['bridge']},{nic_model}={net_info['mac']}"
        if group_data.get("tag", 0) != 0:
            clone_net += f",tag={group_data['tag']}"

        logger.info("[%s] Assigning MAC %s to %s", vdi_group, net_info["mac"], clone_vmid)
        self._px.set_vm_config(clone_vmid, net0=clone_net)

        # Start clone
        self._px.start_vm(clone_vmid)
        logger.info("[%s] VM %s started", vdi_group, clone_vmid)
        wait_for_vm_status(self._px, clone_vmid, "running", timeout=10, poll_interval=2, vdi_group=vdi_group)

        # Health check
        timeout_building = group_data["timeout_building_clone"]
        if check_vm_health(net_info["ip"], timeout_building, vmid=clone_vmid):
            clone_description["buildstate"] = "finished"
            self._px.set_vm_description(clone_vmid, clone_description)
            logger.info("[%s] Clone %s created successfully", vdi_group, clone_vmid)
        else:
            clone_description["buildstate"] = "failed"
            self._px.set_vm_description(clone_vmid, clone_description)
            logger.info("[%s] Clone %s creation failed", vdi_group, clone_vmid)
        return True

    # ------------------------------------------------------------------
    # Public: remove clones
    # ------------------------------------------------------------------

    def remove_clone(self, vm_amount_to_delete: int, clone_states: dict, vdi_group: str) -> None:
        logger.debug("[%s] Begin remove clone", vdi_group)
        states = {k: v for k, v in clone_states.items() if k != "summary"}
        assigned = self._get_assigned_ids(states)
        removeable: list[str] = []
        for vmid, info in states.items():
            if vmid not in assigned and isinstance(info, dict) and "status" in info:
                removeable.append(vmid)
                if len(removeable) >= vm_amount_to_delete:
                    break
        for vmid in removeable:
            self._remove_vm(vmid)

    def remove_outdated_clones(self, outdated_clones: list[dict], clone_states: dict, vdi_group: str) -> None:
        assigned = self._get_assigned_ids(clone_states)
        threads: list[threading.Thread] = []
        for clone_info in outdated_clones:
            vmid = clone_info["vmid"]
            if vmid not in assigned:
                t = threading.Thread(target=self._remove_vm, args=(vmid,))
                threads.append(t)
                t.start()
        for t in threads:
            t.join()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_vm_info_multithreaded(self, vmids: list[str], vdi_group: str, vm_type: str) -> dict:
        pool = ThreadPool(processes=5)
        procs = [pool.apply_async(func=self._get_vm_info_by_api, args=(vmid, vdi_group, vm_type)) for vmid in vmids]
        data: dict = {}
        for p in procs:
            result = p.get()
            if result:
                data[result["vmid"]] = result
        pool.close()
        pool.join()
        return data

    def _get_vm_info_by_api(self, vmid: str, vdi_group: str, vm_type: str = "clone") -> dict | None:
        config = self._px.vm_config(vmid)
        if config is None:
            logger.debug("[%s] VM %s does not exist on %s", vdi_group, vmid, self._px.node)
            return None

        try:
            response = self._px.vm_status(vmid)
            config["status"] = response["qmpstatus"]
            config["uptime"] = response.get("uptime", 0)
            config["spicestatus"] = ""
        except Exception:
            logger.error("[%s] Cannot parse VM %s information", vdi_group, vmid)
            return None

        try:
            desc = json.loads(config.get("description", "{}"))
            if vm_type == "clone":
                config["image"] = desc.get("image", "")
                config["master"] = desc.get("master", "")
                config["lastConnectionRequestUser"] = desc.get("lastConnectionRequestUser", "")
                config["lastConnectionRequestTime"] = desc.get("lastConnectionRequestTime", "")
            if vm_type == "master":
                config["timestamp"] = desc.get("timestamp", "")
            config["imagesize"] = desc.get("imagesize", "")
            config["dateOfCreation"] = desc.get("dateOfCreation", "")
            config["buildstate"] = desc.get("buildstate", "")
            config["vmid"] = vmid
            config["group"] = desc.get("group", "")
            config.pop("description", None)
            logger.debug("[%s] VM %s parsed", vdi_group, vmid)
            return config
        except Exception as exc:
            logger.error("[%s] Failed to extract description for VM %s: %s", vdi_group, vmid, exc)
            return None

    def _get_next_available_vmid(self, clone_states: dict, id_range: list[str], vdi_group: str) -> str | None:
        for vmid in id_range:
            if vmid not in clone_states:
                logger.info("[%s] Next free VM ID: %s", vdi_group, vmid)
                return vmid
        logger.warning("[%s] No free VMIDs left for cloning", vdi_group)
        return None

    def _generate_clone_description(self, group_data: dict, master_vmid: str, clone_name: str, vdi_group: str) -> dict:
        desc: dict[str, str] = {
            "name": clone_name,
            "dateOfCreation": now_timestamp(),
            "master": master_vmid,
            "lastConnectionRequestUser": "",
            "lastConnectionRequestTime": "",
            "group": group_data["group"],
        }
        device_path = f"/srv/linbo/start.conf.{vdi_group}"
        start_conf = device_store.start_conf_loader(device_path)
        image_name = ""
        for os_section in start_conf["os"]:
            image_name = os_section.get("BaseImage", "")
        if image_name:
            image_info = device_store.image_info_loader(image_name)
            desc["imagesize"] = image_info.get("imagesize", "")
            desc["image"] = image_name
        desc["buildstate"] = "building"
        return desc

    def _get_assigned_ids(self, clone_states: dict) -> list[str]:
        timeout_cr = self._ctx.config.timeout_connection_request
        assigned: list[str] = []
        now = now_float()
        for vmid, info in clone_states.items():
            if not isinstance(info, dict):
                continue
            try:
                lcrt = info.get("lastConnectionRequestTime", "")
                if lcrt and (now - float(lcrt)) < timeout_cr:
                    assigned.append(vmid)
                if info.get("user", ""):
                    assigned.append(vmid)
            except (ValueError, TypeError):
                continue
        return list(set(assigned))

    def _remove_vm(self, vmid: str) -> None:
        try:
            status = self._px.vm_status(vmid).get("qmpstatus", "")
            if status != "stopped":
                self._px.stop_vm(vmid)
                time.sleep(3)
            self._px.delete_vm(vmid)
            logger.info("Deleted clone VM %s", vmid)
        except Exception as exc:
            logger.error("Error removing clone %s: %s", vmid, exc)

    def _get_smbstatus(self, school_id: str) -> dict | None:
        """Get logged-in users from smbstatus."""
        smbstatus_command = "smbstatus | grep users"
        if school_id == "default-school":
            lines = self._cmd.run(smbstatus_command)
            logged_in: dict = {}
            for line in lines:
                line_str = line.decode("ascii", errors="replace") if isinstance(line, bytes) else line
                parts = line_str.split()
                if len(parts) < 4:
                    continue
                ip = parts[3]
                user = parts[1]
                if "\\" not in user:
                    continue
                domain, user = user.split("\\")
                if parts[2] == "users":
                    logged_in[user] = {"ip": ip, "domain": domain, "full": f"{domain}\\{user}"}
            return logged_in
        else:
            try:
                import paramiko
                net_conf_list = self._cmd.run("net conf list")
                for line in net_conf_list:
                    line_str = line.decode("ascii", errors="replace") if isinstance(line, bytes) else line
                    if school_id in line_str and "msdfs proxy" in line_str:
                        fileserver = line_str.split(" ")[3]
                        suffix = f"/{school_id}\n"
                        fileserver = fileserver.rstrip(suffix).lstrip("//")
                        with paramiko.SSHClient() as ssh:
                            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                            ssh.connect(fileserver, port=22, username="root")
                            _in, out, err = ssh.exec_command(smbstatus_command)
                            err.channel.recv_exit_status()
                            logged_in = {}
                            for sline in out.readlines():
                                parts = sline.split()
                                if len(parts) < 5:
                                    continue
                                ip = parts[4]
                                user = parts[1]
                                if "\\" not in user:
                                    continue
                                domain, user = user.split("\\")
                                if parts[3] == "users":
                                    logged_in[user] = {"ip": ip, "domain": domain, "full": f"{domain}\\{user}"}
                        return logged_in
            except Exception as exc:
                logger.error("Error getting smbstatus from fileserver: %s", exc)
        return None
