"""
Tests for linuxmusterTools.linbo.linbo_sync: building/running a linbo-remote
command (LinboRemote) and listing its running tmux sessions.
"""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

import linuxmusterTools.linbo.linbo_sync as linbo_sync_module

from linuxmusterTools.linbo.linbo_sync import (
    LinboRemote,
    LinboRemoteParameterError,
    attach_command,
    list_running_sessions,
)


# ── LinboRemote parameter validation ────────────────────────────────────


def make_remote(**kwargs):
    # cmd has no nr on purpose: LinboRemote.run() tests below aren't about nr
    # validation and shouldn't need to resolve a group via Devices/devices.csv.
    return LinboRemote(clients=['10.0.0.5'], cmd='reboot', **kwargs)


def test_build_rejects_mutually_exclusive_targets():
    remote = LinboRemote(clients=['10.0.0.5'], group='win10', cmd='sync:1')

    with pytest.raises(LinboRemoteParameterError):
        remote.build()


def test_build_rejects_no_target():
    remote = LinboRemote(cmd='sync:1')

    with pytest.raises(LinboRemoteParameterError):
        remote.build()


@pytest.mark.parametrize("cmd", ["initcache", "initcache:rsync", "initcache:multicast", "initcache:torrent"])
def test_build_accepts_initcache_with_or_without_a_type(cmd):
    # Without a type, linbo-remote takes the one of start.conf (#42).
    LinboRemote(clients=['10.0.0.5'], cmd=cmd)._check_cmd()


def test_build_rejects_initcache_with_an_unknown_type():
    with pytest.raises(LinboRemoteParameterError):
        LinboRemote(clients=['10.0.0.5'], cmd='initcache:ftp')._check_cmd()


def test_build_rejects_unknown_command():
    remote = LinboRemote(clients=['10.0.0.5'], cmd='frobnicate:1')

    with pytest.raises(LinboRemoteParameterError):
        remote.build()


def test_build_rejects_option_on_command_without_one():
    remote = LinboRemote(clients=['10.0.0.5'], cmd='partition:1')

    with pytest.raises(LinboRemoteParameterError):
        remote.build()


# ── LinboRemote nr validation against start.conf ────────────────────────


OS_CONFIG = [
    {'BaseImage': 'a.qcow2', 'Root': '/dev/sda1'},
    {'BaseImage': 'b.qcow2', 'Root': '/dev/sda2'},
]


def test_check_nr_accepts_valid_os_position():
    remote = LinboRemote(group='win10', cmd='sync:2')

    with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=OS_CONFIG):
        remote.build()  # must not raise


def test_check_nr_rejects_out_of_range_os_position():
    remote = LinboRemote(group='win10', cmd='sync:5')

    with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=OS_CONFIG):
        with pytest.raises(LinboRemoteParameterError):
            remote.build()


def make_fake_startconf_mgr(group, partitions_count):
    linbo_config = MagicMock()
    linbo_config.Partitions = [MagicMock() for _ in range(partitions_count)]
    mgr = MagicMock()
    mgr.load_linbo_startconf.return_value = linbo_config
    return mgr


def test_check_nr_accepts_valid_partition_for_format():
    remote = LinboRemote(group='win10', cmd='format:2')

    with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=OS_CONFIG):
        with patch(
            'linuxmusterTools.linbo.linbo_sync.LinboConfigManager',
            return_value=make_fake_startconf_mgr('win10', 2),
        ):
            remote.build()  # must not raise


def test_check_nr_rejects_unknown_partition_for_format():
    remote = LinboRemote(group='win10', cmd='format:9')

    with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=OS_CONFIG):
        with patch(
            'linuxmusterTools.linbo.linbo_sync.LinboConfigManager',
            return_value=make_fake_startconf_mgr('win10', 2),
        ):
            with pytest.raises(LinboRemoteParameterError):
                remote.build()


def test_check_nr_rejects_missing_start_conf():
    remote = LinboRemote(group='win10', cmd='sync:1')

    with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=None):
        with pytest.raises(LinboRemoteParameterError):
            remote.build()


def make_fake_devices(devices_list):
    fake = MagicMock()
    fake.devices = devices_list
    return fake


def test_check_nr_resolves_group_from_ip():
    devices = [{'ip': '10.0.0.5', 'hostname': 'pc001', 'group': 'win10', 'room': 'room1'}]
    remote = LinboRemote(clients=['10.0.0.5'], cmd='sync:2')

    with patch('linuxmusterTools.linbo.linbo_sync.Devices', return_value=make_fake_devices(devices)):
        with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=OS_CONFIG):
            remote.build()  # must not raise


def test_check_nr_resolves_group_from_hostname():
    devices = [{'ip': '10.0.0.5', 'hostname': 'pc001', 'group': 'win10', 'room': 'room1'}]
    remote = LinboRemote(clients=['pc001'], cmd='sync:2')

    with patch('linuxmusterTools.linbo.linbo_sync.Devices', return_value=make_fake_devices(devices)):
        with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=OS_CONFIG):
            remote.build()  # must not raise


def test_check_nr_resolves_group_from_school_prefixed_hostname():
    devices = [{'ip': '10.0.0.5', 'hostname': 'pc001', 'group': 'win10', 'room': 'room1'}]
    remote = LinboRemote(clients=['lehrer-pc001'], cmd='sync:2', school='lehrer')

    with patch('linuxmusterTools.linbo.linbo_sync.lr.getval', return_value=['lehrer']):
        with patch('linuxmusterTools.linbo.linbo_sync.Devices', return_value=make_fake_devices(devices)):
            with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=OS_CONFIG):
                remote.build()  # must not raise


def test_check_nr_rejects_out_of_range_for_ip_resolved_group():
    devices = [{'ip': '10.0.0.5', 'hostname': 'pc001', 'group': 'win10', 'room': 'room1'}]
    remote = LinboRemote(clients=['10.0.0.5'], cmd='sync:5')

    with patch('linuxmusterTools.linbo.linbo_sync.Devices', return_value=make_fake_devices(devices)):
        with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=OS_CONFIG):
            with pytest.raises(LinboRemoteParameterError):
                remote.build()


def test_check_nr_checks_every_group_in_a_room():
    devices = [
        {'ip': '10.0.0.5', 'hostname': 'pc001', 'group': 'win10', 'room': 'room1'},
        {'ip': '10.0.0.6', 'hostname': 'pc002', 'group': 'linux', 'room': 'room1'},
    ]
    remote = LinboRemote(room='room1', cmd='sync:2')

    def fake_read_config(group):
        return OS_CONFIG if group == 'win10' else OS_CONFIG[:1]

    with patch('linuxmusterTools.linbo.linbo_sync.Devices', return_value=make_fake_devices(devices)):
        with patch('linuxmusterTools.linbo.linbo_sync.read_config', side_effect=fake_read_config):
            # position 2 doesn't exist for the 'linux' group (only 1 OS there)
            with pytest.raises(LinboRemoteParameterError):
                remote.build()


def test_check_nr_rejects_when_group_cannot_be_resolved():
    remote = LinboRemote(clients=['10.0.0.5'], cmd='sync:1')

    with patch('linuxmusterTools.linbo.linbo_sync.Devices', return_value=make_fake_devices([])):
        with pytest.raises(LinboRemoteParameterError):
            remote.build()


# ── LinboRemote image_name (linuxmuster-linbo7 7.4.21) ──────────────────


@pytest.mark.parametrize("cmd", [
    "image_name:noble,create_image:1,upload_image:1",
    "image_name:noble_2-test,create_image:1:new kernel",
    "sync:1,image_name:noble,upload_image:2",
])
def test_check_cmd_accepts_image_name(cmd):
    remote = LinboRemote(group='win10', cmd=cmd)

    with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=OS_CONFIG):
        remote._check_cmd()


@pytest.mark.parametrize("cmd", [
    "image_name,create_image:1",                         # no name
    "image_name:,create_image:1",                        # empty name
    "image_name:noble.qcow2,create_image:1",             # extension
    "image_name:../noble,create_image:1",                # path
    "image_name:1:noble,create_image:1",                 # field too many
    "image_name:noble",                                  # no image command
    "create_image:1,image_name:noble",                   # image command before
    "image_name:noble,sync:1",                           # no image command
    "image_name:noble,create_image:1,create_qdiff:1",    # qdiff
    "upload_qdiff:1,image_name:noble,upload_image:1",    # qdiff before
])
def test_check_cmd_rejects_invalid_image_name(cmd):
    remote = LinboRemote(group='win10', cmd=cmd)

    with patch('linuxmusterTools.linbo.linbo_sync.read_config', return_value=OS_CONFIG):
        with pytest.raises(LinboRemoteParameterError):
            remote._check_cmd()


# ── LinboRemote.run() ────────────────────────────────────────────────────


def test_run_executes_the_built_command():
    remote = make_remote()

    with patch('linuxmusterTools.linbo.linbo_sync.subprocess.run') as run:
        run.return_value = MagicMock(returncode=0, stdout='')
        remote.run()

    args, kwargs = run.call_args
    assert args[0] == '/usr/sbin/linbo-remote -i 10.0.0.5 -c reboot'.split()
    assert kwargs['stderr'] is not None
    assert kwargs['text'] is True


def test_run_returns_success_status():
    remote = make_remote()

    with patch('linuxmusterTools.linbo.linbo_sync.subprocess.run') as run:
        run.return_value = MagicMock(returncode=0, stdout='Started with PID 123.\n')
        result = remote.run()

    assert result == {'status': 0, 'msg': 'Started with PID 123.\n'}


def test_run_detects_offline_hosts():
    remote = make_remote()
    output = 'pc001 Not online, host skipped.\npc002 Not online, host skipped.\n'

    with patch('linuxmusterTools.linbo.linbo_sync.subprocess.run') as run:
        run.return_value = MagicMock(returncode=0, stdout=output)
        result = remote.run()

    assert result == {'status': 1, 'msg': 'Not online, host skipped: pc001,pc002'}


def test_run_raises_on_nonzero_exit():
    remote = make_remote()
    output = (
        'Usage: linbo-remote <options>\n'
        '...\n'
        '\n'
        'No hosts in group win10!'
    )

    with patch('linuxmusterTools.linbo.linbo_sync.subprocess.run') as run:
        run.return_value = MagicMock(returncode=1, stdout=output)
        with pytest.raises(LinboRemoteParameterError, match='No hosts in group win10!'):
            remote.run()


# ── list_running_sessions() / attach_command() ──────────────────────────


def test_attach_command_uses_underscore_separated_session_name():
    # tmux itself replaces the dot with an underscore in session names
    # (dots are significant in its session:window.pane target syntax) —
    # verified against a live tmux server, see the module docstring.
    assert attach_command('pc001') == 'tmux attach -t pc001_linbo-remote'


def test_list_running_sessions_filters_non_linbo_remote_sessions():
    ts = 1733600000
    output = f'pc001_linbo-remote|{ts}\nsome-other-session|{ts}\n'

    with patch('linuxmusterTools.linbo.linbo_sync.subprocess.run') as run:
        run.return_value = MagicMock(stdout=output)
        sessions = list_running_sessions()

    assert sessions == [{
        'hostname': 'pc001',
        'session': 'pc001_linbo-remote',
        'created': datetime.fromtimestamp(ts, tz=timezone.utc).isoformat(),
    }]


def test_list_running_sessions_empty_when_no_sessions():
    with patch('linuxmusterTools.linbo.linbo_sync.subprocess.run') as run:
        run.return_value = MagicMock(stdout='')
        assert list_running_sessions() == []


def test_list_running_sessions_empty_when_no_tmux_binary():
    with patch('linuxmusterTools.linbo.linbo_sync.subprocess.run', side_effect=FileNotFoundError):
        assert list_running_sessions() == []


# ---------------------------------------------------------------------------
# onboot commands (linbocmd/<hostname>.cmd)
# ---------------------------------------------------------------------------

@pytest.fixture
def onboot_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(linbo_sync_module, "ONBOOT_CMD_PATH", tmp_path)
    (tmp_path / "pc02.cmd").write_text("sync:1,start:1\n")
    (tmp_path / "pc01.cmd").write_text(",noauto\n")
    (tmp_path / "README").write_text("not a command file")
    return tmp_path


def test_list_onboot_commands_reads_every_cmd_file(onboot_dir):
    assert linbo_sync_module.list_onboot_commands() == [
        {"hostname": "pc01", "commands": ["noauto"]},
        {"hostname": "pc02", "commands": ["sync:1", "start:1"]},
    ]


def test_list_onboot_commands_without_any_file(tmp_path, monkeypatch):
    monkeypatch.setattr(linbo_sync_module, "ONBOOT_CMD_PATH", tmp_path / "missing")
    assert linbo_sync_module.list_onboot_commands() == []


def test_list_onboot_commands_skips_a_file_not_named_after_a_host(onboot_dir):
    (onboot_dir / "not a host.cmd").write_text("sync:1\n")
    assert [p["hostname"] for p in linbo_sync_module.list_onboot_commands()] == ["pc01", "pc02"]


def test_get_onboot_command_reads_one_host(onboot_dir):
    assert linbo_sync_module.get_onboot_command("pc02") == {
        "hostname": "pc02", "commands": ["sync:1", "start:1"],
    }


def test_get_onboot_command_never_returns_the_rsync_password(onboot_dir):
    # What linbo-remote -p writes before an upload (buildOnbootCmds).
    (onboot_dir / "pc03.cmd").write_text("dryrun,linbo:secret,upload_image:1,start:1,noauto\n")

    expected = {"hostname": "pc03", "commands": ["dryrun", "upload_image:1", "start:1", "noauto"]}
    assert linbo_sync_module.get_onboot_command("pc03") == expected
    assert expected in linbo_sync_module.list_onboot_commands()


def test_get_onboot_command_without_pending_command(onboot_dir):
    with pytest.raises(FileNotFoundError):
        linbo_sync_module.get_onboot_command("pc03")


def test_get_onboot_command_rejects_an_invalid_hostname(onboot_dir):
    with pytest.raises(ValueError):
        linbo_sync_module.get_onboot_command("../start.conf")


def test_delete_onboot_command_removes_the_host_file(onboot_dir):
    linbo_sync_module.delete_onboot_command("pc01")
    assert not (onboot_dir / "pc01.cmd").exists()
    assert (onboot_dir / "pc02.cmd").exists()


def test_delete_onboot_command_without_pending_command(onboot_dir):
    with pytest.raises(FileNotFoundError):
        linbo_sync_module.delete_onboot_command("pc03")


@pytest.mark.parametrize("hostname", ["../start.conf", "pc01/x", "", "pc 01"])
def test_delete_onboot_command_rejects_an_invalid_hostname(onboot_dir, hostname):
    with pytest.raises(ValueError):
        linbo_sync_module.delete_onboot_command(hostname)
