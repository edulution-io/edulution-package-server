import ssl
import socket
from datetime import datetime, timezone

class DomCert:
    def __init__(self, hostname, port):
        self.hostname = hostname
        self.port = port
        self.load()

    def load(self):
        self.valid = None
        self.notAfter = None
        self.notAfter_timestamp = None
        self.cert = None
        self.issuer = None

        try:
            self._get_cert()
        except ssl.SSLCertVerificationError as e:
            # The TLS handshake already rejects an expired certificate, whose
            # dates can then not be read: 10 is X509_V_ERR_CERT_HAS_EXPIRED.
            if e.verify_code == 10:
                self.valid = False
                return
            raise
        self._get_limit()

    def _get_cert(self):
        """
        Get standard SSL cert from hostname:port
        """


        ctx = ssl.create_default_context()
        with ctx.wrap_socket(socket.socket(), server_hostname=self.hostname) as s:
            s.settimeout(10)
            s.connect((self.hostname, self.port))
            self.cert = s.getpeercert()
            self.issuer = self.cert["issuer"]

    def _get_limit(self):
        self.notAfter = self.cert['notAfter']
        self.notAfter_timestamp = datetime.strptime(self.notAfter,"%b %d %H:%M:%S %Y GMT").replace(tzinfo=timezone.utc)
        self.valid = (self.notAfter_timestamp - datetime.now(timezone.utc)).days > 0

    def isvalid(self):
        self.load()
        return self.valid

    def expires(self):
        self.load()
        if self.valid:
            return f"{(self.notAfter_timestamp - datetime.now(timezone.utc)).days} days ({self.notAfter})"

        if self.notAfter:
            return f"Expired since {self.notAfter}"
        return "Expired"
