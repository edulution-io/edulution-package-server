import subprocess
from datetime import datetime

import pytest

import linuxmusterTools.linbo.images as images_module
from linuxmusterTools.linbo.drivers import LinboDriverManager
from linuxmusterTools.linbo.images import (
    ImageExistsError,
    LinboImageManager,
    TIMESTAMP_FMT,
    timestamp2date,
)


@pytest.fixture
def environment(tmp_path, monkeypatch):
    images_root = tmp_path / "images"
    images_root.mkdir()
    drivers = LinboDriverManager(tmp_path / "drivers")
    monkeypatch.setattr(images_module, "LINBO_PATH", str(images_root))
    # _torrent_create() logs next to the real LINBO logs: keep every test out
    # of /var/log, whether or not it renames anything.
    monkeypatch.setattr(images_module, "LINBO_LOG_PATH", str(tmp_path / "log"))
    return images_root, LinboImageManager(driver_manager=drivers)


def _write_info(image_dir, filename, **fields):
    """Write a .info file with exactly the given key/value pairs."""

    content = "".join(f"{key}={value}\n" for key, value in fields.items())
    (image_dir / f"{filename}.info").write_text(content)


def _create_broken_image(images_root, name):
    """A base image with no .info file at all."""

    image_dir = images_root / name
    image_dir.mkdir()
    (image_dir / f"{name}.qcow2").touch()
    return image_dir


def _create_image(images_root, name, timestamp="202601010000"):
    """A complete, valid base image: .qcow2 plus a fully populated .info."""

    image_dir = _create_broken_image(images_root, name)
    _write_info(
        image_dir,
        f"{name}.qcow2",
        timestamp=timestamp,
        image=f"{name}.qcow2",
        imagesize="10",
        partition="/dev/sda1",
        partitionsize="20",
    )
    return image_dir


def _create_backup(image_dir, name, backup_timestamp):
    """A backup as restore()/the upload flow actually leaves one on disk.

    LinboImage(backup=True) never reads this .info (it gets its timestamp
    from the directory name instead), but restore() moves it wholesale along
    with the .qcow2 when swapping a backup back in as the base image — which
    then does need a complete .info to be loaded again.
    """

    backup_dir = image_dir / "backups" / backup_timestamp
    backup_dir.mkdir(parents=True)
    (backup_dir / f"{name}.qcow2").write_bytes(b"y" * 5)
    _write_info(
        backup_dir,
        f"{name}.qcow2",
        timestamp=backup_timestamp,
        image=f"{name}.qcow2",
        imagesize="5",
        partition="/dev/sda1",
        partitionsize="20",
    )
    return backup_dir


# ── parse_info_file / IncompleteImageInfoError ──────────────────────


def test_missing_info_file_reports_all_fields_missing(environment):
    images_root, images = environment
    _create_broken_image(images_root, "broken")

    images.list()

    group = images.groups["broken"]
    assert group.base is None
    assert "missing timestamp, image, imagesize, partition, partitionsize" in group.error


def test_legacy_info_file_reports_only_the_actually_missing_fields(environment):
    images_root, images = environment
    image_dir = _create_broken_image(images_root, "legacy")
    # Older format: "baseimage" instead of "partition", no timestamp.
    _write_info(
        image_dir,
        "legacy.qcow2",
        image="legacy.qcow2",
        baseimage="/dev/sda1",
        partitionsize="20",
        imagesize="10",
    )

    images.list()

    group = images.groups["legacy"]
    assert group.base is None
    assert "missing timestamp, partition" in group.error


def test_complete_info_file_parses_without_error(environment):
    images_root, images = environment
    _create_image(images_root, "ubuntu")

    images.list()

    group = images.groups["ubuntu"]
    assert group.base is not None
    assert group.error is None
    assert group.base.info_file.partition == "/dev/sda1"


# ── Isolation: one broken image must not break the whole listing ───


def test_broken_image_does_not_crash_manager_list(environment):
    images_root, images = environment
    _create_image(images_root, "good")
    _create_broken_image(images_root, "broken")

    images.list()

    assert set(images.groups) == {"good", "broken"}
    assert images.groups["good"].base is not None
    assert images.groups["broken"].base is None


def test_list_returns_images_in_natural_order(environment):
    images_root, images = environment
    for name in ["win10", "Debian", "win2", "ubuntu"]:
        _create_image(images_root, name)

    images.list()

    assert list(images.groups) == ["Debian", "ubuntu", "win2", "win10"]

def test_broken_image_group_to_dict_reports_error_without_crashing(environment):
    images_root, images = environment
    _create_broken_image(images_root, "broken")
    images.list()

    result = images.groups["broken"].to_dict()

    assert result["name"] == "broken"
    assert "missing" in result["error"]
    assert result["selected"] is False


def test_healthy_image_to_dict_is_unaffected_by_a_broken_sibling(environment):
    images_root, images = environment
    _create_image(images_root, "good")
    _create_broken_image(images_root, "broken")
    images.list()

    result = images.groups["good"].to_dict()

    assert result["name"] == "good"
    assert "error" not in result


# ── Refusing to mutate a broken group ───────────────────────────────


def test_rename_refuses_on_broken_group(environment):
    images_root, images = environment
    _create_broken_image(images_root, "broken")
    images.list()

    with pytest.raises(RuntimeError, match="Cannot rename image group broken"):
        images.groups["broken"].rename("renamed")

    # Nothing touched: the original directory is still there under its name.
    assert (images_root / "broken").is_dir()
    assert not (images_root / "renamed").exists()


def test_delete_removes_a_broken_group(environment):
    images_root, images = environment
    _create_broken_image(images_root, "broken")
    images.list()

    # A missing .info must not block the deletion: it is exactly the state a
    # failed delete used to leave behind (#39).
    images.delete("broken")

    assert "broken" not in images.groups
    assert not (images_root / "broken").exists()


def test_save_extras_refuses_on_broken_group(environment):
    images_root, images = environment
    _create_broken_image(images_root, "broken")
    images.list()

    with pytest.raises(RuntimeError, match="Cannot save extras for image group broken"):
        images.save_extras("broken", {"desc": "test"})


def test_save_extras_refuses_when_no_diff_image_exists(environment):
    images_root, images = environment
    _create_image(images_root, "ubuntu")
    images.list()
    assert images.groups["ubuntu"].diff_image is None

    with pytest.raises(RuntimeError, match="Image group ubuntu has no differential image"):
        images.save_extras("ubuntu", {"desc": "test"}, diff=True)


# ── Whole directory removal (#39) ────────────────────────────────────


def test_delete_removes_files_added_by_hand(environment):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    (image_dir / "stray.txt").write_text("leftover")
    (image_dir / "backups").mkdir()
    (image_dir / "backups" / "stray.txt").write_text("leftover")
    images.list()

    images.delete("ubuntu")

    assert not image_dir.exists()


def test_delete_removes_the_upload_backup_directory(environment):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    # image_sync.finalize_upload() keeps its copies in backup/ (singular),
    # which the former file-by-file deletion never knew about.
    upload_backup = image_dir / "backup" / "20260101120000"
    upload_backup.mkdir(parents=True)
    (upload_backup / "ubuntu.qcow2").write_bytes(b"x")
    images.list()

    images.delete("ubuntu")

    assert not image_dir.exists()


def test_delete_backup_removes_files_added_by_hand(environment):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    backup_ts = "202512241000"
    backup_dir = _create_backup(image_dir, "ubuntu", backup_ts)
    (backup_dir / "stray.txt").write_text("leftover")
    images.list()

    images.delete("ubuntu", date=timestamp2date(backup_ts))

    assert not backup_dir.exists()
    assert (image_dir / "ubuntu.qcow2").exists()


def test_delete_refuses_a_symlinked_image_directory(environment, tmp_path):
    images_root, images = environment
    outside = tmp_path / "outside"
    _create_image(tmp_path, "outside")
    (images_root / "linked").symlink_to(outside)
    (outside / "linked.qcow2").touch()
    images.list()

    with pytest.raises(RuntimeError, match="Refusing to remove"):
        images.groups["linked"].delete()

    assert (outside / "outside.qcow2").exists()


# ── Manager.delete() — the self.images/self.groups regression ──────


def test_delete_specific_backup_by_date(environment):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    backup_ts = "202512241000"
    _create_backup(image_dir, "ubuntu", backup_ts)
    images.list()
    date_key = timestamp2date(backup_ts)
    assert date_key in images.groups["ubuntu"].backups

    # This is exactly the path that used to raise AttributeError on the
    # undefined self.images.
    images.delete("ubuntu", date=date_key)

    assert date_key not in images.groups["ubuntu"].backups
    assert not (image_dir / "backups" / backup_ts).exists()
    # The base image itself must be untouched.
    assert (image_dir / "ubuntu.qcow2").exists()


def test_delete_whole_group(environment):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    images.list()

    images.delete("ubuntu")

    assert "ubuntu" not in images.groups
    assert not image_dir.exists()


def test_delete_diff_image(environment):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    (image_dir / "ubuntu.qdiff").write_bytes(b"z" * 5)
    _write_info(
        image_dir,
        "ubuntu.qdiff",
        timestamp="202601020000",
        image="ubuntu.qdiff",
        imagesize="5",
        partition="/dev/sda1",
        partitionsize="20",
    )
    images.list()
    assert images.groups["ubuntu"].diff_image is not None

    images.delete("ubuntu", diff=True)

    assert not (image_dir / "ubuntu.qdiff").exists()


# ── Manager.duplicate() ──────────────────────────────────────────────


def test_duplicate_creates_an_independent_copy(environment):
    images_root, images = environment
    _create_image(images_root, "ubuntu")
    images.list()

    images.duplicate("ubuntu", "ubuntu-copy")

    assert "ubuntu-copy" in images.groups
    assert (images_root / "ubuntu-copy" / "ubuntu-copy.qcow2").exists()
    # Original left untouched.
    assert (images_root / "ubuntu" / "ubuntu.qcow2").exists()


def test_duplicate_rejects_an_existing_target(environment):
    images_root, images = environment
    _create_image(images_root, "ubuntu")
    _create_image(images_root, "existing")
    images.list()

    with pytest.raises(ImageExistsError):
        images.duplicate("ubuntu", "existing")

    # Refused before touching anything: the target is exactly as it was.
    assert (images_root / "existing" / "existing.qcow2").exists()
    assert not (images_root / "existing" / "ubuntu.qcow2").exists()


# ── Manager.restore() ────────────────────────────────────────────────


def test_restore_swaps_base_and_backup(environment):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu", timestamp="202601010000")
    backup_ts = "202512240000"
    _create_backup(image_dir, "ubuntu", backup_ts)
    images.list()
    date_key = timestamp2date(backup_ts)

    images.restore("ubuntu", date_key)

    group = images.groups["ubuntu"]
    # The former backup is now the base image.
    assert group.base.timestamp == backup_ts
    # The former base image now lives under backups/ at today's timestamp.
    assert date_key not in group.backups
    assert len(group.backups) == 1


def test_restore_rejects_a_same_minute_collision(environment):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    backup_ts = "202512240000"
    _create_backup(image_dir, "ubuntu", backup_ts)
    images.list()
    date_key = timestamp2date(backup_ts)

    # Pre-create the exact directory restore() is about to mkdir: the backup
    # timestamp it generates has minute resolution (TIMESTAMP_FMT), so this
    # collision is deterministic within the same test run.
    collision_ts = datetime.now().strftime(TIMESTAMP_FMT)
    (image_dir / "backups" / collision_ts).mkdir()

    with pytest.raises(ImageExistsError):
        images.restore("ubuntu", date_key)

    # Refused before moving anything: original backup is still a backup.
    assert date_key in images.groups["ubuntu"].backups


# ── Torrents: rename/duplicate must not leave a stale one behind ─────


@pytest.fixture
def torrent_calls(monkeypatch):
    """Capture the linbo-torrent invocations instead of running them."""

    calls = []

    def fake_popen(command, **kwargs):
        calls.append(command)
        return None

    monkeypatch.setattr(images_module.subprocess, "Popen", fake_popen)
    monkeypatch.setattr(images_module.subprocess, "check_output", lambda *a, **k: b"")
    return calls


def _add_torrent(image_dir, image):
    """The pair linbo-torrent produces for an image: torrent plus its hash."""

    (image_dir / f"{image}.torrent").write_text("torrent")
    (image_dir / f"{image}.hash").write_text("deadbeef")


def test_rename_drops_the_torrent_and_its_hash(environment, torrent_calls):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    _add_torrent(image_dir, "ubuntu.qcow2")
    images.list()

    images.rename("ubuntu", "debian")

    renamed = images_root / "debian"
    # The hash describes the torrent that just went away: it must not survive
    # under the new name, where it would feed opentracker a phantom entry.
    assert not (renamed / "debian.qcow2.torrent").exists()
    assert not (renamed / "debian.qcow2.hash").exists()
    assert not (renamed / "ubuntu.qcow2.torrent").exists()
    assert not (renamed / "ubuntu.qcow2.hash").exists()


def test_rename_rebuilds_the_torrent_under_the_new_directory(environment, torrent_calls):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    _add_torrent(image_dir, "ubuntu.qcow2")
    images.list()

    images.rename("ubuntu", "debian")

    creations = [call for call in torrent_calls if call[1] == "create"]
    assert len(creations) == 1
    # Created only after the directory move, otherwise the seeding session
    # would point at a path that no longer exists.
    assert creations[0][2] == str(images_root / "debian" / "debian.qcow2")


def test_rename_does_not_rebuild_a_torrent_for_backups(environment, torrent_calls):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    _create_backup(image_dir, "ubuntu", "202601020000")
    images.list()

    images.rename("ubuntu", "debian")

    creations = [call for call in torrent_calls if call[1] == "create"]
    assert [call[2] for call in creations] == [
        str(images_root / "debian" / "debian.qcow2")
    ]


def test_duplicate_leaves_the_torrent_and_hash_behind(environment, torrent_calls):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    _add_torrent(image_dir, "ubuntu.qcow2")
    images.list()

    images.duplicate("ubuntu", "ubuntu-copy")

    copy = images_root / "ubuntu-copy"
    # A copied torrent would describe the original file name.
    assert not (copy / "ubuntu-copy.qcow2.torrent").exists()
    assert not (copy / "ubuntu-copy.qcow2.hash").exists()
    assert not (copy / "ubuntu.qcow2.torrent").exists()
    assert not (copy / "ubuntu.qcow2.hash").exists()
    # The original keeps its own.
    assert (image_dir / "ubuntu.qcow2.torrent").exists()
    assert (image_dir / "ubuntu.qcow2.hash").exists()


def test_to_dict_reports_whether_a_torrent_exists(environment, torrent_calls):
    images_root, images = environment
    image_dir = _create_image(images_root, "ubuntu")
    _create_image(images_root, "debian")
    _add_torrent(image_dir, "ubuntu.qcow2")
    images.list()

    assert images.groups["ubuntu"].base.to_dict()["torrent"] is True
    assert images.groups["debian"].base.to_dict()["torrent"] is False


# ---------------------------------------------------------------------------
# restart_image_services
# ---------------------------------------------------------------------------

def test_restart_image_services_restarts_multicast_and_torrent(monkeypatch):
    calls = []
    monkeypatch.setattr(images_module.subprocess, "run", lambda *args, **kwargs: calls.append((args, kwargs)))

    assert images_module.restart_image_services() == images_module.IMAGE_SERVICES

    (args, kwargs), = calls
    assert args[0] == ['systemctl', 'restart', 'linbo-multicast.service', 'linbo-torrent.service']
    assert kwargs["check"] is True
    assert kwargs["timeout"] == 60


def test_restart_image_services_raises_on_failure(monkeypatch):
    def fail(*args, **kwargs):
        raise subprocess.CalledProcessError(1, 'systemctl', stderr="Unit not found.")
    monkeypatch.setattr(images_module.subprocess, "run", fail)

    with pytest.raises(subprocess.CalledProcessError):
        images_module.restart_image_services()
