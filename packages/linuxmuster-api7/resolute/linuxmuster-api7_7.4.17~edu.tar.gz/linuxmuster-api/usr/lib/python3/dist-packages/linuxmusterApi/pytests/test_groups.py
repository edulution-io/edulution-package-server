import sys
import pytest
from fastapi.testclient import TestClient

from .credentials import *

sys.path.append(LOCAL_API_PATH)
from main import app

client = TestClient(app)
USERS = [GLOBALADMIN, SCHOOLADMIN, TEACHER, STUDENT, STAFF, PARENT]

_need_group = pytest.mark.skipif(GROUP == 'UNCONFIGURED', reason="GROUP not set in credentials.py")
_need_mgmt = pytest.mark.skipif(MGMT_GROUP == 'UNCONFIGURED', reason="MGMT_GROUP not set in credentials.py")


class TestGroups:
    def test_get_groups_ga(self):
        r = client.get(f"{BASE_URL}/groups/", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)

    def test_get_groups_sa(self):
        r = client.get(f"{BASE_URL}/groups/", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[2:])
    def test_get_groups_denied(self, user):
        r = client.get(f"{BASE_URL}/groups/", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    def test_get_legacy_groups_ga(self):
        r = client.get(f"{BASE_URL}/groups/legacy", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)

    def test_get_legacy_groups_sa(self):
        r = client.get(f"{BASE_URL}/groups/legacy", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[2:])
    def test_get_legacy_groups_denied(self, user):
        r = client.get(f"{BASE_URL}/groups/legacy", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @_need_group
    def test_get_group_ga(self):
        r = client.get(f"{BASE_URL}/groups/{GROUP}", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        data = r.json()
        assert data["cn"] == GROUP

    @_need_group
    def test_get_group_sa(self):
        r = client.get(f"{BASE_URL}/groups/{GROUP}", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[2:])
    def test_get_group_denied(self, user):
        r = client.get(f"{BASE_URL}/groups/{GROUP}", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_post_group_denied(self, user):
        r = client.post(
            f"{BASE_URL}/groups/{GROUP}",
            headers={"X-API-KEY": user.jwt},
            json={}
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_patch_group_denied(self, user):
        r = client.patch(
            f"{BASE_URL}/groups/{GROUP}",
            headers={"X-API-KEY": user.jwt},
            json={}
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_delete_group_denied(self, user):
        r = client.delete(f"{BASE_URL}/groups/{GROUP}", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_post_group_members_denied(self, user):
        r = client.post(
            f"{BASE_URL}/groups/{GROUP}/members",
            headers={"X-API-KEY": user.jwt},
            json={"users": []}
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_delete_group_members_denied(self, user):
        r = client.request(
            "DELETE",
            f"{BASE_URL}/groups/{GROUP}/members",
            headers={"X-API-KEY": user.jwt},
            json={"users": []}
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_post_migrate_group_denied(self, user):
        r = client.post(f"{BASE_URL}/groups/{GROUP}/migrate", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]


class TestManagementGroups:
    def test_get_managementgroups_ga(self):
        r = client.get(f"{BASE_URL}/managementgroups/", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)

    def test_get_managementgroups_sa(self):
        r = client.get(f"{BASE_URL}/managementgroups/", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    def test_get_managementgroups_teacher(self):
        r = client.get(f"{BASE_URL}/managementgroups/", headers={"X-API-KEY": TEACHER.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[3:])
    def test_get_managementgroups_denied(self, user):
        r = client.get(f"{BASE_URL}/managementgroups/", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @_need_mgmt
    def test_get_managementgroup_ga(self):
        r = client.get(f"{BASE_URL}/managementgroups/{MGMT_GROUP}", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        data = r.json()
        assert data["cn"] == MGMT_GROUP

    @_need_mgmt
    def test_get_managementgroup_sa(self):
        r = client.get(f"{BASE_URL}/managementgroups/{MGMT_GROUP}", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[2:])
    def test_get_managementgroup_denied(self, user):
        r = client.get(f"{BASE_URL}/managementgroups/{MGMT_GROUP}", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[3:])
    def test_post_managementgroup_members_denied(self, user):
        r = client.post(
            f"{BASE_URL}/managementgroups/{MGMT_GROUP}/members",
            headers={"X-API-KEY": user.jwt},
            json={"users": []}
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[3:])
    def test_delete_managementgroup_members_denied(self, user):
        r = client.request(
            "DELETE",
            f"{BASE_URL}/managementgroups/{MGMT_GROUP}/members",
            headers={"X-API-KEY": user.jwt},
            json={"users": []}
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]


@_need_mgmt
class TestManagementGroupMembers:
    """
    Exercises the actual add/remove logic (GroupManager, via Samba's SamDB)
    behind /managementgroups/{group}/members, not just permission checks.
    STUDENT's membership in MGMT_GROUP is snapshotted before and restored
    after every test, since the shared test LDAP may already have it in
    either state.
    """

    @staticmethod
    def _members():
        r = client.get(f"{BASE_URL}/managementgroups/{MGMT_GROUP}", headers={"X-API-KEY": GLOBALADMIN.jwt})
        return r.json()['member']

    @classmethod
    def _is_member(cls, cn):
        return any(m.startswith(f'CN={cn},') for m in cls._members())

    @staticmethod
    def _add(user_jwt, users, school=None):
        return client.post(
            f"{BASE_URL}/managementgroups/{MGMT_GROUP}/members",
            headers={"X-API-KEY": user_jwt},
            json={"users": users},
            params={"school": school} if school else {},
        )

    @staticmethod
    def _remove(user_jwt, users, school=None):
        return client.request(
            "DELETE",
            f"{BASE_URL}/managementgroups/{MGMT_GROUP}/members",
            headers={"X-API-KEY": user_jwt},
            json={"users": users},
            params={"school": school} if school else {},
        )

    @pytest.fixture(autouse=True)
    def _restore_student_membership(self):
        was_member = self._is_member(STUDENT.cn)
        yield
        is_member = self._is_member(STUDENT.cn)
        if was_member and not is_member:
            self._add(GLOBALADMIN.jwt, [STUDENT.cn], school="default-school")
        elif not was_member and is_member:
            self._remove(GLOBALADMIN.jwt, [STUDENT.cn], school="default-school")

    def test_post_then_delete_member_sa(self):
        assert self._add(SCHOOLADMIN.jwt, [STUDENT.cn]).status_code == 200
        assert self._is_member(STUDENT.cn)

        assert self._remove(SCHOOLADMIN.jwt, [STUDENT.cn]).status_code == 204
        assert not self._is_member(STUDENT.cn)

    def test_post_member_idempotent(self):
        # LDAP code 68 ("already a member") must be swallowed, not raised.
        assert self._add(SCHOOLADMIN.jwt, [STUDENT.cn]).status_code == 200
        assert self._add(SCHOOLADMIN.jwt, [STUDENT.cn]).status_code == 200
        assert self._is_member(STUDENT.cn)

    def test_delete_member_idempotent(self):
        # Removing a member who isn't (or is no longer) in the group must not error.
        self._remove(SCHOOLADMIN.jwt, [STUDENT.cn])
        assert self._remove(SCHOOLADMIN.jwt, [STUDENT.cn]).status_code == 204
        assert not self._is_member(STUDENT.cn)

    def test_post_member_ga_requires_school(self):
        # who.school == 'global': no school given -> 400, nothing done.
        assert self._add(GLOBALADMIN.jwt, [STUDENT.cn]).status_code == 400

    def test_post_member_ga_with_school(self):
        assert self._add(GLOBALADMIN.jwt, [STUDENT.cn], school="default-school").status_code == 200
        assert self._is_member(STUDENT.cn)

    def test_post_member_ga_unknown_school_404(self):
        assert self._add(GLOBALADMIN.jwt, [STUDENT.cn], school="not-a-real-school").status_code == 404

    def test_post_member_sa_other_school_forbidden(self):
        # school-administrators can't act on a school other than their own.
        assert self._add(SCHOOLADMIN.jwt, [STUDENT.cn], school="some-other-school").status_code == 403

    def test_post_member_unknown_group_404(self):
        r = client.post(
            f"{BASE_URL}/managementgroups/not-a-real-group/members",
            headers={"X-API-KEY": SCHOOLADMIN.jwt},
            json={"users": [STUDENT.cn]},
        )
        assert r.status_code == 404

    def test_post_member_unknown_user_404(self):
        # Regression check: GroupManager.add_members() used to swallow every
        # error, not just the benign "already a member" one, so this used to
        # report success even though nothing was added.
        # Uses GLOBALADMIN: UserListChecker validates each target user's role
        # for school-admins/teachers (rejecting an unknown user with a 401
        # before the endpoint even runs), but skips that check entirely for
        # global-administrators, so this is the one role that actually
        # reaches GroupManager.add_members() with an unresolvable member.
        r = self._add(GLOBALADMIN.jwt, ["not-a-real-user-xyz"], school="default-school")
        assert r.status_code == 404
        assert not self._is_member("not-a-real-user-xyz")

    def test_post_member_teacher(self):
        assert self._add(TEACHER.jwt, [STUDENT.cn]).status_code == 200
        assert self._is_member(STUDENT.cn)


class _FakeGroupManager:
    """
    Records the calls instead of writing to the AD: a broken check must not
    actually put somebody into "Domain Admins" on the test server.
    """

    calls = []

    def __init__(self, school='default-school'):
        pass

    def add_members(self, group, members):
        self.calls.append(('add', group))

    def remove_members(self, group, members):
        self.calls.append(('remove', group))


class TestManagementGroupWhitelist:
    @pytest.fixture(autouse=True)
    def _fake_group_manager(self, monkeypatch):
        _FakeGroupManager.calls = []
        monkeypatch.setattr("routers_v1.managementgroups.GroupManager", _FakeGroupManager)

    @pytest.mark.parametrize("method", ["POST", "DELETE"])
    @pytest.mark.parametrize("group", ["Domain Admins", "Administrators", "Enterprise Admins",
                                       "global-admins", "all-wifi", "Wifi", "teachers"])
    @pytest.mark.parametrize("user", [SCHOOLADMIN, TEACHER])
    def test_non_management_group_404(self, method, group, user):
        r = client.request(method, f"{BASE_URL}/managementgroups/{group}/members",
                           headers={"X-API-KEY": user.jwt}, json={"users": [STUDENT.cn]})
        # The older check rejects teachers on any name containing "admins" first
        expected = 403 if user is TEACHER and "admins" in group else 404
        assert r.status_code == expected
        assert _FakeGroupManager.calls == []

    @pytest.mark.parametrize("method", ["POST", "DELETE"])
    def test_admins_teacher_forbidden(self, method):
        r = client.request(method, f"{BASE_URL}/managementgroups/admins/members",
                           headers={"X-API-KEY": TEACHER.jwt}, json={"users": [STUDENT.cn]})
        assert r.status_code == 403
        assert _FakeGroupManager.calls == []

    @pytest.mark.parametrize("method, action", [("POST", "add"), ("DELETE", "remove")])
    @pytest.mark.parametrize("group", ["wifi", "internet", "intranet", "webfilter", "printing"])
    def test_management_group_allowed(self, method, action, group):
        r = client.request(method, f"{BASE_URL}/managementgroups/{group}/members",
                           headers={"X-API-KEY": TEACHER.jwt}, json={"users": [STUDENT.cn]})
        assert r.status_code in (200, 204)
        assert _FakeGroupManager.calls == [(action, group)]


@_need_group
class TestGroupPartialPatch:
    """
    A partial patch must not rewrite what the caller never sent. The schema
    used to default join to True and hide, mailalias and maillist to False,
    so a patch only renaming a group also unhid it and made it joinable.
    """

    TMP_GROUP = 'zz-pytest-defaults'

    @staticmethod
    def _details(group):
        return client.get(f"{BASE_URL}/groups/{group}", headers={"X-API-KEY": GLOBALADMIN.jwt}).json()

    @staticmethod
    def _patch(group, payload):
        return client.patch(f"{BASE_URL}/groups/{group}", headers={"X-API-KEY": SCHOOLADMIN.jwt}, json=payload)

    @pytest.fixture
    def restore(self):
        before = self._details(GROUP)
        yield before
        self._patch(GROUP, {
            "join": before["sophomorixJoinable"],
            "hide": before["sophomorixHidden"],
            "description": before["description"],
        })

    def test_patch_group_leaves_unsent_flags_alone(self, restore):
        self._patch(GROUP, {"join": False, "hide": True})
        staged = self._details(GROUP)
        assert staged["sophomorixJoinable"] is False
        assert staged["sophomorixHidden"] is True

        r = self._patch(GROUP, {"description": "partial patch"})
        assert r.status_code == 200

        after = self._details(GROUP)
        assert after["description"] == "partial patch"
        assert after["sophomorixJoinable"] is False
        assert after["sophomorixHidden"] is True
        assert after["sophomorixMailList"] == restore["sophomorixMailList"]
        assert after["sophomorixMailAlias"] == restore["sophomorixMailAlias"]

    def test_patch_group_still_applies_what_is_sent(self, restore):
        """The guard must not swallow an explicit false."""

        self._patch(GROUP, {"join": False})
        assert self._details(GROUP)["sophomorixJoinable"] is False

        self._patch(GROUP, {"join": True})
        assert self._details(GROUP)["sophomorixJoinable"] is True

    def test_create_group_keeps_the_defaults_for_unsent_flags(self):
        try:
            r = client.post(f"{BASE_URL}/groups/{self.TMP_GROUP}", headers={"X-API-KEY": SCHOOLADMIN.jwt}, json={})
            assert r.status_code == 200

            created = self._details(self.TMP_GROUP)
            assert created["sophomorixJoinable"] is True
            assert created["sophomorixHidden"] is False
            assert created["sophomorixMailList"] is False
            assert created["sophomorixMailAlias"] is False
        finally:
            client.delete(f"{BASE_URL}/groups/{self.TMP_GROUP}", headers={"X-API-KEY": SCHOOLADMIN.jwt})
